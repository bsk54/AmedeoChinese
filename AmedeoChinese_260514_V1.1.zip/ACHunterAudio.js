/**
 * ACHunterAudio.js - Audio-only drill for AC Hunter
 * Integrated with ACHunterSRS for SRS updates
 */

const ACHunterAudio = (function() {
    'use strict';

    // ========== STATE ==========
    const _ad = {
        pool: [],           // Array of items to drill
        i: 0,              // Current index
        revealed: false,   // Listening vs answer shown
        autoMode: false,   // Auto-advance mode
        tReveal: null,     // Reveal timer
        tNext: null,       // Next timer
        listName: '',      // Active list name
        stats: { knew: 0, again: 0 } // Session stats
    };

    // ========== LOCALSTORAGE KEYS ==========
    const LS_CHAR = 'achunteraudio.font.char';
    const LS_SENT = 'achunteraudio.font.sent';
    const LS_PAUSE = 'achunteraudio.pause.s';

    let _fontCharPx = parseInt(localStorage.getItem(LS_CHAR)) || 32;
    let _fontSentPx = parseInt(localStorage.getItem(LS_SENT)) || 16;
    let _pauseSec = parseInt(localStorage.getItem(LS_PAUSE)) || 3;

    // ========== TTS HELPERS ==========
    function speakChinese(text) {
        if (!text || !('speechSynthesis' in window)) return;
        try {
            speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'zh-CN';
            utterance.rate = _ad.speed || 1.0;  // Use stored speed
            speechSynthesis.speak(utterance);
        } catch (e) {
            console.error('TTS error:', e);
        }
    }

    // ========== DOM CREATION ==========
    function ensureAudioDrillDOM() {
        let wrap = document.getElementById('audioDrillOverlay');
        if (wrap) return wrap;

        wrap = document.createElement('div');
        wrap.id = 'audioDrillOverlay';
        wrap.innerHTML = `
            <div class="ad-backdrop"></div>
            <div class="ad-card" role="dialog" aria-modal="true" aria-label="Audio Drill">

                <header class="ad-header">
                    <div class="ad-header-content">
                        <div class="ad-bar">
                            <span>Audio Drill</span>
                            <button id="adCloseBtn" class="ad-close-btn" title="Close">×</button>
                        </div>
                    </div>
                </header>

                <div class="ad-spacer"></div>

                <div class="ad-body" id="adBody">
                    <!-- Green counter badge -->
                    <div id="adCountBadge" class="ad-count-badge">0</div>

                    <!-- Show/Next button (blue → green) -->
                    <button id="adActionBtn" class="ad-action-btn show" title="Reveal">Show ▶</button>
                    
                    <!-- Replay speaker (visible before reveal) -->
                    <button id="adReplayBtn" class="ad-replay-btn" title="Repeat sound">🔊</button>

                    <!-- Listening mask (dots) -->
                    <div class="ad-mask" id="adMask">••</div>

                    <!-- Answer reveal -->
                    <div class="ad-reveal" id="adReveal" hidden>
                        <div class="ad-hanzi" id="adHanzi" title="Click to pronounce">汉</div>
                        <div class="ad-pinyin" id="adPinyin">hàn</div>
                        <div class="ad-translation" id="adTranslation">Chinese character</div>
                    </div>
                </div>

                <footer class="ad-footer">
                    <div class="ad-footer-controls">
                        <label class="ad-slider">
                            <span>Pause</span>
                            <input id="adPauseSlider" type="range" min="3" max="10" step="1" value="${_pauseSec}" />
                            <span id="adPauseVal">${_pauseSec}s</span>
                        </label>
                        <div class="ad-footer-buttons">
                            <button id="adAutoBtn" class="ad-auto-btn" title="Auto-play reveal/next">Auto: OFF</button>
                            <label class="ad-random-label">
                                <input type="checkbox" id="adRandomCheckbox" />
                                <span>Random</span>
                            </label>
                        </div>
                    </div>
                    <div class="ad-footer-info">
                        <span id="adProg">1 / 1</span>
                        <span class="ad-hint">N/Space = next • R = reveal • A = auto • P = repeat</span>
                    </div>
                </footer>
            </div>
        `;
        document.body.appendChild(wrap);
        attachEventListeners();
        injectStyles();
        return wrap;
    }

    // ========== STYLES ==========
    function injectStyles() {
        // Remove ALL old style versions first
        ['achunteraudio-styles', 'achunteraudio-styles-v2', 'achunteraudio-styles-v3', 'achunteraudio-styles-v4-final'].forEach(id => {
            const old = document.getElementById(id);
            if (old) old.remove();
        });

        const styleId = 'achunteraudio-styles-v6';
        if (document.getElementById(styleId)) return;

        const style = document.createElement('style');
        style.id = styleId;
        style.textContent = `
            /* Audio Drill Overlay */
            #audioDrillOverlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: 10000;
                display: none;
                align-items: center;
                justify-content: center;
            }
            #audioDrillOverlay.active {
                display: flex;
            }
            .ad-backdrop {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
            }
            .ad-card {
                position: relative;
                background: white;
                border-radius: 12px;
                max-width: min(760px, 92vw);
                width: 90%;
                max-height: 90vh;
                display: flex;
                flex-direction: column;
                box-shadow: 0 10px 40px rgba(0,0,0,0.3);
                overflow: hidden;
            }

            /* Header - clean white, matching AC style */
            .ad-header {
                background: var(--ac-srs-card-bg, white);
                border-bottom: 1px solid rgba(0, 0, 0, 0.08);
            }
            .ad-header-content {
                max-width: 760px;
                margin: 0 auto;
                padding: 0.7rem 2rem;
            }
            .ad-bar {
                color: var(--ac-srs-text-main, #333);
                font-size: 1.1rem;
                font-weight: 400;
                display: flex;
                align-items: center;
                justify-content: space-between;
            }
            
            /* Close button in header */
            .ad-close-btn {
                background: #ff5252;
                color: white;
                border: none;
                width: 36px;
                height: 36px;
                border-radius: 50%;
                font-size: 1.5rem;
                font-weight: bold;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                line-height: 1;
                flex-shrink: 0;
            }
            .ad-close-btn:hover {
                background: #ff1744;
                transform: scale(1.05);
            }
            
            .ad-controls {
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
            }
            .ad-slider {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                color: var(--ac-srs-text-main, #555);
                font-size: 0.9rem;
            }
            .ad-slider span:first-child {
                min-width: 70px;
            }
            .ad-slider input[type="range"] {
                flex: 1;
                height: 4px;
            }
            .ad-slider span:last-child {
                min-width: 50px;
                text-align: right;
            }
            .ad-auto-btn {
                background: white;
                color: #333;
                border: none;
                padding: 0.5rem 1rem;
                border-radius: 20px;
                cursor: pointer;
                font-weight: 600;
                align-self: flex-start;
            }
            .ad-auto-btn.active {
                background: #4CAF50;
                color: white;
            }

            /* Spacer between header and body */
            .ad-spacer {
                height: 10px;
                background: #f0f0f0;
                flex-shrink: 0;
            }

            /* Body */
            .ad-body {
                flex: 1;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 2rem;
                position: relative;
                min-height: 400px;
            }

            /* Counter badge */
            .ad-count-badge {
                position: absolute;
                top: 1rem;
                left: 1rem;
                background: #4CAF50;
                color: white;
                width: 50px;
                height: 50px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 1.2rem;
                font-weight: bold;
                box-shadow: 0 2px 8px rgba(76, 175, 80, 0.3);
            }

            /* Action button (Show/Next) - top right of body */
            .ad-action-btn {
                position: absolute;
                right: 12px;
                top: 72px;
                padding: 12px 18px;
                font-size: 1rem;
                font-weight: bold;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                box-shadow: 0 2px 6px rgba(0,0,0,0.15);
                z-index: 5;
            }
            .ad-action-btn.show {
                background: #2196F3;
                color: white;
            }
            .ad-action-btn.next {
                background: #4CAF50;
                color: white;
            }
            .ad-action-btn:hover {
                filter: brightness(1.05);
            }

            /* Replay button - right side, directly UNDER Show button */
            .ad-replay-btn {
                position: absolute;
                right: 12px;
                top: 132px;
                background: rgba(127, 127, 127, 0.2);
                border: none;
                border-radius: 8px;
                font-size: 32px;
                line-height: 1;
                padding: 10px;
                cursor: pointer;
                z-index: 5;
            }
            .ad-replay-btn:hover {
                background: rgba(127, 127, 127, 0.3);
            }

            /* Listening mask */
            .ad-mask {
                font-size: 4rem;
                color: #ccc;
                letter-spacing: 1rem;
            }

            /* Answer reveal */
            .ad-reveal {
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 1rem;
                text-align: center;
            }
            .ad-hanzi {
                font-size: 64px;
                font-weight: normal;
                cursor: pointer;
                user-select: none;
            }
            .ad-pinyin {
                font-size: 24px;
                color: #666;
            }
            .ad-translation {
                font-size: 18px;
                color: #333;
                max-width: 400px;
            }

            /* Footer */
            .ad-footer {
                padding: 1rem;
                background: #f5f5f5;
                display: flex;
                flex-direction: column;
                gap: 0.75rem;
                font-size: 0.9rem;
                color: #666;
            }
            .ad-footer-controls {
                display: flex;
                align-items: center;
                gap: 1.5rem;
                flex-wrap: wrap;
            }
            .ad-footer-buttons {
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .ad-random-label {
                display: flex;
                align-items: center;
                gap: 6px;
                cursor: pointer;
                font-size: 0.9rem;
                color: var(--ac-srs-text-main, #555);
            }
            .ad-random-label input {
                cursor: pointer;
                background: white;
                border: 1px solid #ccc;
                width: 16px;
                height: 16px;
            }
            .ad-footer-info {
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .ad-hint {
                font-size: 0.8rem;
            }

            /* Dark mode */
            [data-theme="dark"] .ad-card,
            @media (prefers-color-scheme: dark) {
                .ad-card {
                    background: #1e1e1e;
                }
                .ad-hanzi,
                .ad-translation {
                    color: #eee;
                }
                .ad-pinyin {
                    color: #aaa;
                }
                .ad-footer {
                    background: #2a2a2a;
                    color: #aaa;
                }
            }

            /* Mobile adjustments */
            @media (max-width: 600px) {
                .ad-card {
                    width: 100%;
                    max-height: 100vh;
                    border-radius: 0;
                }
                .ad-header-content {
                    padding: 0.4rem 1rem;
                }
                .ad-spacer {
                    height: 10px;
                }
                .ad-body {
                    margin-top: 20px;
                }
                .ad-action-btn {
                    right: 0.5rem;
                    padding: 0.75rem 1.5rem;
                    font-size: 1rem;
                }
                .ad-hanzi {
                    font-size: 48px;
                }
                .ad-hint {
                    display: none;
                }
            }
        `;
        document.head.appendChild(style);
    }

    // ========== EVENT LISTENERS ==========
    function attachEventListeners() {
        // Close button
        document.getElementById('adCloseBtn')?.addEventListener('click', close);

        // Pause slider (only one remaining)
        document.getElementById('adPauseSlider')?.addEventListener('input', (e) => {
            _pauseSec = parseInt(e.target.value);
            document.getElementById('adPauseVal').textContent = _pauseSec + 's';
            localStorage.setItem(LS_PAUSE, _pauseSec);
        });

        // Auto button
        document.getElementById('adAutoBtn')?.addEventListener('click', () => {
            _ad.autoMode = !_ad.autoMode;
            const btn = document.getElementById('adAutoBtn');
            btn.textContent = _ad.autoMode ? 'Auto: ON' : 'Auto: OFF';
            btn.classList.toggle('active', _ad.autoMode);
        });

        // Random checkbox
        const randomCheckbox = document.getElementById('adRandomCheckbox');
        if (randomCheckbox) {
            // Load saved state
            const savedRandom = localStorage.getItem('achunteraudio.random') === 'true';
            randomCheckbox.checked = savedRandom;
            
            // Save on change
            randomCheckbox.addEventListener('change', (e) => {
                localStorage.setItem('achunteraudio.random', e.target.checked);
                console.log('🔀 Random mode:', e.target.checked);
            });
        }

        // Action button (Show/Next)
        document.getElementById('adActionBtn')?.addEventListener('click', handleAction);

        // Replay button
        document.getElementById('adReplayBtn')?.addEventListener('click', () => {
            const item = _ad.pool[_ad.i];
            if (item) speakChinese(item.zh);
        });

        // Hanzi click (pronounce)
        document.getElementById('adHanzi')?.addEventListener('click', () => {
            const item = _ad.pool[_ad.i];
            if (item) speakChinese(item.zh);
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', handleKeyboard);

        // Backdrop click to close
        document.querySelector('.ad-backdrop')?.addEventListener('click', close);
    }

    // ========== KEYBOARD HANDLER ==========
    function handleKeyboard(e) {
        const overlay = document.getElementById('audioDrillOverlay');
        if (!overlay || !overlay.classList.contains('active')) return;

        const key = e.key.toLowerCase();

        if (key === 'escape') {
            e.preventDefault();
            close();
        } else if (key === 'n' || key === ' ') {
            e.preventDefault();
            handleAction();
        } else if (key === 'r') {
            e.preventDefault();
            if (!_ad.revealed) {
                handleAction(); // Reveal
            }
        } else if (key === 'a') {
            e.preventDefault();
            document.getElementById('adAutoBtn')?.click();
        } else if (key === 'p') {
            e.preventDefault();
            document.getElementById('adReplayBtn')?.click();
        }
    }

    // ========== TIMERS ==========
    function clearTimers() {
        if (_ad.tReveal) {
            clearTimeout(_ad.tReveal);
            _ad.tReveal = null;
        }
        if (_ad.tNext) {
            clearTimeout(_ad.tNext);
            _ad.tNext = null;
        }
    }

    // ========== ACTION HANDLER ==========
    function handleAction() {
        if (!_ad.revealed) {
            // Show answer + auto-replay
            reveal();
        } else {
            // Next word (no scoring)
            next();
        }
    }

    function reveal() {
        _ad.revealed = true;
        render();
        
        // Auto-replay the sound when revealing
        const item = _ad.pool[_ad.i];
        if (item) {
            setTimeout(() => speakChinese(item.zh), 100);
        }

        // Auto-advance if enabled
        if (_ad.autoMode) {
            clearTimers();
            _ad.tNext = setTimeout(() => {
                next(); // Just move to next (no scoring in auto mode)
            }, _pauseSec * 1000);
        }
    }

    function next() {
        clearTimers();
        _ad.i++;
        _ad.revealed = false;

        if (_ad.i >= _ad.pool.length) {
            finish();
        } else {
            render();
            // Auto-play Chinese
            const item = _ad.pool[_ad.i];
            if (item) {
                setTimeout(() => speakChinese(item.zh), 100);
            }
        }
    }

    // ========== RENDER ==========
    function render() {
        const item = _ad.pool[_ad.i];
        if (!item) return;

        // Update counter badge
        const remaining = _ad.pool.length - _ad.i;
        document.getElementById('adCountBadge').textContent = remaining;

        // Update progress
        document.getElementById('adProg').textContent = `${_ad.i + 1} / ${_ad.pool.length}`;

        // Show/hide elements
        document.getElementById('adMask').hidden = _ad.revealed;
        document.getElementById('adReveal').hidden = !_ad.revealed;
        document.getElementById('adReplayBtn').style.display = 'block';

        // Update action button
        const actionBtn = document.getElementById('adActionBtn');
        if (_ad.revealed) {
            actionBtn.textContent = 'Next ▶';
            actionBtn.classList.remove('show');
            actionBtn.classList.add('next');
            actionBtn.title = 'Next';
        } else {
            actionBtn.textContent = 'Show ▶';
            actionBtn.classList.remove('next');
            actionBtn.classList.add('show');
            actionBtn.title = 'Reveal';
        }

        // Fill answer content
        if (_ad.revealed) {
            // REVEALED: Show everything
            document.getElementById('adHanzi').textContent = item.zh;
            document.getElementById('adHanzi').style.fontSize = _fontCharPx + 'px';
            document.getElementById('adPinyin').textContent = item.py;
            document.getElementById('adTranslation').textContent = item.tr;
            document.getElementById('adTranslation').style.fontSize = _fontSentPx + 'px';
        } else {
            // LISTENING: Clear everything (blank screen for guessing)
            document.getElementById('adHanzi').textContent = '';
            document.getElementById('adPinyin').textContent = '';
            document.getElementById('adTranslation').textContent = '';
        }
    }

    // ========== START ==========
    function start(words, speed = 1.0) {
        console.log('🎧 Starting Audio Drill with', words.length, 'words');
        console.log('🎧 Speed:', speed);

        // Validate input
        if (!words || words.length === 0) {
            alert('No words available for audio drill!');
            return;
        }

        // Load random setting from localStorage
        const randomEnabled = localStorage.getItem('achunteraudio.random') === 'true';
        
        // Shuffle if random is enabled
        let processedWords = [...words];  // Copy array
        if (randomEnabled) {
            console.log('🔀 Shuffling words (random mode enabled)');
            // Fisher-Yates shuffle
            for (let i = processedWords.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [processedWords[i], processedWords[j]] = [processedWords[j], processedWords[i]];
            }
        }

        // Initialize state
        _ad.pool = processedWords;
        _ad.i = 0;
        _ad.revealed = false;
        _ad.autoMode = false;
        _ad.listName = '';
        _ad.stats = { completed: 0 };
        _ad.speed = speed;  // Store speed for TTS

        // Show overlay
        ensureAudioDrillDOM();
        document.getElementById('audioDrillOverlay').classList.add('active');

        // Render first question
        render();

        // Auto-play first word
        setTimeout(() => speakChinese(_ad.pool[0].zh), 300);
    }

    // ========== FINISH ==========
    function finish() {
        clearTimers();
        
        // Show simple completion message
        const totalWords = _ad.pool.length;
        const message = `Audio Drill Complete!\n\nYou reviewed ${totalWords} word${totalWords !== 1 ? 's' : ''}.`;
        
        alert(message);
        close();
    }

    // ========== CLOSE ==========
    function close() {
        clearTimers();
        speechSynthesis.cancel();
        document.getElementById('audioDrillOverlay')?.classList.remove('active');
    }

    // ========== PUBLIC API ==========
    return {
        start: start,
        close: close
    };
})();

// Auto-initialize on load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        console.log('✅ ACHunterAudio loaded');
    });
} else {
    console.log('✅ ACHunterAudio loaded');
}