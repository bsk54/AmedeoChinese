/**
 * ACHunter.js
 *
 * Embedded Hanzi Hunter inside Amedeo Chinese.
 *
 * Phase 1 — list management UI
 *   Step 1: 🎯 entry button + fullscreen panel + ACLists storage scaffolding
 *   Step 2: list CRUD (create, rename, delete, set active)
 *   Step 3: per-list contents view (planned)
 *   Step 4: bubble Export → list (planned)
 *   Step 5: paste-import (planned)
 *   Step 6: hamburger items + polish (planned)
 *
 * Phase 2 — full Hanzi Hunter (SRS, bubble hunt, list view, audio drill).
 * Phase 3 — polish.
 *
 * Storage:
 *   - localStorage key 'ACLists'   — owned entirely by this module.
 *   - localStorage key 'ACVariables' — NOT touched.
 *   - localStorage key 'ACData'      — NOT touched.
 *
 * Mount point in HTML:
 *   - <button id="hunterEntryBadge"> — the 🎯 nav badge (in HTML directly)
 *   - <div id="hunterRoot"></div>    — populated by this module on load
 */

(function () {
    'use strict';

    /* ============================================================
     * AC LISTS — storage scaffolding
     *
     * Storage shape (localStorage key 'ACLists'):
     *
     *   {
     *     schema: 1,
     *     activeListId: "list_001",        // or null if none
     *     lastUsedListId: "list_001",      // hint for Export modal default
     *     lists: {
     *       "list_001": {
     *         id: "list_001",
     *         name: "HSK 1 Words",
     *         createdAt: "2026-04-30T10:00:00.000Z",
     *         updatedAt: "2026-04-30T10:00:00.000Z",
     *         defaultLang: "EN",          // for items missing .lang
     *         items: [
     *           { zh: "你好", py: "nǐhǎo", tr: "hello", lang: "EN" }
     *         ]
     *       }
     *     }
     *   }
     * ============================================================ */

    const AC_LISTS_KEY = 'ACLists';

    function defaultACLists() {
        return {
            schema: 1,
            activeListId: null,
            lastUsedListId: null,
            lists: {}
        };
    }

    function getACLists() {
        try {
            const raw = localStorage.getItem(AC_LISTS_KEY);
            if (!raw) return defaultACLists();
            const data = JSON.parse(raw);
            if (!data.schema)        data.schema = 1;
            if (!data.lists || typeof data.lists !== 'object') data.lists = {};
            if (!('activeListId'   in data)) data.activeListId   = null;
            if (!('lastUsedListId' in data)) data.lastUsedListId = null;
            return data;
        } catch (e) {
            console.warn('[ACLists] Failed to parse storage, returning defaults:', e);
            return defaultACLists();
        }
    }

    function saveACLists(data) {
        try {
            localStorage.setItem(AC_LISTS_KEY, JSON.stringify(data));
        } catch (e) {
            console.error('[ACLists] Failed to save:', e);
            alert('Could not save list data — your browser storage may be full.');
        }
    }

    function initACListsStorage() {
        if (!localStorage.getItem(AC_LISTS_KEY)) {
            saveACLists(defaultACLists());
        }
    }

    function newListId() {
        const t = Date.now().toString(36);
        const r = Math.random().toString(36).slice(2, 6);
        return 'list_' + t + '_' + r;
    }

    function getActiveACList() {
        const data = getACLists();
        if (!data.activeListId) return null;
        return data.lists[data.activeListId] || null;
    }

    function getAllACLists() {
        const data = getACLists();
        return Object.values(data.lists);
    }


    /* ============================================================
     * Hunter panel — markup injection
     *
     * Builds the panel + modals once at load time and inserts them
     * into #hunterRoot. Earlier we had this as static HTML in
     * AmedeoChineseIndex.html; injecting from JS keeps the host file
     * thin and lets ACHunter own its own markup as well as logic.
     * ============================================================ */

    const HUNTER_HTML = `
        <!-- Fullscreen panel -->
        <div class="hh-panel" id="hunterPanel" aria-hidden="true">
            <header class="hh-panel-header">
                <button class="hh-panel-back" id="hunterPanelBack" title="Back to Amedeo Chinese" aria-label="Back">←</button>
                <div class="hh-panel-title">Amedeo Chinese Word Lists</div>
                <div class="hh-panel-spacer"></div>
            </header>
            <div class="hh-panel-body">

                <!-- Lists view (Step 2) -->
                <section class="hh-lists-view" id="hhListsView">
                    <div class="hh-lists-toolbar">
                        <div class="hh-lists-title-row">
                            <h2 class="hh-lists-h">Lists</h2>
                            <span class="hh-lists-count" id="hhListsCount"></span>
                        </div>
                        <button class="hh-btn hh-btn-primary" id="hhNewListBtn" title="Create a new list">+ New list</button>
                    </div>

                    <div class="hh-empty hh-empty-lists" id="hhListsEmpty" style="display:none">
                        <div class="hh-empty-icon">📋</div>
                        <div class="hh-empty-title">No lists yet</div>
                        <div class="hh-empty-hint">
                            Create a list to start collecting words.<br>
                            Words you Export from the bubble game will land in your active list.
                        </div>
                        <button class="hh-btn hh-btn-primary hh-empty-cta" id="hhEmptyCreateBtn">+ Create your first list</button>
                    </div>

                    <div class="hh-list-collection" id="hhListCollection"></div>
                </section>

                <!-- Per-list contents view (Step 3) -->
                <section class="hh-contents-view" id="hhContentsView" style="display:none">
                    <div class="hh-contents-toolbar">
                        <button class="hh-btn hh-btn-ghost" id="hhContentsBackBtn">← Lists</button>
                        <div class="hh-contents-title-row">
                            <h2 class="hh-contents-h" id="hhContentsTitle">List name</h2>
                            <span class="hh-contents-count" id="hhContentsCount"></span>
                        </div>
                        <div class="hh-contents-actions">
                            <button class="hh-btn hh-btn-ghost" id="hhImportBtn" title="Paste-import words">Import</button>
                            <button class="hh-btn hh-btn-primary" id="hhAddWordBtn" title="Add a word">+ Add word</button>
                        </div>
                    </div>

                    <div class="hh-empty hh-empty-words" id="hhWordsEmpty" style="display:none">
                        <div class="hh-empty-icon">📝</div>
                        <div class="hh-empty-title">No words yet</div>
                        <div class="hh-empty-hint">
                            Add words manually or export them from the bubble game.<br>
                            You can also paste-import a batch of words.
                        </div>
                    </div>

                    <div class="hh-words-collection" id="hhWordsCollection"></div>
                </section>

            </div>
        </div>

        <!-- Create / Rename modal -->
        <div class="hh-modal-overlay" id="hhListNameOverlay" aria-hidden="true">
            <div class="hh-modal" role="dialog" aria-modal="true" aria-labelledby="hhListNameTitle">
                <header class="hh-modal-header">
                    <h3 id="hhListNameTitle">New list</h3>
                    <button class="hh-modal-close" id="hhListNameClose" aria-label="Close">×</button>
                </header>
                <div class="hh-modal-body">
                    <label class="hh-label" for="hhListNameInput">List name</label>
                    <input type="text" class="hh-input" id="hhListNameInput"
                           maxlength="80" placeholder="e.g. HSK 1 — Lesson 5"
                           autocomplete="off" autocapitalize="sentences" spellcheck="false">
                    <div class="hh-modal-hint" id="hhListNameHint"></div>
                </div>
                <footer class="hh-modal-footer">
                    <button class="hh-btn hh-btn-ghost" id="hhListNameCancel">Cancel</button>
                    <button class="hh-btn hh-btn-primary" id="hhListNameSubmit">Create</button>
                </footer>
            </div>
        </div>

        <!-- Confirm-delete modal -->
        <div class="hh-modal-overlay" id="hhListDeleteOverlay" aria-hidden="true">
            <div class="hh-modal" role="dialog" aria-modal="true" aria-labelledby="hhListDeleteTitle">
                <header class="hh-modal-header">
                    <h3 id="hhListDeleteTitle">Delete list?</h3>
                    <button class="hh-modal-close" id="hhListDeleteClose" aria-label="Close">×</button>
                </header>
                <div class="hh-modal-body">
                    <div class="hh-modal-hint" id="hhListDeleteHint"></div>
                </div>
                <footer class="hh-modal-footer">
                    <button class="hh-btn hh-btn-ghost"   id="hhListDeleteCancel">Cancel</button>
                    <button class="hh-btn hh-btn-danger"  id="hhListDeleteSubmit">Delete</button>
                </footer>
            </div>
        </div>

        <!-- Add / Edit word modal (Step 3) -->
        <div class="hh-modal-overlay" id="hhWordEditOverlay" aria-hidden="true">
            <div class="hh-modal" role="dialog" aria-modal="true" aria-labelledby="hhWordEditTitle">
                <header class="hh-modal-header">
                    <h3 id="hhWordEditTitle">Add word</h3>
                    <button class="hh-modal-close" id="hhWordEditClose" aria-label="Close">×</button>
                </header>
                <div class="hh-modal-body">
                    <label class="hh-label" for="hhWordZhInput">Chinese</label>
                    <input type="text" class="hh-input" id="hhWordZhInput"
                           placeholder="你好" autocomplete="off" spellcheck="false">
                    
                    <label class="hh-label" for="hhWordPyInput" style="margin-top:0.75rem">Pinyin (optional)</label>
                    <input type="text" class="hh-input" id="hhWordPyInput"
                           placeholder="nǐhǎo" autocomplete="off" spellcheck="false">
                    
                    <label class="hh-label" for="hhWordTrInput" style="margin-top:0.75rem">Translation</label>
                    <input type="text" class="hh-input" id="hhWordTrInput"
                           placeholder="hello" autocomplete="off" spellcheck="false">
                    
                    <label class="hh-label" for="hhWordLangSelect" style="margin-top:0.75rem">Language</label>
                    <select class="hh-input" id="hhWordLangSelect">
                        <option value="EN">English</option>
                        <option value="ES">Spanish</option>
                        <option value="FR">French</option>
                        <option value="DE">German</option>
                        <option value="AR">Arabic</option>
                        <option value="BN">Bengali</option>
                        <option value="NL">Dutch</option>
                        <option value="FA">Farsi</option>
                        <option value="HI">Hindi</option>
                        <option value="ID">Indonesian</option>
                        <option value="IT">Italian</option>
                        <option value="JA">Japanese</option>
                        <option value="KO">Korean</option>
                        <option value="PT">Portuguese</option>
                        <option value="RU">Russian</option>
                        <option value="TH">Thai</option>
                        <option value="TL">Tagalog</option>
                        <option value="TR">Turkish</option>
                        <option value="UK">Ukrainian</option>
                        <option value="UR">Urdu</option>
                        <option value="VI">Vietnamese</option>
                    </select>

                    <div class="hh-modal-hint" id="hhWordEditHint"></div>
                </div>
                <footer class="hh-modal-footer">
                    <button class="hh-btn hh-btn-ghost" id="hhWordEditCancel">Cancel</button>
                    <button class="hh-btn hh-btn-primary" id="hhWordEditSubmit">Add</button>
                </footer>
            </div>
        </div>

        <!-- Confirm-delete word modal (Step 3) -->
        <div class="hh-modal-overlay" id="hhWordDeleteOverlay" aria-hidden="true">
            <div class="hh-modal" role="dialog" aria-modal="true" aria-labelledby="hhWordDeleteTitle">
                <header class="hh-modal-header">
                    <h3 id="hhWordDeleteTitle">Delete word?</h3>
                    <button class="hh-modal-close" id="hhWordDeleteClose" aria-label="Close">×</button>
                </header>
                <div class="hh-modal-body">
                    <div class="hh-modal-hint" id="hhWordDeleteHint"></div>
                </div>
                <footer class="hh-modal-footer">
                    <button class="hh-btn hh-btn-ghost"   id="hhWordDeleteCancel">Cancel</button>
                    <button class="hh-btn hh-btn-danger"  id="hhWordDeleteSubmit">Delete</button>
                </footer>
            </div>
        </div>

        <!-- Paste-import modal (Step 5) -->
        <div class="hh-modal-overlay" id="hhImportOverlay" aria-hidden="true">
            <div class="hh-modal hh-modal-wide" role="dialog" aria-modal="true" aria-labelledby="hhImportTitle">
                <header class="hh-modal-header">
                    <h3 id="hhImportTitle">Import words</h3>
                    <button class="hh-modal-close" id="hhImportClose" aria-label="Close">×</button>
                </header>
                <div class="hh-modal-body">
                    <label class="hh-label" for="hhImportTextarea">Paste word data</label>
                    <textarea class="hh-input hh-textarea" id="hhImportTextarea" 
                              placeholder="Paste tab-delimited or #-delimited rows:
你好	nǐhǎo	hello
再见	zàijiàn	goodbye

Supported formats:
• 2 columns: word, translation (non-Chinese pairs)
• 3 columns: Chinese, pinyin, translation
• 4 columns: Chinese, pinyin, translation, language"
                              rows="8" spellcheck="false"></textarea>
                    
                    <div id="hhImportPreviewSection" style="display:none; margin-top:1rem;">
                        <div class="hh-import-preview-header">
                            <strong>Preview</strong>
                            <span id="hhImportPreviewSummary" style="color:var(--text-secondary,#888);font-size:0.9rem;"></span>
                        </div>
                        <div id="hhImportPreview" class="hh-import-preview"></div>
                        
                        <div id="hhImportLangPicker" style="display:none; margin-top:0.75rem;">
                            <label class="hh-label" for="hhImportLangSelect">Translation language</label>
                            <select class="hh-input" id="hhImportLangSelect" style="width:auto;">
                                <option value="EN">English</option>
                                <option value="ES">Spanish</option>
                                <option value="FR">French</option>
                                <option value="DE">German</option>
                                <option value="AR">Arabic</option>
                                <option value="BN">Bengali</option>
                                <option value="NL">Dutch</option>
                                <option value="FA">Farsi</option>
                                <option value="HI">Hindi</option>
                                <option value="ID">Indonesian</option>
                                <option value="IT">Italian</option>
                                <option value="JA">Japanese</option>
                                <option value="KO">Korean</option>
                                <option value="PT">Portuguese</option>
                                <option value="RU">Russian</option>
                                <option value="TH">Thai</option>
                                <option value="TL">Tagalog</option>
                                <option value="TR">Turkish</option>
                                <option value="UK">Ukrainian</option>
                                <option value="UR">Urdu</option>
                                <option value="VI">Vietnamese</option>
                            </select>
                        </div>
                    </div>

                    <div class="hh-modal-hint" id="hhImportHint"></div>
                </div>
                <footer class="hh-modal-footer">
                    <button class="hh-btn hh-btn-ghost" id="hhImportCancel">Cancel</button>
                    <button class="hh-btn hh-btn-primary" id="hhImportSubmit" disabled>Import</button>
                </footer>
            </div>
        </div>
    `;

    function mountHunterMarkup() {
        const root = document.getElementById('hunterRoot');
        if (!root) {
            console.warn('[ACHunter] #hunterRoot not found in DOM — markup not mounted.');
            return false;
        }
        // Idempotent: only inject once.
        if (root.dataset.mounted === '1') return true;
        root.innerHTML = HUNTER_HTML;
        root.dataset.mounted = '1';
        return true;
    }


    /* ============================================================
     * Panel control
     *
     * Open/close the fullscreen Hunter panel. On open, stop any AC
     * audio (idempotent — these helpers no-op if nothing is playing).
     * ============================================================ */

    // Track which AC content section was visible BEFORE opening the panel,
    // so we can restore it on close. Fixes the "blank content" bug after
    // returning from the Hunter panel.
    let _previousSectionState = null;

    function snapshotACState() {
        // The most reliable source of truth: AC persists currentSection to
        // localStorage as part of ACVariables. This is set by AC's showSection()
        // function whenever the user navigates between T/W/G/P/W*/S sections,
        // and it survives reloads. Reading this avoids all the timing issues
        // with badge .active states being cleared before our snapshot runs.
        try {
            const acVarsRaw = localStorage.getItem('ACVariables');
            if (acVarsRaw) {
                const acVars = JSON.parse(acVarsRaw);
                if (acVars && acVars.currentSection && acVars.currentSection !== 'null') {
                    _previousSectionState = { sectionName: acVars.currentSection };
                    console.log('[ACHunter] Snapshotted from localStorage:', acVars.currentSection);
                    return;
                }
            }
        } catch (e) {
            console.warn('[ACHunter] Failed to read ACVariables:', e);
        }

        // Fallback 1: Check body[data-section]
        try {
            const ds = document.body.getAttribute('data-section');
            if (ds && ds !== 'null' && ds !== '') {
                _previousSectionState = { sectionName: ds };
                console.log('[ACHunter] Snapshotted from body[data-section]:', ds);
                return;
            }
        } catch (_) {}

        // Fallback 2: Check active badges
        try {
            const badges = document.querySelectorAll('.nav-badge.active');
            for (const b of badges) {
                if (b.id === 'hunterEntryBadge' || b.id === 'study-badge') continue;
                const section = b.getAttribute('data-section');
                if (section && section !== 'null' && section !== '') {
                    _previousSectionState = { sectionName: section };
                    console.log('[ACHunter] Snapshotted from active badge:', section);
                    return;
                }
            }
        } catch (_) {}

        // Fallback 3: Default to 'text' section if nothing found
        _previousSectionState = { sectionName: 'text' };
        console.log('[ACHunter] No section found, defaulting to: text');
    }

    function restoreACState() {
        if (!_previousSectionState || !_previousSectionState.sectionName) {
            return;
        }
        const target = _previousSectionState.sectionName;
        // The most reliable restoration is to click the nav badge that was
        // active before — this fires AC's own switchSection → showSection
        // path with all the side effects already wired up.
        try {
            const badge = document.querySelector(
                '.nav-badge[data-section="' + target.replace(/"/g, '\\"') + '"]'
            );
            if (badge) {
                badge.click();
            } else {
                console.warn('[ACHunter] ⚠ No badge found for section', target);
            }
        } catch (e) {
            console.warn('[ACHunter] restoreACState click failed:', e);
            // Last-ditch fallback: maybe AC exposed showSection on window.
            try {
                if (window.showSection) {
                    window.showSection(target);
                } else {
                    console.warn('[ACHunter] window.showSection not available');
                }
            } catch (e2) {
                console.warn('[ACHunter] Fallback also failed:', e2);
            }
        }
    }

    function openHunterPanel() {
        if (!mountHunterMarkup()) return;
        const panel = document.getElementById('hunterPanel');
        if (!panel) return;

        // Stop any audio currently playing before transitioning.
        try { window.stopAllAudio       && window.stopAllAudio(); }       catch (_) {}
        try { window.stopAutoplay       && window.stopAutoplay(); }       catch (_) {}
        try { window.stopWordAutoplay   && window.stopWordAutoplay(); }   catch (_) {}

        panel.classList.add('open');
        panel.setAttribute('aria-hidden', 'false');

        const badge = document.getElementById('hunterEntryBadge');
        if (badge) badge.classList.add('active');

        initACListsStorage();
        renderHHListsView();
    }

    function closeHunterPanel() {
        const panel = document.getElementById('hunterPanel');
        if (!panel) return;

        // Reset to lists view before closing (in case we were in contents view).
        // This ensures next open starts fresh at lists, not stuck in a per-list view.
        if (_openListId) {
            closeListContents();
        }

        // BUG FIX (aria-hidden warning): blur any descendant focus before
        // we set aria-hidden="true". Without this, browsers warn (and
        // screen readers complain) that we're hiding a focused element.
        const active = document.activeElement;
        if (active && panel.contains(active) && typeof active.blur === 'function') {
            try { active.blur(); } catch (_) {}
        }

        panel.classList.remove('open');
        panel.setAttribute('aria-hidden', 'true');

        const badge = document.getElementById('hunterEntryBadge');
        if (badge) badge.classList.remove('active');

        // BUG FIX (blank content): re-render the AC section the user came
        // from, so they don't return to an empty content area.
        restoreACState();
    }


    /* ============================================================
     * AC LISTS — UI logic
     * ============================================================ */

    function hhFormatDate(iso) {
        if (!iso) return '';
        try {
            const d = new Date(iso);
            if (isNaN(d.getTime())) return '';
            const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            const now = new Date();
            const sameYear = d.getFullYear() === now.getFullYear();
            const base = months[d.getMonth()] + ' ' + d.getDate();
            return sameYear ? base : base + ' ' + d.getFullYear();
        } catch (_) { return ''; }
    }

    function hhEscape(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function hhSortListsForDisplay(allLists, activeListId) {
        return allLists.slice().sort((a, b) => {
            // Active list always first.
            if (a.id === activeListId && b.id !== activeListId) return -1;
            if (b.id === activeListId && a.id !== activeListId) return  1;
            // Both non-active (or both active, though only one can be):
            // sort alphabetically by name, case-insensitive.
            const an = (a.name || '').toLowerCase();
            const bn = (b.name || '').toLowerCase();
            return an < bn ? -1 : an > bn ? 1 : 0;
        });
    }

    function hhValidateListName(name, excludeId) {
        const trimmed = (name || '').trim();
        if (!trimmed) return 'Please enter a name.';
        if (trimmed.length > 80) return 'Name is too long (max 80 characters).';
        const all = getAllACLists();
        for (const l of all) {
            if (excludeId && l.id === excludeId) continue;
            if ((l.name || '').trim().toLowerCase() === trimmed.toLowerCase()) {
                return 'A list with this name already exists.';
            }
        }
        return null;
    }

    function renderHHListsView() {
        const collection = document.getElementById('hhListCollection');
        const empty      = document.getElementById('hhListsEmpty');
        const countEl    = document.getElementById('hhListsCount');
        if (!collection || !empty) return;

        const data = getACLists();
        const all  = Object.values(data.lists || {});
        const sorted = hhSortListsForDisplay(all, data.activeListId);

        if (countEl) {
            countEl.textContent = sorted.length === 0
                ? ''
                : (sorted.length === 1 ? '1 list' : sorted.length + ' lists');
        }

        if (sorted.length === 0) {
            empty.style.display = '';
            collection.innerHTML = '';
            collection.style.display = 'none';
            return;
        }
        empty.style.display = 'none';
        collection.style.display = '';

        collection.innerHTML = sorted.map(list => {
            const isActive = (list.id === data.activeListId);
            const itemCount = (list.items || []).length;
            const meta = [];
            meta.push(itemCount + (itemCount === 1 ? ' word' : ' words'));
            const updated = hhFormatDate(list.updatedAt || list.createdAt);
            if (updated) meta.push('updated ' + updated);

            return `
                <div class="hh-list-card${isActive ? ' is-active' : ''}" data-list-id="${hhEscape(list.id)}">
                    <div class="hh-list-info">
                        <div class="hh-list-name-row">
                            <span class="hh-list-name" title="${hhEscape(list.name)}">${hhEscape(list.name)}</span>
                            ${isActive ? '<span class="hh-list-active-tag">active</span>' : ''}
                        </div>
                        <div class="hh-list-meta">${hhEscape(meta.join(' · '))}</div>
                    </div>
                    <div class="hh-list-actions">
                        ${isActive
                            ? ''
                            : `<button class="hh-icon-btn" data-action="activate" title="Set as active">⭐</button>`
                        }
                        <button class="hh-icon-btn" data-action="rename" title="Rename">✏️</button>
                        <button class="hh-icon-btn is-danger" data-action="delete" title="Delete">🗑</button>
                    </div>
                </div>
            `;
        }).join('');
    }


    /* ============================================================
     * Modal: create / rename
     * ============================================================ */

    let _hhListNameMode    = 'create';
    let _hhListNameTargetId = null;

    function hhOpenNameModalForCreate() {
        _hhListNameMode    = 'create';
        _hhListNameTargetId = null;
        document.getElementById('hhListNameTitle').textContent  = 'New list';
        document.getElementById('hhListNameSubmit').textContent = 'Create';
        const inp = document.getElementById('hhListNameInput');
        inp.value = '';
        const hint = document.getElementById('hhListNameHint');
        hint.textContent = '';
        hint.classList.remove('is-error');
        const overlay = document.getElementById('hhListNameOverlay');
        overlay.classList.add('open');
        overlay.setAttribute('aria-hidden', 'false');
        setTimeout(() => { try { inp.focus(); } catch(_){} }, 30);
    }

    function hhOpenNameModalForRename(listId) {
        const data = getACLists();
        const list = data.lists[listId];
        if (!list) return;
        _hhListNameMode    = 'rename';
        _hhListNameTargetId = listId;
        document.getElementById('hhListNameTitle').textContent  = 'Rename list';
        document.getElementById('hhListNameSubmit').textContent = 'Save';
        const inp = document.getElementById('hhListNameInput');
        inp.value = list.name || '';
        const hint = document.getElementById('hhListNameHint');
        hint.textContent = '';
        hint.classList.remove('is-error');
        const overlay = document.getElementById('hhListNameOverlay');
        overlay.classList.add('open');
        overlay.setAttribute('aria-hidden', 'false');
        setTimeout(() => { try { inp.focus(); inp.select(); } catch(_){} }, 30);
    }

    function hhCloseNameModal() {
        const overlay = document.getElementById('hhListNameOverlay');
        if (!overlay) return;
        // BUG FIX (aria-hidden): blur focus first, then hide.
        const active = document.activeElement;
        if (active && overlay.contains(active) && typeof active.blur === 'function') {
            try { active.blur(); } catch (_) {}
        }
        overlay.classList.remove('open');
        overlay.setAttribute('aria-hidden', 'true');
    }

    function hhSubmitNameModal() {
        const inp   = document.getElementById('hhListNameInput');
        const hint  = document.getElementById('hhListNameHint');
        const name  = (inp.value || '').trim();
        const excludeId = (_hhListNameMode === 'rename') ? _hhListNameTargetId : null;
        const err = hhValidateListName(name, excludeId);
        if (err) {
            hint.textContent = err;
            hint.classList.add('is-error');
            inp.focus();
            return;
        }

        const data = getACLists();
        const nowISO = new Date().toISOString();

        if (_hhListNameMode === 'create') {
            const id = newListId();
            data.lists[id] = {
                id: id,
                name: name,
                createdAt: nowISO,
                updatedAt: nowISO,
                defaultLang: null,
                items: []
            };
            data.activeListId = id;
            data.lastUsedListId = id;
            saveACLists(data);
        } else if (_hhListNameMode === 'rename' && _hhListNameTargetId) {
            const list = data.lists[_hhListNameTargetId];
            if (!list) { hhCloseNameModal(); return; }
            list.name = name;
            list.updatedAt = nowISO;
            saveACLists(data);
        }

        hhCloseNameModal();
        renderHHListsView();
    }


    /* ============================================================
     * Modal: delete confirmation
     * ============================================================ */

    let _hhListDeleteTargetId = null;

    function hhOpenDeleteModal(listId) {
        const data = getACLists();
        const list = data.lists[listId];
        if (!list) return;
        _hhListDeleteTargetId = listId;
        const itemCount = (list.items || []).length;
        const wordsTxt = itemCount === 1 ? '1 word' : (itemCount + ' words');
        const hint = document.getElementById('hhListDeleteHint');
        hint.innerHTML = `Delete the list <b>${hhEscape(list.name)}</b> (${hhEscape(wordsTxt)})?<br>This cannot be undone.`;
        const overlay = document.getElementById('hhListDeleteOverlay');
        overlay.classList.add('open');
        overlay.setAttribute('aria-hidden', 'false');
    }

    function hhCloseDeleteModal() {
        _hhListDeleteTargetId = null;
        const overlay = document.getElementById('hhListDeleteOverlay');
        if (!overlay) return;
        // BUG FIX (aria-hidden): blur focus first.
        const active = document.activeElement;
        if (active && overlay.contains(active) && typeof active.blur === 'function') {
            try { active.blur(); } catch (_) {}
        }
        overlay.classList.remove('open');
        overlay.setAttribute('aria-hidden', 'true');
    }

    function hhConfirmDeleteList() {
        if (!_hhListDeleteTargetId) { hhCloseDeleteModal(); return; }
        const data = getACLists();
        const wasActive   = (data.activeListId   === _hhListDeleteTargetId);
        const wasLastUsed = (data.lastUsedListId === _hhListDeleteTargetId);
        delete data.lists[_hhListDeleteTargetId];
        if (wasActive) {
            const remaining = Object.values(data.lists);
            if (remaining.length === 0) {
                data.activeListId = null;
            } else {
                remaining.sort((a, b) => {
                    const au = a.updatedAt || a.createdAt || '';
                    const bu = b.updatedAt || b.createdAt || '';
                    return au < bu ? 1 : -1;
                });
                data.activeListId = remaining[0].id;
            }
        }
        if (wasLastUsed) {
            data.lastUsedListId = data.activeListId;
        }
        saveACLists(data);
        hhCloseDeleteModal();
        renderHHListsView();
    }


    /* ============================================================
     * Set active
     * ============================================================ */

    function hhSetActiveList(listId) {
        const data = getACLists();
        if (!data.lists[listId]) return;
        data.activeListId = listId;
        data.lastUsedListId = listId;
        saveACLists(data);
        renderHHListsView();
    }


    /* ============================================================
     * Step 3 — Per-list contents view
     *
     * Open a single list to see/edit/delete its words. The list row
     * cards from Step 2 gain click handlers (already delegated in
     * Step 2's wiring, will add in wireACHunter). Clicking a card
     * transitions from lists-view to contents-view.
     * ============================================================ */

    // Track which list is currently open in the contents view.
    let _openListId = null;

    function openListContents(listId) {
        const data = getACLists();
        const list = data.lists[listId];
        if (!list) return;

        _openListId = listId;

        // Hide lists view, show contents view.
        const listsView    = document.getElementById('hhListsView');
        const contentsView = document.getElementById('hhContentsView');
        if (listsView)    listsView.style.display = 'none';
        if (contentsView) contentsView.style.display = '';

        renderListContents(listId);
    }

    function closeListContents() {
        _openListId = null;

        // Show lists view, hide contents view.
        const listsView    = document.getElementById('hhListsView');
        const contentsView = document.getElementById('hhContentsView');
        if (listsView)    listsView.style.display = '';
        if (contentsView) contentsView.style.display = 'none';


        // Re-render lists view in case the word count changed.
        renderHHListsView();
    }

    // Language code-to-name map (from AC's langMap).
    const LANG_MAP = {
        'EN': 'English',   'ES': 'Spanish',   'FR': 'French',    'DE': 'German',
        'AR': 'Arabic',    'BN': 'Bengali',   'NL': 'Dutch',     'FA': 'Farsi',
        'HI': 'Hindi',     'ID': 'Indonesian','IT': 'Italian',   'JA': 'Japanese',
        'KO': 'Korean',    'PT': 'Portuguese','RU': 'Russian',   'TH': 'Thai',
        'TL': 'Tagalog',   'TR': 'Turkish',   'UK': 'Ukrainian', 'UR': 'Urdu',
        'VI': 'Vietnamese'
    };

    function renderListContents(listId) {
        const data = getACLists();
        const list = data.lists[listId];
        if (!list) return;

        // Update header: list name + word count.
        const titleEl = document.getElementById('hhContentsTitle');
        const countEl = document.getElementById('hhContentsCount');
        if (titleEl) titleEl.textContent = list.name || 'Untitled';
        if (countEl) {
            const n = (list.items || []).length;
            countEl.textContent = n === 0 ? '' : (n === 1 ? '1 word' : n + ' words');
        }

        const collection = document.getElementById('hhWordsCollection');
        const empty      = document.getElementById('hhWordsEmpty');
        if (!collection || !empty) return;

        const items = list.items || [];

        // Empty state vs populated rows.
        if (items.length === 0) {
            empty.style.display = '';
            collection.innerHTML = '';
            collection.style.display = 'none';
            return;
        }
        empty.style.display = 'none';
        collection.style.display = '';

        collection.innerHTML = items.map((item, idx) => {
            const zh = hhEscape(item.zh || '');
            const py = hhEscape(item.py || '');
            const tr = hhEscape(item.tr || '');
            const lang = item.lang || 'EN';
            const langName = LANG_MAP[lang] || lang;

            // Build metadata line: pinyin + translation. If pinyin is empty,
            // just show translation. If both empty, show placeholder.
            let meta = '';
            if (py && tr) meta = py + ' · ' + tr;
            else if (py)  meta = py;
            else if (tr)  meta = tr;
            else          meta = '(no translation)';

            return `
                <div class="hh-word-row" data-word-idx="${idx}">
                    <div class="hh-word-info">
                        <div class="hh-word-zh">${zh || '(no Chinese)'}</div>
                        <div class="hh-word-meta">${hhEscape(meta)}</div>
                    </div>
                    <div class="hh-word-lang-badge">${hhEscape(langName)}</div>
                    <div class="hh-word-actions">
                        <button class="hh-icon-btn" data-action="edit" title="Edit">✏️</button>
                        <button class="hh-icon-btn is-danger" data-action="delete" title="Delete">🗑</button>
                    </div>
                </div>
            `;
        }).join('');
    }


    /* ============================================================
     * Modal: add / edit word
     * ============================================================ */

    let _hhWordEditMode  = 'add';     // 'add' | 'edit'
    let _hhWordEditIdx   = null;      // array index when editing

    function hhOpenWordEditModalForAdd() {
        if (!_openListId) return;
        _hhWordEditMode = 'add';
        _hhWordEditIdx  = null;

        document.getElementById('hhWordEditTitle').textContent  = 'Add word';
        document.getElementById('hhWordEditSubmit').textContent = 'Add';

        document.getElementById('hhWordZhInput').value     = '';
        document.getElementById('hhWordPyInput').value     = '';
        document.getElementById('hhWordTrInput').value     = '';
        document.getElementById('hhWordLangSelect').value  = 'EN';

        const hint = document.getElementById('hhWordEditHint');
        hint.textContent = '';
        hint.classList.remove('is-error');

        const overlay = document.getElementById('hhWordEditOverlay');
        overlay.classList.add('open');
        overlay.setAttribute('aria-hidden', 'false');

        setTimeout(() => {
            try { document.getElementById('hhWordZhInput').focus(); } catch(_){}
        }, 30);
    }

    function hhOpenWordEditModalForEdit(idx) {
        if (!_openListId) return;
        const data = getACLists();
        const list = data.lists[_openListId];
        if (!list || !list.items || !list.items[idx]) return;

        _hhWordEditMode = 'edit';
        _hhWordEditIdx  = idx;

        const item = list.items[idx];

        document.getElementById('hhWordEditTitle').textContent  = 'Edit word';
        document.getElementById('hhWordEditSubmit').textContent = 'Save';

        document.getElementById('hhWordZhInput').value     = item.zh   || '';
        document.getElementById('hhWordPyInput').value     = item.py   || '';
        document.getElementById('hhWordTrInput').value     = item.tr   || '';
        document.getElementById('hhWordLangSelect').value  = item.lang || 'EN';

        const hint = document.getElementById('hhWordEditHint');
        hint.textContent = '';
        hint.classList.remove('is-error');

        const overlay = document.getElementById('hhWordEditOverlay');
        overlay.classList.add('open');
        overlay.setAttribute('aria-hidden', 'false');

        setTimeout(() => {
            try {
                const inp = document.getElementById('hhWordZhInput');
                inp.focus();
                inp.select();
            } catch(_){}
        }, 30);
    }

    function hhCloseWordEditModal() {
        const overlay = document.getElementById('hhWordEditOverlay');
        if (!overlay) return;
        // Blur focus before hiding (aria-hidden fix).
        const active = document.activeElement;
        if (active && overlay.contains(active) && typeof active.blur === 'function') {
            try { active.blur(); } catch (_) {}
        }
        overlay.classList.remove('open');
        overlay.setAttribute('aria-hidden', 'true');
    }

    function hhSubmitWordEditModal() {
        if (!_openListId) { hhCloseWordEditModal(); return; }

        const zh   = (document.getElementById('hhWordZhInput').value     || '').trim();
        const py   = (document.getElementById('hhWordPyInput').value     || '').trim();
        const tr   = (document.getElementById('hhWordTrInput').value     || '').trim();
        const lang = document.getElementById('hhWordLangSelect').value   || 'EN';
        const hint = document.getElementById('hhWordEditHint');

        // Validation: zh and tr are required.
        if (!zh) {
            hint.textContent = 'Chinese text is required.';
            hint.classList.add('is-error');
            document.getElementById('hhWordZhInput').focus();
            return;
        }
        if (!tr) {
            hint.textContent = 'Translation is required.';
            hint.classList.add('is-error');
            document.getElementById('hhWordTrInput').focus();
            return;
        }

        const data = getACLists();
        const list = data.lists[_openListId];
        if (!list) { hhCloseWordEditModal(); return; }

        const nowISO = new Date().toISOString();

        if (_hhWordEditMode === 'add') {
            // Append to items array.
            if (!list.items) list.items = [];
            list.items.push({ zh, py, tr, lang });
            list.updatedAt = nowISO;
            saveACLists(data);
        } else if (_hhWordEditMode === 'edit' && _hhWordEditIdx != null) {
            // Overwrite existing item.
            if (!list.items || !list.items[_hhWordEditIdx]) {
                hhCloseWordEditModal();
                return;
            }
            list.items[_hhWordEditIdx] = { zh, py, tr, lang };
            list.updatedAt = nowISO;
            saveACLists(data);
        }

        hhCloseWordEditModal();
        renderListContents(_openListId);
    }


    /* ============================================================
     * Modal: delete word confirmation
     * ============================================================ */

    let _hhWordDeleteIdx = null;

    function hhOpenWordDeleteModal(idx) {
        if (!_openListId) return;
        const data = getACLists();
        const list = data.lists[_openListId];
        if (!list || !list.items || !list.items[idx]) return;

        _hhWordDeleteIdx = idx;

        const item = list.items[idx];
        const zh = hhEscape(item.zh || '(no Chinese)');
        const hint = document.getElementById('hhWordDeleteHint');
        hint.innerHTML = `Delete <b>${zh}</b>?<br>This cannot be undone.`;

        const overlay = document.getElementById('hhWordDeleteOverlay');
        overlay.classList.add('open');
        overlay.setAttribute('aria-hidden', 'false');
    }

    function hhCloseWordDeleteModal() {
        _hhWordDeleteIdx = null;
        const overlay = document.getElementById('hhWordDeleteOverlay');
        if (!overlay) return;
        // Blur focus before hiding.
        const active = document.activeElement;
        if (active && overlay.contains(active) && typeof active.blur === 'function') {
            try { active.blur(); } catch (_) {}
        }
        overlay.classList.remove('open');
        overlay.setAttribute('aria-hidden', 'true');
    }

    function hhConfirmWordDelete() {
        if (!_openListId || _hhWordDeleteIdx == null) {
            hhCloseWordDeleteModal();
            return;
        }

        const data = getACLists();
        const list = data.lists[_openListId];
        if (!list || !list.items) {
            hhCloseWordDeleteModal();
            return;
        }

        // Remove the item at index.
        list.items.splice(_hhWordDeleteIdx, 1);
        list.updatedAt = new Date().toISOString();
        saveACLists(data);

        hhCloseWordDeleteModal();
        renderListContents(_openListId);
    }


    /* ============================================================
     * Wiring
     * ============================================================ */

    function wireACHunter() {
        // Mount markup if not yet mounted.
        if (!mountHunterMarkup()) return;

        // 🎯 entry badge
        const badge = document.getElementById('hunterEntryBadge');
        if (badge) {
            badge.addEventListener('click', (e) => {
                e.stopPropagation();
                // Snapshot the AC state NOW, before opening the panel (which
                // will mark the 🎯 badge active and potentially clear other
                // badges' active state). This ensures we capture which section
                // badge was active before the transition.
                snapshotACState();
                openHunterPanel();
            });
        }

        // Panel back button — context-aware:
        //   • If we're in a list's contents view, go back to lists view (don't close panel)
        //   • If we're in lists view, close the panel
        const back = document.getElementById('hunterPanelBack');
        if (back) {
            back.addEventListener('click', () => {
                if (_openListId) {
                    // We're in contents view — go back to lists view, stay in panel.
                    closeListContents();
                } else {
                    // We're in lists view — close the panel entirely.
                    closeHunterPanel();
                }
            });
        }

        // Toolbar + empty-state create buttons
        const newBtn   = document.getElementById('hhNewListBtn');
        const emptyBtn = document.getElementById('hhEmptyCreateBtn');
        if (newBtn)   newBtn.addEventListener('click', hhOpenNameModalForCreate);
        if (emptyBtn) emptyBtn.addEventListener('click', hhOpenNameModalForCreate);

        // Per-row actions via event delegation
        const collection = document.getElementById('hhListCollection');
        if (collection) {
            collection.addEventListener('click', (e) => {
                // Check if a button (action button) was clicked.
                const btn = e.target.closest('button[data-action]');
                if (btn) {
                    const card = btn.closest('.hh-list-card');
                    if (!card) return;
                    const listId = card.getAttribute('data-list-id');
                    if (!listId) return;
                    const action = btn.getAttribute('data-action');
                    if      (action === 'activate') hhSetActiveList(listId);
                    else if (action === 'rename')   hhOpenNameModalForRename(listId);
                    else if (action === 'delete')   hhOpenDeleteModal(listId);
                    return; // Stop here — don't also fire card-click.
                }

                // If no button was clicked, check if the card itself was clicked.
                const card = e.target.closest('.hh-list-card');
                if (card) {
                    const listId = card.getAttribute('data-list-id');
                    if (listId) openListContents(listId);
                }
            });
        }

        // Contents view: back button, add word button, word row actions.
        const contentsBackBtn = document.getElementById('hhContentsBackBtn');
        if (contentsBackBtn) {
            contentsBackBtn.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent bubbling to panel back button
                closeListContents();
            });
        }

        const importBtn = document.getElementById('hhImportBtn');
        if (importBtn) {
            importBtn.addEventListener('click', hhOpenImportModal);
        }

        const addWordBtn = document.getElementById('hhAddWordBtn');
        if (addWordBtn) {
            addWordBtn.addEventListener('click', hhOpenWordEditModalForAdd);
        }

        const wordsCollection = document.getElementById('hhWordsCollection');
        if (wordsCollection) {
            wordsCollection.addEventListener('click', (e) => {
                const btn = e.target.closest('button[data-action]');
                if (!btn) return;
                const row = btn.closest('.hh-word-row');
                if (!row) return;
                const idx = parseInt(row.getAttribute('data-word-idx'), 10);
                if (isNaN(idx)) return;
                const action = btn.getAttribute('data-action');
                if      (action === 'edit')   hhOpenWordEditModalForEdit(idx);
                else if (action === 'delete') hhOpenWordDeleteModal(idx);
            });
        }

        // Name modal
        const nameOverlay = document.getElementById('hhListNameOverlay');
        const nameClose   = document.getElementById('hhListNameClose');
        const nameCancel  = document.getElementById('hhListNameCancel');
        const nameSubmit  = document.getElementById('hhListNameSubmit');
        const nameInput   = document.getElementById('hhListNameInput');
        if (nameClose)  nameClose.addEventListener('click', hhCloseNameModal);
        if (nameCancel) nameCancel.addEventListener('click', hhCloseNameModal);
        if (nameSubmit) nameSubmit.addEventListener('click', hhSubmitNameModal);
        if (nameOverlay) {
            nameOverlay.addEventListener('click', (e) => {
                if (e.target === nameOverlay) hhCloseNameModal();
            });
        }
        if (nameInput) {
            nameInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    hhSubmitNameModal();
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    hhCloseNameModal();
                }
            });
            nameInput.addEventListener('input', () => {
                const hint = document.getElementById('hhListNameHint');
                if (hint) {
                    hint.textContent = '';
                    hint.classList.remove('is-error');
                }
            });
        }

        // Delete modal
        const delOverlay = document.getElementById('hhListDeleteOverlay');
        const delClose   = document.getElementById('hhListDeleteClose');
        const delCancel  = document.getElementById('hhListDeleteCancel');
        const delSubmit  = document.getElementById('hhListDeleteSubmit');
        if (delClose)  delClose.addEventListener('click', hhCloseDeleteModal);
        if (delCancel) delCancel.addEventListener('click', hhCloseDeleteModal);
        if (delSubmit) delSubmit.addEventListener('click', hhConfirmDeleteList);
        if (delOverlay) {
            delOverlay.addEventListener('click', (e) => {
                if (e.target === delOverlay) hhCloseDeleteModal();
            });
        }

        // Word edit modal (Step 3)
        const wordEditOverlay = document.getElementById('hhWordEditOverlay');
        const wordEditClose   = document.getElementById('hhWordEditClose');
        const wordEditCancel  = document.getElementById('hhWordEditCancel');
        const wordEditSubmit  = document.getElementById('hhWordEditSubmit');
        const wordZhInput     = document.getElementById('hhWordZhInput');

        if (wordEditClose)  wordEditClose.addEventListener('click', hhCloseWordEditModal);
        if (wordEditCancel) wordEditCancel.addEventListener('click', hhCloseWordEditModal);
        if (wordEditSubmit) wordEditSubmit.addEventListener('click', hhSubmitWordEditModal);
        if (wordEditOverlay) {
            wordEditOverlay.addEventListener('click', (e) => {
                if (e.target === wordEditOverlay) hhCloseWordEditModal();
            });
        }
        // Enter in any input submits the form.
        [wordZhInput,
         document.getElementById('hhWordPyInput'),
         document.getElementById('hhWordTrInput')
        ].forEach(inp => {
            if (!inp) return;
            inp.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    hhSubmitWordEditModal();
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    hhCloseWordEditModal();
                }
            });
            // Clear inline error as user types.
            inp.addEventListener('input', () => {
                const hint = document.getElementById('hhWordEditHint');
                if (hint) {
                    hint.textContent = '';
                    hint.classList.remove('is-error');
                }
            });
        });

        // Word delete modal (Step 3)
        const wordDelOverlay = document.getElementById('hhWordDeleteOverlay');
        const wordDelClose   = document.getElementById('hhWordDeleteClose');
        const wordDelCancel  = document.getElementById('hhWordDeleteCancel');
        const wordDelSubmit  = document.getElementById('hhWordDeleteSubmit');
        if (wordDelClose)  wordDelClose.addEventListener('click', hhCloseWordDeleteModal);
        if (wordDelCancel) wordDelCancel.addEventListener('click', hhCloseWordDeleteModal);
        if (wordDelSubmit) wordDelSubmit.addEventListener('click', hhConfirmWordDelete);
        if (wordDelOverlay) {
            wordDelOverlay.addEventListener('click', (e) => {
                if (e.target === wordDelOverlay) hhCloseWordDeleteModal();
            });
        }

        // Import modal (Step 5)
        const importOverlay = document.getElementById('hhImportOverlay');
        const importClose   = document.getElementById('hhImportClose');
        const importCancel  = document.getElementById('hhImportCancel');
        const importSubmit  = document.getElementById('hhImportSubmit');
        const importTextarea = document.getElementById('hhImportTextarea');

        if (importClose)  importClose.addEventListener('click', hhCloseImportModal);
        if (importCancel) importCancel.addEventListener('click', hhCloseImportModal);
        if (importSubmit) importSubmit.addEventListener('click', hhSubmitImport);
        if (importOverlay) {
            importOverlay.addEventListener('click', (e) => {
                if (e.target === importOverlay) hhCloseImportModal();
            });
        }
        if (importTextarea) {
            // Auto-parse on input (debounced would be better for huge pastes, but
            // we'll keep it simple for now — parse runs fast enough).
            importTextarea.addEventListener('input', hhParseImportData);
        }

        // ESC handling — all modals first (order matters: newest modals first),
        // then panel. Step 5 import modal goes before Step 3 word modals.
        document.addEventListener('keydown', (e) => {
            if (e.key !== 'Escape') return;
            if (importOverlay   && importOverlay.classList.contains('open'))   { hhCloseImportModal();     e.stopPropagation(); return; }
            if (wordDelOverlay  && wordDelOverlay.classList.contains('open'))  { hhCloseWordDeleteModal(); e.stopPropagation(); return; }
            if (wordEditOverlay && wordEditOverlay.classList.contains('open')) { hhCloseWordEditModal();   e.stopPropagation(); return; }
            if (delOverlay      && delOverlay.classList.contains('open'))      { hhCloseDeleteModal();     e.stopPropagation(); return; }
            if (nameOverlay     && nameOverlay.classList.contains('open'))     { hhCloseNameModal();       e.stopPropagation(); return; }
            const panel = document.getElementById('hunterPanel');
            if (panel && panel.classList.contains('open')) {
                // If contents view is open, ESC closes it (back to lists).
                // If lists view is open, ESC closes the panel (back to AC).
                const contentsView = document.getElementById('hhContentsView');
                if (contentsView && contentsView.style.display !== 'none') {
                    closeListContents();
                    e.stopPropagation();
                } else {
                    closeHunterPanel();
                    e.stopPropagation();
                }
            }
        }, true); // capture so we beat any other ESC handlers
    }

    // Run wiring once the DOM is ready. The script tag is `defer`, so
    // DOMContentLoaded should already have fired by the time we reach
    // here in most cases — handle both possibilities defensively.
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', wireACHunter);
    } else {
        wireACHunter();
    }


    /* ============================================================
     * Step 5 — Paste-import
     *
     * User pastes tab-delimited or #-delimited rows into a textarea.
     * We detect delimiter, parse columns, show preview (first 10 rows),
     * and import all on confirm.
     *
     * Column formats:
     *   2 cols: sourceWord, translation → { zh: col1, py: "", tr: col2, lang: "" }
     *   3 cols: zh, py, tr              → { zh: col1, py: col2, tr: col3, lang: userPicked }
     *   4 cols: zh, py, tr, lang        → { zh: col1, py: col2, tr: col3, lang: col4 }
     * ============================================================ */

    let _hhImportParsedRows = [];  // Holds all parsed rows for final import

    function hhOpenImportModal() {
        if (!_openListId) return;

        // Get current AC language to pre-select in the lang picker
        let currentACLang = 'EN';
        try {
            const acVars = JSON.parse(localStorage.getItem('ACVariables') || '{}');
            currentACLang = (acVars.language || 'EN').toUpperCase();
        } catch (_) {}

        document.getElementById('hhImportTextarea').value = '';
        document.getElementById('hhImportPreviewSection').style.display = 'none';
        document.getElementById('hhImportLangPicker').style.display = 'none';
        document.getElementById('hhImportSubmit').disabled = true;
        document.getElementById('hhImportLangSelect').value = currentACLang;
        document.getElementById('hhImportHint').textContent = '';
        document.getElementById('hhImportHint').classList.remove('is-error');

        _hhImportParsedRows = [];

        const overlay = document.getElementById('hhImportOverlay');
        overlay.classList.add('open');
        overlay.setAttribute('aria-hidden', 'false');

        setTimeout(() => {
            try { document.getElementById('hhImportTextarea').focus(); } catch (_) {}
        }, 30);
    }

    function hhCloseImportModal() {
        const overlay = document.getElementById('hhImportOverlay');
        if (!overlay) return;
        const active = document.activeElement;
        if (active && overlay.contains(active) && typeof active.blur === 'function') {
            try { active.blur(); } catch (_) {}
        }
        overlay.classList.remove('open');
        overlay.setAttribute('aria-hidden', 'true');
        _hhImportParsedRows = [];
    }

    function hhParseImportData() {
        const text = (document.getElementById('hhImportTextarea').value || '').trim();
        if (!text) {
            document.getElementById('hhImportPreviewSection').style.display = 'none';
            document.getElementById('hhImportSubmit').disabled = true;
            return;
        }

        const hint = document.getElementById('hhImportHint');
        hint.textContent = '';
        hint.classList.remove('is-error');

        // Detect delimiter: tab or #. Tab takes precedence.
        const lines = text.split('\n').filter(l => l.trim());
        if (lines.length === 0) {
            document.getElementById('hhImportPreviewSection').style.display = 'none';
            document.getElementById('hhImportSubmit').disabled = true;
            return;
        }

        let delimiter = '\t';
        if (!lines[0].includes('\t') && lines[0].includes('#')) {
            delimiter = '#';
        }

        // Parse all rows
        const rows = [];
        for (const line of lines) {
            const cols = line.split(delimiter).map(c => c.trim()).filter(c => c);
            if (cols.length < 2 || cols.length > 4) continue; // Skip malformed
            rows.push(cols);
        }

        if (rows.length === 0) {
            hint.textContent = 'No valid rows found. Use tab or # as delimiter.';
            hint.classList.add('is-error');
            document.getElementById('hhImportPreviewSection').style.display = 'none';
            document.getElementById('hhImportSubmit').disabled = true;
            return;
        }

        // Detect column count from first row (assume all rows have same count)
        const colCount = rows[0].length;
        const allSameCount = rows.every(r => r.length === colCount);
        if (!allSameCount) {
            hint.textContent = 'Rows have inconsistent column counts. Please fix and try again.';
            hint.classList.add('is-error');
            document.getElementById('hhImportPreviewSection').style.display = 'none';
            document.getElementById('hhImportSubmit').disabled = true;
            return;
        }

        // Format label for preview
        let formatLabel = '';
        let needsLangPicker = false;
        if (colCount === 2) {
            formatLabel = '2 columns (word, translation — non-Chinese pair)';
        } else if (colCount === 3) {
            formatLabel = '3 columns (Chinese, pinyin, translation)';
            needsLangPicker = true;
        } else if (colCount === 4) {
            formatLabel = '4 columns (Chinese, pinyin, translation, language)';
        }

        // Build preview: first 10 rows
        const previewRows = rows.slice(0, 10);
        const previewHTML = `
            <div style="font-size:0.85rem;color:var(--text-secondary,#888);margin-bottom:0.5rem;">
                Format: ${hhEscape(formatLabel)}<br>
                Delimiter: ${delimiter === '\t' ? 'Tab' : '#'}
            </div>
            <table class="hh-import-table">
                <tbody>
                    ${previewRows.map(cols => `
                        <tr>${cols.map(c => `<td>${hhEscape(c)}</td>`).join('')}</tr>
                    `).join('')}
                </tbody>
            </table>
        `;

        document.getElementById('hhImportPreview').innerHTML = previewHTML;
        const summary = rows.length > 10
            ? `(showing first 10 of ${rows.length} rows)`
            : `(${rows.length} row${rows.length === 1 ? '' : 's'})`;
        document.getElementById('hhImportPreviewSummary').textContent = summary;
        document.getElementById('hhImportPreviewSection').style.display = '';

        // Show language picker for 3-column paste
        const langPicker = document.getElementById('hhImportLangPicker');
        if (needsLangPicker) {
            langPicker.style.display = '';
        } else {
            langPicker.style.display = 'none';
        }

        // Store parsed rows for import
        _hhImportParsedRows = rows;

        // Enable import button
        document.getElementById('hhImportSubmit').disabled = false;
    }

    function hhSubmitImport() {
        if (!_openListId || _hhImportParsedRows.length === 0) {
            hhCloseImportModal();
            return;
        }

        const data = getACLists();
        const list = data.lists[_openListId];
        if (!list) {
            hhCloseImportModal();
            return;
        }

        const colCount = _hhImportParsedRows[0].length;
        let lang = '';

        // For 3-column paste, get user-selected language
        if (colCount === 3) {
            lang = document.getElementById('hhImportLangSelect').value || '';
        }

        if (!list.items) list.items = [];
        let added = 0;

        for (const cols of _hhImportParsedRows) {
            let zh, py, tr, itemLang;

            if (colCount === 2) {
                // 2 cols: non-Chinese pair
                zh = cols[0];
                py = '';
                tr = cols[1];
                itemLang = '';
            } else if (colCount === 3) {
                // 3 cols: Chinese + pinyin + translation
                zh = cols[0];
                py = cols[1];
                tr = cols[2];
                itemLang = lang;  // from picker
            } else if (colCount === 4) {
                // 4 cols: all specified
                zh = cols[0];
                py = cols[1];
                tr = cols[2];
                itemLang = (cols[3] || '').toUpperCase();
            }

            // Skip if zh or tr is empty
            if (!zh || !tr) continue;

            // Duplicate check: same zh + lang (empty lang matches empty)
            const exists = list.items.some(item =>
                (item.zh || '').trim() === zh.trim() &&
                ((item.lang || '').toUpperCase() === (itemLang || '').toUpperCase())
            );

            if (exists) continue; // Skip duplicate

            list.items.push({ zh, py, tr, lang: itemLang });
            added++;
        }

        list.updatedAt = new Date().toISOString();
        saveACLists(data);

        hhCloseImportModal();
        renderListContents(_openListId);
    }


    /* ============================================================
     * Step 4 — Export from bubble game
     *
     * Called by ACBubbles.js when the user taps Export. Adds the
     * current bubble word to the active list (or reports duplicate).
     * ============================================================ */

    function addWordToActiveList(zh, py, tr, lang) {
        // zh and tr are required. py is optional. lang defaults to EN.
        zh   = (zh   || '').trim();
        tr   = (tr   || '').trim();
        py   = (py   || '').trim();
        lang = (lang || 'EN').toUpperCase();

        if (!zh || !tr) {
            return { added: false, reason: 'missing_data', listName: null };
        }

        const data = getACLists();
        if (!data.activeListId) {
            return { added: false, reason: 'no_active_list', listName: null };
        }

        const list = data.lists[data.activeListId];
        if (!list) {
            return { added: false, reason: 'list_not_found', listName: null };
        }

        // Duplicate detection: same zh + lang combination.
        // (pinyin and translation can vary; we only care about the
        // Chinese text in the specific language context.)
        if (!list.items) list.items = [];
        const exists = list.items.some(item =>
            (item.zh || '').trim() === zh &&
            ((item.lang || 'EN').toUpperCase() === lang)
        );

        if (exists) {
            return { added: false, reason: 'duplicate', listName: list.name };
        }

        // Add the word.
        list.items.push({ zh, py, tr, lang });
        list.updatedAt = new Date().toISOString();
        saveACLists(data);

        return { added: true, reason: 'success', listName: list.name };
    }


    /* ============================================================
     * Public API
     *
     * Exposed on `window` for use by other scripts (e.g. AC bubble
     * game's Export button in Step 4) and for console-based debug.
     * ============================================================ */

    window.AC_LISTS_KEY      = AC_LISTS_KEY;
    window.getACLists        = getACLists;
    window.saveACLists       = saveACLists;
    window.defaultACLists    = defaultACLists;
    window.newListId         = newListId;
    window.getActiveACList   = getActiveACList;
    window.getAllACLists     = getAllACLists;
    window.openHunterPanel   = openHunterPanel;
    window.closeHunterPanel  = closeHunterPanel;
    window.renderHHListsView = renderHHListsView;
    window.hhSetActiveList   = hhSetActiveList;
    window.addWordToActiveList = addWordToActiveList;
})();