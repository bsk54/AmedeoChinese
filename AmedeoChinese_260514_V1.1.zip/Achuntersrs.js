/**
 * ACHunterSRS.js - AC Hunter SRS System (Phase 2)
 * Step 0: Visual shell - entry screen with layout matching Hanzi Hunter
 */

(function() {
  'use strict';
  
  // ========== GLOBAL STATE ==========
  let currentListId = null;
  let currentPracticeWords = []; // Store words from last practice session
  let srsSettings = {
    levelMath: 1,        // 1=A, 2=B, 3=C, 4=D
    rangeMin: 1,
    rangeMax: 100,
    sentenceSpeed: 1.0,
    activeTrackByList: {}  // Track mode per list: { [listId]: 'primary' | 'hard' }
  };
  
  // ========== ROUND SYSTEM STATE (3-Round Testing) ==========
  let sessionRound = 1;                 // 1 | 2 | 3
  let round1Queue = [];                 // [{ index, word, srs }] initial pass
  let round2Set = new Set();            // Set of indices that were wrong in Round 1
  let round2Order = [];                 // Fixed order for R2 (kept for R3)
  let round2State = new Map();          // index -> { neededOk: 2, prevOk: false }
  let round2Queue = [];                 // Working queue for R2 (indices)
  let round3Queue = [];                 // Working queue for R3 (indices)
  let sessionFirstOutcome = {};         // index -> 'ok' | 'again' (first attempt only)
  let totalPlanned = 0;                 // Total items in session
  let seenCount = 0;                    // Items seen at least once
  let correctCount = 0;                 // Items cleared
  let current = null;                   // Current item being tested
  
  // ========== STORAGE KEYS ==========
  const STORAGE_KEYS = {
    AC_LISTS: 'ACLists',
    SETTINGS: 'ACHunterSRS_Settings',  // Separate from main AC settings
    SRS_PREFIX: 'ACHunter_SRS_',
    HARD_PREFIX: 'ACHunter_HardTrack_',
    PRACTICE: 'ACHunter_Practice'
  };
  
  // ========== CONSTANTS ==========
  const MAX_LEVEL = 5;
  const MS_PER_DAY = 86400000;
  
  // ========== HARD TRACK ROUTING ==========
  
  // Get active track mode for current list ('primary' or 'hard')
  function getActiveTrack() {
    if (!currentListId) return 'primary';
    const mode = srsSettings.activeTrackByList[currentListId];
    // Fallback to primary if no hard track exists
    if (mode === 'hard' && !hasHardTrack(currentListId)) {
      return 'primary';
    }
    return mode || 'primary';
  }
  
  // Set active track mode for current list
  function setActiveTrack(mode) {
    if (!currentListId) return;
    if (mode === 'hard' && !hasHardTrack(currentListId)) {
      showToast('No Hard Track exists for this list');
      return;
    }
    srsSettings.activeTrackByList[currentListId] = mode;
    saveSRSSettings();
    updateTrackIndicator();
    updateLoadedInfo();
    updateDueCount();
    showToast(`Switched to ${mode === 'hard' ? 'Hard' : 'Primary'} Track`);
  }
  
  // Check if hard track exists for a list
  function hasHardTrack(listId) {
    const hardTrackData = loadHardTrackData(listId || currentListId);
    return hardTrackData !== null;
  }
  
  // Get active items (routes to primary or hard track)
  function getActiveItemsList() {
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    if (!list || !list.items) return [];
    
    const track = getActiveTrack();
    
    if (track === 'hard') {
      const hardTrackData = loadHardTrackData(currentListId);
      if (hardTrackData && hardTrackData.order) {
        // Map indices back to actual words
        return hardTrackData.order
          .filter(idx => idx >= 0 && idx < list.items.length)
          .map(idx => list.items[idx]);
      }
    }
    
    // Default: primary track
    return list.items;
  }
  
  // Get active SRS data (routes to primary or hard track)
  function getActiveSRSData() {
    const track = getActiveTrack();
    
    if (track === 'hard') {
      const hardTrackData = loadHardTrackData(currentListId);
      return hardTrackData || { items: [] };
    }
    
    return loadSRSData(currentListId);
  }
  
  // Save active SRS data
  function saveActiveSRSData(srsData) {
    const track = getActiveTrack();
    
    if (track === 'hard') {
      const key = `${STORAGE_KEYS.HARD_PREFIX}${currentListId}`;
      try {
        localStorage.setItem(key, JSON.stringify(srsData));
      } catch (e) {
        console.error('Failed to save hard track SRS data:', e);
      }
    } else {
      const key = `${STORAGE_KEYS.SRS_PREFIX}${currentListId}`;
      try {
        localStorage.setItem(key, JSON.stringify(srsData));
      } catch (e) {
        console.error('Failed to save SRS data:', e);
      }
    }
  }
  
  // Update track indicator in UI
  function updateTrackIndicator() {
    const indicator = document.getElementById('ac-srs-track-indicator');
    if (!indicator) return;
    
    const track = getActiveTrack();
    indicator.textContent = track === 'hard' ? 'Hard Track' : 'Primary';
    indicator.className = 'ac-srs-track-indicator ' + (track === 'hard' ? 'ac-srs-track-hard' : 'ac-srs-track-primary');
  }
  
  // Toggle between primary and hard track
  function toggleTrack() {
    const current = getActiveTrack();
    const next = current === 'primary' ? 'hard' : 'primary';
    setActiveTrack(next);
  }
  
  // Save SRS settings
  function saveSRSSettings() {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(srsSettings));
    } catch (e) {
      console.error('Failed to save SRS settings:', e);
    }
  }
  
  // ========== INITIALIZATION ==========
  window.ACHunterSRS = {
    init: initSRS,
    open: openSRS,
    close: closeSRS,
    cleanupDemoLists: cleanupDemoLists,
    getDueItems: getDueItems,
    reviewItem: reviewItem,
    getActiveListName: getActiveListName,
    getCurrentWords: getCurrentWords
  };
  
  // Get currently loaded words from active list
  function getCurrentWords() {
    // Return words from the last practice session (filtered and ready)
    if (currentPracticeWords && currentPracticeWords.length > 0) {
      console.log('[ACHunterSRS] Returning practice session words:', currentPracticeWords.length);
      return currentPracticeWords;
    }
    
    // Fallback: if no practice session, filter for Level 0 tested words
    if (!currentListId) {
      console.log('[ACHunterSRS] No list loaded and no practice session');
      return [];
    }
    
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    
    if (!list || !list.items) {
      console.log('[ACHunterSRS] No items in current list');
      return [];
    }
    
    // Load SRS data to check levels
    const srsData = loadSRSData(currentListId);
    const min = srsSettings.rangeMin || 1;
    const max = srsSettings.rangeMax || list.items.length;
    
    // Filter: Level 0 only + tested (has SRS data)
    const filtered = [];
    for (let i = min - 1; i < Math.min(max, list.items.length); i++) {
      const srsItem = srsData.items && srsData.items[i];
      // Include if: has SRS data AND level is 0
      if (srsItem && srsItem.level === 0) {
        filtered.push({
          zh: list.items[i].zh,
          py: list.items[i].py,
          tr: list.items[i].tr
        });
      }
    }
    
    console.log('[ACHunterSRS] Returning Level 0 tested words:', filtered.length);
    return filtered;
  }
  
  // Get active list name
  function getActiveListName() {
    const acLists = loadACLists();
    return acLists.active || null;
  }
  
  // Get due items for a list
  function getDueItems(listName) {
    const acLists = loadACLists();
    
    // Find list by name
    let listId = null;
    for (const id in acLists.lists) {
      if (acLists.lists[id].name === listName) {
        listId = id;
        break;
      }
    }
    
    if (!listId) {
      console.log('List not found:', listName);
      return [];
    }
    
    const list = acLists.lists[listId];
    const srsData = loadSRSData(listId);
    
    // Get today's date (midnight)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayTime = today.getTime();
    
    // Filter items that are due today or earlier
    const dueItems = [];
    
    list.items.forEach((word, index) => {
      const srsItem = srsData.items.find(item => item.word === word.zh);
      
      // If item has SRS data and due date
      if (srsItem && srsItem.dueDate) {
        const dueDate = new Date(srsItem.dueDate);
        dueDate.setHours(0, 0, 0, 0);
        
        if (dueDate.getTime() <= todayTime) {
          dueItems.push({
            zh: word.zh,
            py: word.py,
            tr: word.tr
          });
        }
      }
    });
    
    return dueItems;
  }
  
  // Review an item (update SRS state)
  function reviewItem(listName, zh, quality) {
    const acLists = loadACLists();
    
    // Find list by name
    let listId = null;
    for (const id in acLists.lists) {
      if (acLists.lists[id].name === listName) {
        listId = id;
        break;
      }
    }
    
    if (!listId) {
      console.log('List not found:', listName);
      return;
    }
    
    const srsData = loadSRSData(listId);
    
    // Find or create item
    let item = srsData.items.find(i => i.word === zh);
    if (!item) {
      item = {
        word: zh,
        level: 0,
        dueDate: new Date().toISOString(),
        reviewCount: 0,
        hardTrack: false
      };
      srsData.items.push(item);
    }
    
    // Update based on quality (SM-2 algorithm)
    item.reviewCount = (item.reviewCount || 0) + 1;
    
    if (quality >= 3) {
      // Good response
      item.level = Math.min(5, (item.level || 0) + 1);
    } else {
      // Bad response
      item.level = Math.max(0, (item.level || 0) - 1);
      item.hardTrack = true;
    }
    
    // Calculate next due date (simplified SM-2)
    const intervals = [1, 2, 4, 7, 14, 30]; // days
    const daysToAdd = intervals[item.level] || 1;
    
    const nextDue = new Date();
    nextDue.setDate(nextDue.getDate() + daysToAdd);
    item.dueDate = nextDue.toISOString();
    
    // Save SRS data
    try {
      const key = `${STORAGE_KEYS.SRS_PREFIX}${listId}`;
      localStorage.setItem(key, JSON.stringify(srsData));
    } catch (e) {
      console.error('Error saving SRS data:', e);
    }
  }
  
  // Cleanup function to remove demo lists created by ACHunterSRS_Demo.html
  function cleanupDemoLists() {
    const acLists = loadACLists();
    let removed = [];
    
    // List of known demo list names
    const demoNames = ['HSK 1', 'Italian Vocabulary', 'Demo List', 'Test List'];
    
    // Remove any list with a demo name
    Object.keys(acLists.lists).forEach(listId => {
      const list = acLists.lists[listId];
      if (demoNames.includes(list.name)) {
        removed.push(list.name);
        delete acLists.lists[listId];
        
        // If this was the active list, clear active
        if (acLists.activeListId === listId) {
          acLists.activeListId = null;
        }
        
        // If this was last used, clear it
        if (acLists.lastUsedListId === listId) {
          acLists.lastUsedListId = null;
        }
      }
    });
    
    if (removed.length > 0) {
      saveACLists(acLists);
      console.log('[ACHunterSRS] Removed demo lists:', removed);
      
      // Refresh the lists view if it's open
      if (typeof window.renderHHListsView === 'function') {
        window.renderHHListsView();
      }
      
      return { removed: removed, count: removed.length };
    }
    
    return { removed: [], count: 0 };
  }
  
  function initSRS() {
    // Load global settings
    loadSettings();
    
    // Wire 🎓 badge to open SRS panel
    const studyBadge = document.getElementById('study-badge');
    if (studyBadge) {
      studyBadge.addEventListener('click', openSRS);
    }
    
    // Log cleanup function availability
    console.log('[ACHunterSRS] Initialized. To remove demo lists, run: ACHunterSRS.cleanupDemoLists()');
  }
  
  // ========== PANEL CREATION ==========
  function createSRSPanel() {
    const overlay = document.createElement('div');
    overlay.className = 'ac-srs-overlay';
    overlay.id = 'ac-srs-overlay';
    
    overlay.innerHTML = `
      <div class="ac-srs-panel">
        <!-- Header -->
        <header class="ac-srs-header">
          <div class="ac-srs-header-content">
            <div class="ac-srs-title">AC 2.0</div>
            <div class="ac-srs-header-spacer"></div>
            <select id="ac-srs-list-select" class="ac-srs-list-select">
              <option value="">Select a list...</option>
            </select>
            <button id="ac-srs-abcd-badge" class="ac-srs-abcd-badge" title="SRS Mode (click to cycle)">A</button>
            <div class="ac-srs-header-spacer"></div>
            <button id="ac-srs-hamburger" class="ac-srs-hamburger" title="Settings">☰</button>
            <button id="ac-srs-close" class="ac-srs-close" title="Close">×</button>
          </div>
        </header>
        
        <!-- Loaded info -->
        <div class="ac-srs-loaded-stats" id="ac-srs-loaded-info">
          Select a list to begin
        </div>
        
        <!-- Content area -->
        <div class="ac-srs-content">
          <!-- Range slider -->
          <div class="ac-srs-controls">
            <div class="ac-srs-row">
              <div class="ac-srs-nums">
                Range: <span id="ac-srs-min-lb" class="ac-srs-num">1</span>–<span id="ac-srs-max-lb" class="ac-srs-num">1</span>
              </div>
              <div class="ac-srs-nums">
                Total: <span id="ac-srs-total-lb" class="ac-srs-num">0</span>
              </div>
            </div>
            <div class="ac-srs-slider-row">
              <input id="ac-srs-min-idx" type="range" min="1" max="1" value="1" aria-label="Minimum range">
              <input id="ac-srs-max-idx" type="range" min="1" max="1" value="1" aria-label="Maximum range">
            </div>
          </div>
          
          <!-- 4 main buttons -->
          <div class="ac-srs-button-grid">
            <button id="ac-srs-btn-daily" class="ac-srs-btn ac-srs-btn-daily" title="T">
              Daily<br>Hunt
            </button>
            <button id="ac-srs-btn-practice" class="ac-srs-btn ac-srs-btn-practice" title="H">
              Hunter<br>Practise
            </button>
            <button id="ac-srs-btn-due" class="ac-srs-btn ac-srs-btn-due" title="E">
              Due<br><span id="ac-srs-due-count" class="ac-srs-due-count">0</span>
            </button>
            <button id="ac-srs-btn-prey" class="ac-srs-btn ac-srs-btn-prey" title="L">
              Prey
            </button>
          </div>
          
          <!-- Speed control with badges (Option B: Split Layout) -->
          <div class="ac-srs-speed-control-bar">
            <!-- Left badge: Lists (📋) -->
            <button id="ac-srs-lists-badge" class="ac-srs-control-badge" title="Word Lists">📋</button>
            
            <!-- Center: Speed slider -->
            <div class="ac-srs-speed-control">
              <label>
                <span class="ac-srs-label-text">Speed</span>
                <input id="ac-srs-speed-range" type="range" min="0.2" max="1.5" step="0.1" value="1.0" aria-label="Sentence speed">
                <span id="ac-srs-speed-value" class="ac-srs-speed-value">1.0×</span>
              </label>
            </div>
            
            <!-- Right badge: Study (🎓) - this is the current open button -->
            <div class="ac-srs-control-badge-placeholder"></div>
          </div>
          
          <!-- Keyboard shortcuts -->
          <div class="ac-srs-shortcuts">
            Shortcuts:
            <span class="ac-srs-kbd">T</span> start •
            <span class="ac-srs-kbd">S</span> show •
            <span class="ac-srs-kbd">D</span> ok •
            <span class="ac-srs-kbd">F</span> again •
            <span class="ac-srs-kbd">A</span> speak sentence •
            <span class="ac-srs-kbd">J</span> SRS mode •
            <span class="ac-srs-kbd">E</span> due •
            <span class="ac-srs-kbd">Q</span> shift •
            <span class="ac-srs-kbd">U</span> dilute due •
            <span class="ac-srs-kbd">Z</span> reset •
            <span class="ac-srs-kbd">X</span> end •
            <em>Click Pinyin/Translation to see another example.</em>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(overlay);
    return overlay;
  }
  
  // ========== OPEN/CLOSE ==========
  // ========== SECTION STATE RESTORATION ==========
  // Track which AC content section was visible BEFORE opening SRS,
  // so we can restore it on close (same pattern as ACHunter.js)
  let _previousSectionState = null;

  function snapshotACState() {
    // Read currentSection from localStorage (most reliable)
    try {
      const acVarsRaw = localStorage.getItem('ACVariables');
      if (acVarsRaw) {
        const acVars = JSON.parse(acVarsRaw);
        if (acVars && acVars.currentSection && acVars.currentSection !== 'null') {
          _previousSectionState = { sectionName: acVars.currentSection };
          console.log('[ACHunterSRS] Snapshotted from localStorage:', acVars.currentSection);
          return;
        }
      }
    } catch (e) {
      console.warn('[ACHunterSRS] Failed to read ACVariables:', e);
    }

    // Fallback 1: Check body[data-section]
    try {
      const ds = document.body.getAttribute('data-section');
      if (ds && ds !== 'null' && ds !== '') {
        _previousSectionState = { sectionName: ds };
        console.log('[ACHunterSRS] Snapshotted from body[data-section]:', ds);
        return;
      }
    } catch (_) {}

    // Fallback 2: Check active badges (excluding study badge)
    try {
      const badges = document.querySelectorAll('.nav-badge.active');
      for (const b of badges) {
        if (b.id === 'study-badge' || b.id === 'hunterEntryBadge') continue;
        const section = b.getAttribute('data-section');
        if (section && section !== 'null' && section !== '') {
          _previousSectionState = { sectionName: section };
          console.log('[ACHunterSRS] Snapshotted from active badge:', section);
          return;
        }
      }
    } catch (_) {}

    // Fallback 3: Default to 'text' section if nothing found
    _previousSectionState = { sectionName: 'text' };
    console.log('[ACHunterSRS] No section found, defaulting to: text');
  }

  function restoreACState() {
    if (!_previousSectionState || !_previousSectionState.sectionName) {
      console.warn('[ACHunterSRS] No section state to restore');
      return;
    }
    const target = _previousSectionState.sectionName;
    console.log('[ACHunterSRS] Restoring section:', target);
    
    // Click the badge that was active before - this fires AC's showSection
    try {
      const badge = document.querySelector(
        '.nav-badge[data-section="' + target.replace(/"/g, '\\"') + '"]'
      );
      if (badge) {
        console.log('[ACHunterSRS] Clicking badge for section:', target);
        badge.click();
      } else {
        console.warn('[ACHunterSRS] No badge found for section:', target);
        // Try fallback
        if (window.showSection) {
          console.log('[ACHunterSRS] Using window.showSection fallback');
          window.showSection(target);
        }
      }
    } catch (e) {
      console.warn('[ACHunterSRS] restoreACState click failed:', e);
      // Fallback: try window.showSection
      try {
        if (window.showSection) {
          window.showSection(target);
        } else {
          console.warn('[ACHunterSRS] window.showSection not available');
        }
      } catch (e2) {
        console.warn('[ACHunterSRS] Fallback also failed:', e2);
      }
    }
  }

  // ========== PANEL OPEN/CLOSE ==========
  function openSRS() {
    // Snapshot AC state BEFORE opening panel
    snapshotACState();
    
    let overlay = document.getElementById('ac-srs-overlay');
    
    if (!overlay) {
      overlay = createSRSPanel();
      attachEventListeners();
    }
    
    // Populate list selector
    populateListSelector();
    
    // Show overlay
    overlay.classList.add('ac-srs-active');
  }
  
  function closeSRS() {
    const overlay = document.getElementById('ac-srs-overlay');
    if (overlay) {
      overlay.classList.remove('ac-srs-active');
    }
    
    // Restore the AC section that was visible before
    restoreACState();
  }
  
  // ========== EVENT LISTENERS ==========
  function attachEventListeners() {
    // Close button
    const closeBtn = document.getElementById('ac-srs-close');
    closeBtn.addEventListener('click', closeSRS);
    
    // ABCD mode badge (cycle A → B → C → D → A)
    const abcdBadge = document.getElementById('ac-srs-abcd-badge');
    abcdBadge.addEventListener('click', cycleABCDMode);
    
    // Hamburger menu
    const hamburger = document.getElementById('ac-srs-hamburger');
    hamburger.addEventListener('click', openSettings);
    
    // Lists badge (left of speed slider)
    const listsBadge = document.getElementById('ac-srs-lists-badge');
    if (listsBadge) {
      listsBadge.addEventListener('click', () => {
        if (typeof window.openHunterPanel === 'function') {
          window.openHunterPanel();
        } else {
          showToast('List management not available. Ensure ACHunter.js is loaded.');
        }
      });
    }
    
    // List selector
    const listSelect = document.getElementById('ac-srs-list-select');
    listSelect.addEventListener('change', onListChange);
    
    // Range sliders
    const minSlider = document.getElementById('ac-srs-min-idx');
    const maxSlider = document.getElementById('ac-srs-max-idx');
    minSlider.addEventListener('input', onRangeChange);
    maxSlider.addEventListener('input', onRangeChange);
    
    // Sentence speed slider
    const speedSlider = document.getElementById('ac-srs-speed-range');
    speedSlider.addEventListener('input', onSpeedChange);
    
    // 4 main buttons (all show "Coming soon" for Step 0)
    document.getElementById('ac-srs-btn-daily').addEventListener('click', () => {
      startDailyHunt();
    });
    
    document.getElementById('ac-srs-btn-practice').addEventListener('click', () => {
      openHunterPractice();
    });
    
    // ========== LONG-PRESS HELPER ==========
    // Centralized press management (tap vs long-press) - from HanziHunter
    function attachPress(el, onTap, onLong, longDelay = 550) {
        if (!el) return;
        let timer = null;
        let longFired = false;
        let pointerId = null;

        const clear = () => {
            if (timer) {
                clearTimeout(timer);
                timer = null;
            }
            pointerId = null;
        };

        el.addEventListener('pointerdown', e => {
            // prevent default behaviour (e.g., context menu or scroll)
            if (e.cancelable) e.preventDefault();
            e.stopPropagation();

            longFired = false;
            pointerId = e.pointerId ?? null;
            clear();

            timer = setTimeout(() => {
                longFired = true;
                if (onLong) onLong(e);
            }, longDelay);
        }, { passive: false });

        el.addEventListener('pointerup', e => {
            if (pointerId != null && e.pointerId != null && e.pointerId !== pointerId) return;
            if (e.cancelable) e.preventDefault();
            e.stopPropagation();

            if (timer) {
                clearTimeout(timer);
                timer = null;
                if (!longFired && onTap) onTap(e);
            }
        }, { passive: false });

        el.addEventListener('pointercancel', clear, { passive: true });
        el.addEventListener('pointerleave', clear, { passive: true });

        // Prevent context menu on long-press
        el.addEventListener('contextmenu', e => {
            e.preventDefault();
            e.stopPropagation();
        }, { passive: false });
    }

    // Due button: tap = Daily Hunt, long-press = Audio Drill
    const dueBtn = document.getElementById('ac-srs-btn-due');
    attachPress(
        dueBtn,
        () => { // normal tap
            openDueOverview();
        },
        () => { // long-press (550ms)
            if (typeof ACHunterAudio !== 'undefined' && ACHunterAudio.start) {
                const words = getCurrentWords();
                if (words && words.length > 0) {
                    ACHunterAudio.start(words);
                } else {
                    console.log('[ACHunterSRS] No words available for audio drill');
                }
            } else {
                console.log('[ACHunterSRS] ACHunterAudio not available');
            }
        }
    );
    
    document.getElementById('ac-srs-btn-prey').addEventListener('click', () => {
      openPreyBrowser();
    });
    
    // Keyboard shortcuts (optional for Step 0, we can add in later steps)
    document.addEventListener('keydown', onKeyPress);
    
    // Global keyboard handler for Audio Drill (B key)
    document.addEventListener('keydown', (e) => {
      // Only handle B if no modal/input is active
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (document.getElementById('ac-srs-overlay')?.classList.contains('ac-srs-active')) return;
      if (document.getElementById('audioDrillOverlay')?.classList.contains('active')) return;
      
      if (e.key.toLowerCase() === 'b') {
        e.preventDefault();
        if (typeof ACHunterAudio !== 'undefined' && ACHunterAudio.start) {
          const words = getCurrentWords();
          if (words && words.length > 0) {
            ACHunterAudio.start(words);
          } else {
            console.log('[ACHunterSRS] No words loaded. Open a list first (H button).');
          }
        } else {
          console.log('[ACHunterSRS] ACHunterAudio not available');
        }
      }
    });
  }
  
  // ========== LIST SELECTOR ==========
  function populateListSelector() {
    const listSelect = document.getElementById('ac-srs-list-select');
    const acLists = loadACLists();
    
    // Clear existing options
    listSelect.innerHTML = '<option value="">Select a list...</option>';
    
    if (!acLists || !acLists.lists) {
      return;
    }
    
    // Add each list
    Object.keys(acLists.lists).forEach(listId => {
      const list = acLists.lists[listId];
      const option = document.createElement('option');
      option.value = listId;
      option.textContent = list.name || `List ${listId}`;
      listSelect.appendChild(option);
    });
    
    // Select first list if available
    const firstListId = Object.keys(acLists.lists)[0];
    if (firstListId && !currentListId) {
      currentListId = firstListId;
      listSelect.value = firstListId;
      onListChange();
    }
  }
  
  function onListChange() {
    const listSelect = document.getElementById('ac-srs-list-select');
    const selectedId = listSelect.value;
    
    if (!selectedId) {
      currentListId = null;
      updateLoadedInfo('Select a list to begin');
      return;
    }
    
    currentListId = selectedId;
    
    // Load list data
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    
    if (!list) {
      updateLoadedInfo('List not found');
      return;
    }
    
    const itemCount = list.items ? list.items.length : 0;
    
    // Update info display
    updateLoadedInfo(`${itemCount} words`);
    
    // Update range slider bounds
    const minSlider = document.getElementById('ac-srs-min-idx');
    const maxSlider = document.getElementById('ac-srs-max-idx');
    
    minSlider.min = 1;
    minSlider.max = itemCount;
    maxSlider.min = 1;
    maxSlider.max = itemCount;
    
    // Restore saved range or use defaults
    const savedMin = srsSettings.rangeMin || 1;
    const savedMax = srsSettings.rangeMax || Math.min(100, itemCount);
    
    minSlider.value = Math.min(savedMin, itemCount);
    maxSlider.value = Math.min(savedMax, itemCount);
    
    // Update labels
    updateRangeLabels();
    
    // Update due count (placeholder for now)
    updateDueCount();
  }
  
  // ========== RANGE SLIDERS ==========
  function onRangeChange() {
    const minSlider = document.getElementById('ac-srs-min-idx');
    const maxSlider = document.getElementById('ac-srs-max-idx');
    
    let min = parseInt(minSlider.value);
    let max = parseInt(maxSlider.value);
    
    // Ensure min <= max
    if (min > max) {
      if (minSlider === document.activeElement) {
        max = min;
        maxSlider.value = max;
      } else {
        min = max;
        minSlider.value = min;
      }
    }
    
    // Save to settings
    srsSettings.rangeMin = min;
    srsSettings.rangeMax = max;
    saveSettings();
    
    // Update labels
    updateRangeLabels();
    
    // Update due count
    updateDueCount();
  }
  
  function updateRangeLabels() {
    const minSlider = document.getElementById('ac-srs-min-idx');
    const maxSlider = document.getElementById('ac-srs-max-idx');
    
    const min = parseInt(minSlider.value);
    const max = parseInt(maxSlider.value);
    const total = parseInt(maxSlider.max);
    
    document.getElementById('ac-srs-min-lb').textContent = min;
    document.getElementById('ac-srs-max-lb').textContent = max;
    document.getElementById('ac-srs-total-lb').textContent = total;
  }
  
  // ========== SENTENCE SPEED ==========
  function onSpeedChange() {
    const speedSlider = document.getElementById('ac-srs-speed-range');
    const speed = parseFloat(speedSlider.value);
    
    srsSettings.sentenceSpeed = speed;
    saveSettings();
    
    document.getElementById('ac-srs-speed-value').textContent = speed.toFixed(1) + '×';
  }
  
  // ========== ABCD MODE ==========
  function cycleABCDMode() {
    const badge = document.getElementById('ac-srs-abcd-badge');
    const modes = ['A', 'B', 'C', 'D'];
    const currentMode = badge.textContent;
    const currentIndex = modes.indexOf(currentMode);
    const nextIndex = (currentIndex + 1) % modes.length;
    const nextMode = modes[nextIndex];
    
    badge.textContent = nextMode;
    srsSettings.levelMath = nextIndex + 1; // 1=A, 2=B, 3=C, 4=D
    saveSettings();
    
    // Update title attribute with mode description
    const descriptions = {
      'A': 'Mode A: 2, 4, 8, 16… days',
      'B': 'Mode B: 3, 7, 14, 30… days',
      'C': 'Mode C: 4, 12, 30, 60… days',
      'D': 'Mode D: 14, 30, 45, 60… days'
    };
    badge.title = descriptions[nextMode];
  }
  
  // ========== DUE COUNT ==========
  function updateDueCount() {
    const dueCountEl = document.getElementById('ac-srs-due-count');
    if (!dueCountEl) return;
    
    if (!currentListId) {
      dueCountEl.textContent = '0';
      dueCountEl.classList.add('ac-srs-hidden');
      return;
    }
    
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    
    if (!list || !list.items) {
      dueCountEl.textContent = '0';
      dueCountEl.classList.add('ac-srs-hidden');
      return;
    }
    
    // Count items due today or overdue
    const srsData = loadSRSData(currentListId);
    const min = srsSettings.rangeMin || 1;
    const max = srsSettings.rangeMax || list.items.length;
    const today4amTime = today4am();
    
    let dueCount = 0;
    
    for (let i = min - 1; i < Math.min(max, list.items.length); i++) {
      const srsItem = srsData.items && srsData.items[i];
      
      // Unseen items count as due today
      if (!srsItem || !srsItem.PrTS) {
        if (!srsItem) continue;
        dueCount++;
        continue;
      }
      
      // Check if item is due today or overdue
      const dueDate = normalizeToLocalMidnight(new Date(srsItem.PrTS));
      if (dueDate.getTime() <= today4amTime.getTime()) {
        dueCount++;
      }
    }
    
    // Update badge
    dueCountEl.textContent = String(dueCount);
    
    // Hide badge if count is 0
    if (dueCount === 0) {
      dueCountEl.classList.add('ac-srs-hidden');
    } else {
      dueCountEl.classList.remove('ac-srs-hidden');
    }
  }
  
  // ========== LOADED INFO ==========
  function updateLoadedInfo(text) {
    const infoEl = document.getElementById('ac-srs-loaded-info');
    if (infoEl) {
      infoEl.textContent = text;
    }
  }
  
  // ========== KEYBOARD SHORTCUTS ==========
  function onKeyPress(e) {
    // Only handle if overlay is active
    const overlay = document.getElementById('ac-srs-overlay');
    if (!overlay || !overlay.classList.contains('ac-srs-active')) {
      return;
    }
    
    // Basic shortcuts for Step 0
    switch(e.key.toLowerCase()) {
      case 'x':
        closeSRS();
        break;
      case 'j':
        cycleABCDMode();
        break;
      // More shortcuts will be added in later steps
    }
  }
  
  // ========== TOAST ==========
  function showToast(message, duration = 2000) {
    let toast = document.getElementById('ac-srs-toast');
    
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'ac-srs-toast';
      toast.className = 'ac-srs-toast';
      document.body.appendChild(toast);
    }
    
    toast.textContent = message;
    toast.classList.add('ac-srs-show');
    
    setTimeout(() => {
      toast.classList.remove('ac-srs-show');
    }, duration);
  }
  
  // ========== STORAGE ==========
  function loadACLists() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.AC_LISTS);
      return data ? JSON.parse(data) : { lists: {} };
    } catch (e) {
      console.error('Failed to load AC lists:', e);
      return { lists: {} };
    }
  }
  
  function loadSettings() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (data) {
        const saved = JSON.parse(data);
        srsSettings = { ...srsSettings, ...saved };
      }
      
      // Apply saved ABCD mode to badge
      const badge = document.getElementById('ac-srs-abcd-badge');
      if (badge) {
        const modes = ['A', 'B', 'C', 'D'];
        badge.textContent = modes[srsSettings.levelMath - 1] || 'A';
      }
      
      // Apply saved speed to slider
      const speedSlider = document.getElementById('ac-srs-speed-range');
      if (speedSlider) {
        speedSlider.value = srsSettings.sentenceSpeed || 1.0;
        document.getElementById('ac-srs-speed-value').textContent = 
          (srsSettings.sentenceSpeed || 1.0).toFixed(1) + '×';
      }
    } catch (e) {
      console.error('Failed to load SRS settings:', e);
    }
  }
  
  // ========== SETTINGS MODAL (STEP 2) ==========
  
  // Hard Track state (Step 3)
  let hardTrackActive = false;
  
  function openSettings() {
    let overlay = document.getElementById('ac-srs-settings-overlay');
    
    if (!overlay) {
      overlay = createSettingsOverlay();
      document.body.appendChild(overlay);
    }
    
    // Populate current values
    populateSettings();
    
    // Show overlay
    overlay.classList.add('ac-srs-open');
  }
  
  function createSettingsOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'ac-srs-modal-overlay';
    overlay.id = 'ac-srs-settings-overlay';
    
    overlay.innerHTML = `
      <div class="ac-srs-modal ac-srs-settings-modal">
        <div class="ac-srs-modal-header">
          <h3 class="ac-srs-modal-title">Settings</h3>
          <button id="ac-srs-settings-close" class="ac-srs-modal-close">×</button>
        </div>
        
        <div class="ac-srs-settings-content">
          <!-- Language 1 (Source/Chinese) -->
          <div class="ac-srs-setting-group">
            <h4>Language 1 (Source)</h4>
            <div class="ac-srs-setting-row">
              <label>Language</label>
              <select id="ac-srs-lang1">
                <option value="zh-CN">Chinese (Simplified)</option>
                <option value="zh-TW">Chinese (Traditional)</option>
                <option value="en-US">English (US)</option>
                <option value="en-GB">English (UK)</option>
                <option value="de-DE">German</option>
                <option value="fr-FR">French</option>
                <option value="it-IT">Italian</option>
                <option value="es-ES">Spanish</option>
                <option value="pt-PT">Portuguese</option>
                <option value="ja-JP">Japanese</option>
                <option value="ko-KR">Korean</option>
              </select>
            </div>
            <div class="ac-srs-setting-row">
              <label>Voice</label>
              <select id="ac-srs-voice1">
                <option value="">Default</option>
              </select>
            </div>
          </div>
          
          <!-- Language 2 (Translation) -->
          <div class="ac-srs-setting-group">
            <h4>Language 2 (Translation)</h4>
            <div class="ac-srs-setting-row">
              <label>Language</label>
              <select id="ac-srs-lang2">
                <option value="en-US">English (US)</option>
                <option value="en-GB">English (UK)</option>
                <option value="de-DE">German</option>
                <option value="fr-FR">French</option>
                <option value="it-IT">Italian</option>
                <option value="es-ES">Spanish</option>
                <option value="pt-PT">Portuguese</option>
                <option value="zh-CN">Chinese (Simplified)</option>
                <option value="zh-TW">Chinese (Traditional)</option>
                <option value="ja-JP">Japanese</option>
                <option value="ko-KR">Korean</option>
              </select>
            </div>
            <div class="ac-srs-setting-row">
              <label>Voice</label>
              <select id="ac-srs-voice2">
                <option value="">Default</option>
              </select>
            </div>
          </div>
          
          <!-- Speech Settings -->
          <div class="ac-srs-setting-group">
            <h4>Speech</h4>
            <div class="ac-srs-setting-row">
              <label>Sentence speed</label>
              <input type="range" id="ac-srs-settings-speed" min="0.2" max="1.5" step="0.1" value="1.0">
              <span id="ac-srs-settings-speed-val">1.0×</span>
            </div>
          </div>
          
          <!-- Display Settings -->
          <div class="ac-srs-setting-group">
            <h4>Display</h4>
            <div class="ac-srs-setting-row">
              <label>Character size</label>
              <input type="range" id="ac-srs-settings-char-size" min="24" max="48" step="4" value="36">
              <span id="ac-srs-settings-char-val">36px</span>
            </div>
          </div>
          
          <!-- Study Settings -->
          <div class="ac-srs-setting-group">
            <h4>Study</h4>
            <div class="ac-srs-setting-row">
              <label>Max words per session</label>
              <input type="number" id="ac-srs-settings-max-words" min="5" max="100" value="20">
            </div>
          </div>
          
          <!-- Hard Track Settings (Step 3) -->
          <div class="ac-srs-setting-group">
            <h4>Hard Track</h4>
            <p class="ac-srs-setting-desc">
              Create a separate study track for your most difficult words. 
              Hard Track items have independent SRS state and appear in their own review sessions.
            </p>
            <div class="ac-srs-setting-row">
              <button id="ac-srs-create-hard-track" class="ac-srs-btn-hard-track">
                Create Hard Track…
              </button>
            </div>
          </div>
          
          <!-- Scheduling (Step 7) -->
          <div class="ac-srs-setting-section">
            <h4 class="ac-srs-setting-title">Scheduling</h4>
            <p class="ac-srs-setting-desc">
              Manage due dates for items in your active list and range.
            </p>
            <div class="ac-srs-setting-row">
              <button id="ac-srs-shift-dates" class="ac-srs-btn-secondary">
                Shift due dates…
              </button>
            </div>
            <div class="ac-srs-setting-row">
              <button id="ac-srs-dilute-dates" class="ac-srs-btn-secondary">
                Dilute due cards across N days…
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
    
    // Close button
    overlay.querySelector('#ac-srs-settings-close').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open');
    });
    
    // Close on backdrop click
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('ac-srs-open');
      }
    });
    
    // Populate voice dropdowns when language changes
    const lang1Select = overlay.querySelector('#ac-srs-lang1');
    const lang2Select = overlay.querySelector('#ac-srs-lang2');
    
    lang1Select.addEventListener('change', () => {
      populateVoices('ac-srs-voice1', lang1Select.value);
    });
    
    lang2Select.addEventListener('change', () => {
      populateVoices('ac-srs-voice2', lang2Select.value);
    });
    
    // Live preview sliders
    const speedSlider = overlay.querySelector('#ac-srs-settings-speed');
    const charSizeSlider = overlay.querySelector('#ac-srs-settings-char-size');
    const speedVal = overlay.querySelector('#ac-srs-settings-speed-val');
    const charVal = overlay.querySelector('#ac-srs-settings-char-val');
    
    speedSlider.addEventListener('input', () => {
      speedVal.textContent = speedSlider.value + '×';
    });
    
    charSizeSlider.addEventListener('input', () => {
      charVal.textContent = charSizeSlider.value + 'px';
    });
    
    // Auto-save on change
    const autoSave = () => {
      autoSaveSettings();
      showToast('Saved ✓', 1000);
    };
    
    overlay.querySelector('#ac-srs-lang1').addEventListener('change', autoSave);
    overlay.querySelector('#ac-srs-voice1').addEventListener('change', autoSave);
    overlay.querySelector('#ac-srs-lang2').addEventListener('change', autoSave);
    overlay.querySelector('#ac-srs-voice2').addEventListener('change', autoSave);
    speedSlider.addEventListener('change', autoSave);
    charSizeSlider.addEventListener('change', autoSave);
    overlay.querySelector('#ac-srs-settings-max-words').addEventListener('change', autoSave);
    
    // Populate voices on load
    if ('speechSynthesis' in window) {
      speechSynthesis.addEventListener('voiceschanged', () => {
        populateVoices('ac-srs-voice1', lang1Select.value);
        populateVoices('ac-srs-voice2', lang2Select.value);
      });
    }
    
    // Hard Track button (Step 3)
    overlay.querySelector('#ac-srs-create-hard-track').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open');
      openHardTrackModal();
    });
    
    // Shift dates button (Step 7)
    overlay.querySelector('#ac-srs-shift-dates').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open');
      shiftDueDatesPrompt();
    });
    
    // Dilute dates button (Step 7)
    overlay.querySelector('#ac-srs-dilute-dates').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open');
      diluteDueDatesPrompt();
    });
    
    return overlay;
  }
  
  function populateSettings() {
    const overlay = document.getElementById('ac-srs-settings-overlay');
    if (!overlay) return;
    
    // Load settings
    const settings = {
      lang1: srsSettings.lang1 || 'zh-CN',
      voice1: srsSettings.voice1 || '',
      lang2: srsSettings.lang2 || 'en-US',
      voice2: srsSettings.voice2 || '',
      sentenceSpeed: srsSettings.sentenceSpeed || 1.0,
      charSize: srsSettings.charSize || 36,
      maxWords: srsSettings.maxWords || 20
    };
    
    // Populate form
    overlay.querySelector('#ac-srs-lang1').value = settings.lang1;
    overlay.querySelector('#ac-srs-lang2').value = settings.lang2;
    overlay.querySelector('#ac-srs-settings-speed').value = settings.sentenceSpeed;
    overlay.querySelector('#ac-srs-settings-speed-val').textContent = settings.sentenceSpeed + '×';
    overlay.querySelector('#ac-srs-settings-char-size').value = settings.charSize;
    overlay.querySelector('#ac-srs-settings-char-val').textContent = settings.charSize + 'px';
    overlay.querySelector('#ac-srs-settings-max-words').value = settings.maxWords;
    
    // Populate voices
    populateVoices('ac-srs-voice1', settings.lang1);
    populateVoices('ac-srs-voice2', settings.lang2);
    
    // Set voice selections
    setTimeout(() => {
      if (settings.voice1) overlay.querySelector('#ac-srs-voice1').value = settings.voice1;
      if (settings.voice2) overlay.querySelector('#ac-srs-voice2').value = settings.voice2;
    }, 100);
  }
  
  function populateVoices(selectId, lang) {
    const select = document.getElementById(selectId);
    if (!select) return;
    
    if (!('speechSynthesis' in window)) {
      select.innerHTML = '<option value="">Not supported</option>';
      return;
    }
    
    const voices = speechSynthesis.getVoices();
    const langVoices = voices.filter(v => v.lang.startsWith(lang.split('-')[0]));
    
    select.innerHTML = '<option value="">Default</option>';
    
    langVoices.forEach(voice => {
      const option = document.createElement('option');
      option.value = voice.name;
      option.textContent = `${voice.name} (${voice.lang})`;
      select.appendChild(option);
    });
  }
  
  function saveSettings() {
    const overlay = document.getElementById('ac-srs-settings-overlay');
    if (!overlay) return;
    
    // Gather values
    srsSettings.lang1 = overlay.querySelector('#ac-srs-lang1').value;
    srsSettings.voice1 = overlay.querySelector('#ac-srs-voice1').value;
    srsSettings.lang2 = overlay.querySelector('#ac-srs-lang2').value;
    srsSettings.voice2 = overlay.querySelector('#ac-srs-voice2').value;
    srsSettings.sentenceSpeed = parseFloat(overlay.querySelector('#ac-srs-settings-speed').value);
    srsSettings.charSize = parseInt(overlay.querySelector('#ac-srs-settings-char-size').value);
    srsSettings.maxWords = parseInt(overlay.querySelector('#ac-srs-settings-max-words').value);
    
    // Save to localStorage
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(srsSettings));
    } catch (e) {
      console.error('Failed to save settings:', e);
    }
    
    // Update main panel sentence speed slider
    const mainSpeedSlider = document.getElementById('ac-srs-speed-range');
    const mainSpeedValue = document.getElementById('ac-srs-speed-value');
    if (mainSpeedSlider) {
      mainSpeedSlider.value = srsSettings.sentenceSpeed;
      mainSpeedValue.textContent = srsSettings.sentenceSpeed.toFixed(1) + '×';
    }
    
    // Close modal
    overlay.classList.remove('ac-srs-open');
    
    showToast('Settings saved');
  }
  
  function autoSaveSettings() {
    const overlay = document.getElementById('ac-srs-settings-overlay');
    if (!overlay) return;
    
    // Gather values
    srsSettings.lang1 = overlay.querySelector('#ac-srs-lang1').value;
    srsSettings.voice1 = overlay.querySelector('#ac-srs-voice1').value;
    srsSettings.lang2 = overlay.querySelector('#ac-srs-lang2').value;
    srsSettings.voice2 = overlay.querySelector('#ac-srs-voice2').value;
    srsSettings.sentenceSpeed = parseFloat(overlay.querySelector('#ac-srs-settings-speed').value);
    srsSettings.charSize = parseInt(overlay.querySelector('#ac-srs-settings-char-size').value);
    srsSettings.maxWords = parseInt(overlay.querySelector('#ac-srs-settings-max-words').value);
    
    // Save to localStorage
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(srsSettings));
    } catch (e) {
      console.error('Failed to save settings:', e);
    }
    
    // Update main panel sentence speed slider
    const mainSpeedSlider = document.getElementById('ac-srs-speed-range');
    const mainSpeedValue = document.getElementById('ac-srs-speed-value');
    if (mainSpeedSlider) {
      mainSpeedSlider.value = srsSettings.sentenceSpeed;
      mainSpeedValue.textContent = srsSettings.sentenceSpeed.toFixed(1) + '×';
    }
  }
  
  // ========== DAILY HUNT (STEP 4) ==========
  
  // Session state
  let currentSession = null;
  
  function startDailyHunt() {
    if (!currentListId) {
      showToast('Please select a list first');
      return;
    }
    
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    
    if (!list || !list.items || list.items.length === 0) {
      showToast('This list is empty');
      return;
    }
    
    // Get active track items and SRS data
    const activeItems = getActiveItemsList();
    const srsData = getActiveSRSData();
    
    // Initialize SRS data if needed
    if (!srsData.items || srsData.items.length === 0) {
      initializeSRSData(activeItems);
    }
    
    // Gather due items
    const dueItems = gatherDueItems(activeItems, srsData);
    
    if (dueItems.length === 0) {
      showToast('No items due for review!');
      return;
    }
    
    // Reset round state
    sessionRound = 1;
    round1Queue = [];
    round2Set = new Set();
    round2Order = [];
    round2State.clear();
    round2Queue = [];
    round3Queue = [];
    sessionFirstOutcome = {};
    seenCount = 0;
    correctCount = 0;
    current = null;
    
    // Initialize Round 1: shuffle all due items
    round1Queue = dueItems.slice();
    shuffleArray(round1Queue);
    totalPlanned = round1Queue.length;
    
    // Start session
    currentSession = {
      list: list,
      srsData: srsData,
      dueItems: dueItems,
      stats: {
        total: dueItems.length,
        correct: 0,
        wrong: 0
      }
    };
    
    // Open card overlay
    openCardOverlay();
    nextItem();
  }
  
  // Shuffle array in place
  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }
  
  // ========== ROUND SYSTEM FUNCTIONS ==========
  
  function beginRound2() {
    if (round2Set.size === 0) {
      endSession();
      return;
    }
    
    sessionRound = 2;
    
    // Create fixed order for R2 (will be reused for R3)
    round2Order = Array.from(round2Set);
    shuffleArray(round2Order);
    
    // Initialize R2 state: need 2 total "I knew" (not consecutive)
    round2State.clear();
    for (const idx of round2Order) {
      round2State.set(idx, { correctCount: 0, neededTotal: 2 });
    }
    
    // Initialize R2 queue
    round2Queue = round2Order.slice();
    
    console.log(`[Round 2] Starting with ${round2Queue.length} items`);
  }
  
  function beginRound3() {
    sessionRound = 3;
    
    // Survivors: items still needing work in R2
    const survivors = round2Order.filter(idx => {
      const st = round2State.get(idx);
      return st && st.correctCount < st.neededTotal;
    });
    
    round3Queue = survivors.slice();
    
    console.log(`[Round 3] Starting with ${round3Queue.length} items`);
    
    if (round3Queue.length === 0) {
      endSession();
    }
  }
  
  function nextItem() {
    // Move across rounds as queues empty
    if (sessionRound === 1) {
      if (round1Queue.length === 0) {
        if (round2Set.size === 0) {
          endSession();
          return;
        }
        beginRound2();
        if (sessionRound !== 1) {
          nextItem();
          return;
        }
      }
      current = round1Queue.shift();
    }
    else if (sessionRound === 2) {
      if (round2Queue.length === 0) {
        beginRound3();
        if (round3Queue.length === 0) {
          endSession();
          return;
        }
        // Fall through to R3
      } else {
        const idx = round2Queue.shift();
        const dueItem = currentSession.dueItems.find(item => item.index === idx);
        if (dueItem) {
          current = dueItem;
        } else {
          nextItem();
          return;
        }
      }
    }
    
    if (sessionRound === 3) {
      if (round3Queue.length === 0) {
        endSession();
        return;
      }
      const idx = round3Queue.shift();
      const dueItem = currentSession.dueItems.find(item => item.index === idx);
      if (dueItem) {
        current = dueItem;
      } else {
        nextItem();
        return;
      }
    }
    
    // Display the item
    displayCard();
  }
  
  function displayCard() {
    if (!current) return;
    
    const main = document.getElementById('ac-srs-card-main');
    const rail = document.getElementById('ac-srs-right-rail');
    
    // Get character size from settings
    const charSize = srsSettings.charSize || 36;
    
    // Show character (flexbox will center it)
    main.innerHTML = `
      <div class="ac-srs-char" id="ac-srs-char" style="font-size: ${charSize}px;">${current.word.zh}</div>
      <div class="ac-srs-char-py" id="ac-srs-char-py" style="display:none;"></div>
      <div class="ac-srs-char-tr" id="ac-srs-char-tr" style="display:none;"></div>
      <button id="ac-srs-sound-replay" class="ac-srs-sound-btn" style="display:none;" title="Play sound again">🔊</button>
    `;
    
    // Update counter badge (show items not yet completed)
    const counterBadge = document.getElementById('ac-srs-card-counter-badge');
    const remaining = totalPlanned - correctCount;
    counterBadge.textContent = remaining;
    counterBadge.style.opacity = '1';
    
    // Add/update round badge for Round 2
    const card = document.querySelector('.ac-srs-card');
    let roundBadge = card.querySelector('#ac-srs-round-badge');
    
    if (sessionRound === 2) {
      if (!roundBadge) {
        roundBadge = document.createElement('div');
        roundBadge.id = 'ac-srs-round-badge';
        roundBadge.className = 'ac-srs-round-badge';
        card.appendChild(roundBadge);
      }
      roundBadge.textContent = 'Revision';
      roundBadge.style.display = 'block';
    } else if (roundBadge) {
      roundBadge.style.display = 'none';
    }
    
    // Set rail to pre-reveal state and ensure it's visible
    rail.style.display = '';  // Reset display (fixes bug #4)
    rail.className = 'ac-srs-rail state-prereveal';
  }
  
  function initializeSRSData(list) {
    const srsData = {
      settings: {
        levelMath: srsSettings.levelMath || 1
      },
      items: list.items.map(() => ({
        level: 0,
        PrTS: 0,        // Due now
        r: 0,           // Right count
        w: 0,           // Wrong count
        t: 0,           // Total views
        lV: '',         // Last viewed
        nP: '—'         // Next practice
      }))
    };
    
    // Save
    const key = `${STORAGE_KEYS.SRS_PREFIX}${currentListId}`;
    localStorage.setItem(key, JSON.stringify(srsData));
    
    return srsData;
  }
  
  function gatherDueItems(items, srsData) {
    const now = Date.now();
    const min = srsSettings.rangeMin || 1;
    const max = srsSettings.rangeMax || items.length;
    const maxWords = srsSettings.maxWords || 20;
    
    const dueItems = [];
    
    for (let i = min - 1; i < Math.min(max, items.length); i++) {
      const item = items[i];
      const srsItem = srsData.items[i] || {};
      
      if (isDue(srsItem, now)) {
        dueItems.push({
          index: i,
          word: item,
          srs: srsItem
        });
        
        if (dueItems.length >= maxWords) break;
      }
    }
    
    return dueItems;
  }
  
  function isDue(item, nowMs) {
    if (!item) return true;
    if (item.PrTS == null || item.PrTS === 0) return true;  // Unseen
    return item.PrTS <= nowMs;
  }
  
  function openCardOverlay() {
    let overlay = document.getElementById('ac-srs-card-overlay');
    
    if (!overlay) {
      overlay = createCardOverlay();
      document.body.appendChild(overlay);
    }
    
    overlay.classList.add('ac-srs-open');
  }
  
  function createCardOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'ac-srs-modal-overlay';
    overlay.id = 'ac-srs-card-overlay';
    
    overlay.innerHTML = `
      <div class="ac-srs-card">
        <!-- Right Rail: Thumb-friendly buttons (HH style) -->
        <div id="ac-srs-right-rail" class="ac-srs-rail state-prereveal">
          <div class="ac-srs-rail-stack">
            <button id="ac-srs-rail-show" class="ac-srs-rail-btn ac-srs-rail-show" title="S">
              👀 Show
            </button>
            <button id="ac-srs-rail-ok" class="ac-srs-rail-btn ac-srs-rail-ok" title="D">
              ✔ I knew
            </button>
            <button id="ac-srs-rail-again" class="ac-srs-rail-btn ac-srs-rail-again" title="F">
              ↻ Again
            </button>
            <button id="ac-srs-rail-exit" class="ac-srs-rail-btn ac-srs-rail-exit" title="X">
              Exit
            </button>
          </div>
        </div>
        
        <!-- Card Content -->
        <div class="ac-srs-char-wrap">
          <!-- Counter badge (top-left) -->
          <div class="ac-srs-card-counter" id="ac-srs-card-counter-badge">0</div>
          
          <!-- KaiTi toggle (top-left below counter) -->
          <label class="ac-srs-kaiti-toggle">
            <input type="checkbox" id="ac-srs-kaiti-check">
            <span>楷体</span>
          </label>
          
          <!-- Main card display area -->
          <div id="ac-srs-card-main" class="ac-srs-card-main">
            <!-- Character/word content will be rendered here -->
          </div>
        </div>
      </div>
    `;
    
    // Wire up buttons
    overlay.querySelector('#ac-srs-rail-show').addEventListener('click', showAnswer);
    overlay.querySelector('#ac-srs-rail-ok').addEventListener('click', () => recordAnswer(true));
    overlay.querySelector('#ac-srs-rail-again').addEventListener('click', () => recordAnswer(false));
    overlay.querySelector('#ac-srs-rail-exit').addEventListener('click', endSession);
    
    // KaiTi toggle
    const kaitiCheck = overlay.querySelector('#ac-srs-kaiti-check');
    kaitiCheck.checked = srsSettings.useKaiTi || false;
    kaitiCheck.addEventListener('change', (e) => {
      srsSettings.useKaiTi = e.target.checked;
      saveSettings();
      applyKaiTi();
    });
    
    // Apply KaiTi if enabled
    applyKaiTi();
    
    // Keyboard shortcuts
    document.addEventListener('keydown', handleCardKeyPress);
    
    return overlay;
  }
  
  function applyKaiTi() {
    const card = document.querySelector('.ac-srs-card');
    if (!card) return;
    
    if (srsSettings.useKaiTi) {
      card.classList.add('ac-srs-kaiti-active');
    } else {
      card.classList.remove('ac-srs-kaiti-active');
    }
  }
  
  function showNextCard() {
    if (!currentSession) return;
    
    if (currentSession.currentIndex >= currentSession.dueItems.length) {
      showSessionEnd();
      return;
    }
    
    const dueItem = currentSession.dueItems[currentSession.currentIndex];
    const isChinese = dueItem.word.py && dueItem.word.py.trim() !== '';
    
    // Update counter badge
    const remaining = currentSession.stats.total - currentSession.currentIndex;
    document.getElementById('ac-srs-card-counter-badge').textContent = remaining;
    
    // Set rail to pre-reveal state (Show button tall, Exit small)
    const rail = document.getElementById('ac-srs-right-rail');
    rail.className = 'ac-srs-rail state-prereveal';
    
    // Show question
    const main = document.getElementById('ac-srs-card-main');
    const charSize = srsSettings.charSize || 36;
    
    main.innerHTML = `
      <div class="ac-srs-char" style="font-size: ${charSize}px;">
        ${isChinese ? dueItem.word.zh : dueItem.word.tr}
      </div>
    `;
  }
  
  function showAnswer() {
    if (!current) return;
    
    const py = document.getElementById('ac-srs-char-py');
    const tr = document.getElementById('ac-srs-char-tr');
    const soundBtn = document.getElementById('ac-srs-sound-replay');
    const rail = document.getElementById('ac-srs-right-rail');
    
    py.textContent = current.word.py || '';
    py.style.display = 'block';
    
    tr.textContent = current.word.tr || '';
    tr.style.display = 'block';
    
    // Show sound replay button
    if (soundBtn) {
      soundBtn.style.display = 'inline-block';
      soundBtn.onclick = () => playSound();
    }
    
    // Switch rail to revealed state
    rail.className = 'ac-srs-rail state-revealed';
    
    // Play TTS automatically
    playSound();
  }
  
  function playSound() {
    if (!current) return;
    const text = current.word.zh;
    if (!text) return;
    
    // Stop any current speech
    speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'zh-CN';
    utterance.rate = srsSettings.sentenceSpeed || 1.0;
    
    // Use selected voice if available
    if (srsSettings.voice1) {
      const voices = speechSynthesis.getVoices();
      const selectedVoice = voices.find(v => v.name === srsSettings.voice1);
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
    }
    
    speechSynthesis.speak(utterance);
  }
  
  function recordAnswer(wasCorrect) {
    if (!current) return;
    
    const idx = current.index;
    const key = idx.toString();
    
    // Record first outcome for SRS update
    if (!sessionFirstOutcome[key]) {
      sessionFirstOutcome[key] = wasCorrect ? 'ok' : 'again';
      scheduleNext(current, wasCorrect ? 'ok' : 'again');
    }
    
    // Mark as seen
    if (!current.seen) {
      current.seen = true;
      seenCount++;
    }
    
    // Update stats
    if (wasCorrect) {
      currentSession.stats.correct++;
    } else {
      currentSession.stats.wrong++;
    }
    
    // Round-specific logic
    if (sessionRound === 1) {
      if (wasCorrect) {
        // "I knew" → Word DONE, counter decreases
        correctCount++;
      } else {
        // "Again" → Mark for Round 2
        round2Set.add(idx);
      }
      current = null;
      nextItem();
      return;
    }
    
    if (sessionRound === 2) {
      const st = round2State.get(idx);
      if (!st) {
        current = null;
        nextItem();
        return;
      }
      
      if (wasCorrect) {
        st.correctCount++;
        if (st.correctCount >= st.neededTotal) {
          // Got 2 total "I knew" → Word DONE, counter decreases
          correctCount++;
          // Do NOT requeue
        } else {
          // Got 1/2 → Requeue
          round2Queue.push(idx);
        }
      } else {
        // "Again" → Just requeue, don't reset count
        round2Queue.push(idx);
      }
      
      current = null;
      nextItem();
      return;
    }
    
    if (sessionRound === 3) {
      // Final pass → Word DONE regardless, counter decreases
      correctCount++;
      current = null;
      nextItem();
      return;
    }
  }
  
  function scheduleNext(dueItem, outcome) {
    const item = dueItem.srs;
    const levelMath = currentSession.srsData.settings.levelMath || 1;
    const now = new Date();
    
    // Update counters
    if (outcome === 'ok') {
      item.r = (item.r || 0) + 1;
    } else if (outcome === 'again') {
      item.w = (item.w || 0) + 1;
    }
    item.t = (item.r || 0) + (item.w || 0);
    
    // Promotion/Demotion
    if (outcome === 'ok') {
      item.level = Math.min(MAX_LEVEL, (item.level || 0) + 1);
      const days = calculateDaysToAdd(item.level, levelMath);
      item.PrTS = addDaysAt4am(days);
    } else if (outcome === 'again') {
      item.level = 0;
      item.PrTS = addDaysAt4am(1);  // Tomorrow
    }
    
    // Book-keeping
    item.lV = toLocalDateTimeString(now);
    if (item.PrTS != null) {
      const next = new Date(item.PrTS);
      item.nP = toLocalDateString(next);
    } else {
      item.nP = '—';
    }
    
    // Save immediately
    saveSRSData();
  }
  
  function calculateDaysToAdd(level, levelMath) {
    let daysToAdd = 0;
    
    if (levelMath === 1) {
      // A: 2, 4, 8, 16, ...
      daysToAdd = Math.pow(2, level);
    } else if (levelMath === 2) {
      // B: 3, 7, 14, 30, 60, 120, 240, then linear 120 steps
      if (level <= 6) {
        daysToAdd = Math.pow(2, level + 1) - 1;
      } else {
        daysToAdd = (level - 5) * 120;
      }
    } else if (levelMath === 3) {
      // C: 4, 12, 30, 60, 120, 240, ...
      switch (level) {
        case 1: daysToAdd = 4; break;
        case 2: daysToAdd = 12; break;
        case 3: daysToAdd = 30; break;
        default: daysToAdd = 30 * Math.pow(2, level - 3); break;
      }
    } else if (levelMath === 4) {
      // D: 14, 30, 45, 60, then ×2
      switch (level) {
        case 1: daysToAdd = 14; break;
        case 2: daysToAdd = 30; break;
        case 3: daysToAdd = 45; break;
        case 4: daysToAdd = 60; break;
        default: daysToAdd = 60 * Math.pow(2, level - 4); break;
      }
    }
    
    return Math.max(0, Math.floor(daysToAdd));
  }
  
  function today4am() {
    const now = new Date();
    const fourAM = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 4, 0, 0, 0);
    return fourAM;
  }
  
  function addDaysAt4am(days) {
    return today4am().getTime() + (days * MS_PER_DAY);
  }
  
  function toLocalDateString(d) {
    const pad = n => (n < 10 ? '0' : '') + n;
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }
  
  function toLocalDateTimeString(d) {
    const pad = n => (n < 10 ? '0' : '') + n;
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }
  
  // Helper for Step 7: Normalize timestamp to 4 AM local time
  function normalizePrTS(timestamp) {
    if (timestamp === null || timestamp === undefined) return null;
    const d = new Date(timestamp);
    const normalized = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 4, 0, 0, 0);
    return normalized.getTime();
  }
  
  // Helper for Step 7: Get date at local midnight (for comparison)
  function normalizeToLocalMidnight(d) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 4, 0, 0, 0);
  }
  
  function saveSRSData() {
    if (!currentSession) return;
    saveActiveSRSData(currentSession.srsData);
  }
  
  // Direct save (for operations outside study sessions like Shift/Dilute)
  function saveDirectSRSData(listId, srsData) {
    const key = `${STORAGE_KEYS.SRS_PREFIX}${listId}`;
    try {
      localStorage.setItem(key, JSON.stringify(srsData));
    } catch (e) {
      console.error('Failed to save SRS data:', e);
    }
  }
  
  function showSessionEnd() {
    const main = document.getElementById('ac-srs-card-main');
    const buttons = document.getElementById('ac-srs-card-buttons');
    
    // Hide counter badge on end screen
    document.getElementById('ac-srs-card-counter-badge').style.opacity = '0';
    
    main.innerHTML = `
      <div class="ac-srs-session-end">
        <div class="ac-srs-end-title">Session Complete!</div>
        <div class="ac-srs-end-stats">
          <div class="ac-srs-end-stat">
            <div class="ac-srs-end-stat-value">${currentSession.stats.total}</div>
            <div class="ac-srs-end-stat-label">Total</div>
          </div>
          <div class="ac-srs-end-stat">
            <div class="ac-srs-end-stat-value ac-srs-stat-correct">${currentSession.stats.correct}</div>
            <div class="ac-srs-end-stat-label">Correct</div>
          </div>
          <div class="ac-srs-end-stat">
            <div class="ac-srs-end-stat-value ac-srs-stat-wrong">${currentSession.stats.wrong}</div>
            <div class="ac-srs-end-stat-label">Wrong</div>
          </div>
        </div>
      </div>
    `;
    
    buttons.innerHTML = `
      <button id="ac-srs-end-close" class="ac-srs-btn-action ac-srs-btn-primary">Close</button>
    `;
    
    document.getElementById('ac-srs-end-close').addEventListener('click', endSession);
  }
  
  function endSession() {
    if (!currentSession) {
      const overlay = document.getElementById('ac-srs-card-overlay');
      if (overlay) overlay.classList.remove('ac-srs-open');
      return;
    }
    
    // Show completion toast (white, no stats)
    showToast('Session complete.');
    
    // Close overlay
    const overlay = document.getElementById('ac-srs-card-overlay');
    if (overlay) {
      overlay.classList.remove('ac-srs-open');
    }
    
    // Update due count
    updateDueCount();
    
    // Clear session
    currentSession = null;
    current = null;
  }
  
  function handleCardKeyPress(e) {
    const overlay = document.getElementById('ac-srs-card-overlay');
    if (!overlay || !overlay.classList.contains('ac-srs-open')) return;
    
    switch(e.key.toLowerCase()) {
      case 's':
        const showBtn = document.getElementById('ac-srs-rail-show');
        if (showBtn && showBtn.offsetParent !== null) showBtn.click();
        break;
      case 'd':
        const okBtn = document.getElementById('ac-srs-rail-ok');
        if (okBtn && okBtn.offsetParent !== null) okBtn.click();
        break;
      case 'f':
        const againBtn = document.getElementById('ac-srs-rail-again');
        if (againBtn && againBtn.offsetParent !== null) againBtn.click();
        break;
      case 'x':
        endSession();
        break;
    }
  }
  
  // ========== HUNTER PRACTICE (STEP 5) ==========
  
  // Practice settings
  const practiceSettings = {
    mode: 'score', // 'level0' or 'score'
    maxOnScreen: 7,
    scoreMin: -2,
    scoreMax: 1
  };
  
  function openHunterPractice() {
    if (!currentListId) {
      showToast('Please select a list first');
      return;
    }
    
    // Load saved settings
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRACTICE);
      if (saved) {
        Object.assign(practiceSettings, JSON.parse(saved));
      }
    } catch (e) {
      console.error('Failed to load practice settings:', e);
    }
    
    let overlay = document.getElementById('ac-srs-practice-entry-overlay');
    
    if (!overlay) {
      overlay = createPracticeEntryOverlay();
      document.body.appendChild(overlay);
    }
    
    // Populate settings
    populatePracticeEntry();
    
    // Show overlay
    overlay.classList.add('ac-srs-open');
  }
  
  function createPracticeEntryOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'ac-srs-modal-overlay';
    overlay.id = 'ac-srs-practice-entry-overlay';
    
    overlay.innerHTML = `
      <div class="ac-srs-modal ac-srs-practice-entry-modal">
        <div class="ac-srs-modal-header">
          <h3 class="ac-srs-modal-title">Hunt (Practise)</h3>
          <button id="ac-srs-practice-entry-close" class="ac-srs-modal-close">×</button>
        </div>
        
        <div class="ac-srs-practice-entry-content">
          <!-- Selection mode -->
          <div class="ac-srs-practice-mode">
            <label class="ac-srs-practice-mode-label">How do you want to pick items?</label>
            <label class="ac-srs-practice-radio">
              <input type="radio" name="practice-mode" value="level0" id="ac-srs-practice-level0">
              <span>Level 0 only</span>
            </label>
            <label class="ac-srs-practice-radio">
              <input type="radio" name="practice-mode" value="score" id="ac-srs-practice-score">
              <span>Score (t) = right − wrong</span>
            </label>
          </div>
          
          <!-- Max on screen -->
          <div class="ac-srs-practice-slider-row">
            <label>Max on screen</label>
            <input type="range" id="ac-srs-practice-max" min="3" max="20" value="7">
            <span id="ac-srs-practice-max-val">7</span>
          </div>
          
          <!-- Preview count -->
          <div class="ac-srs-practice-preview" id="ac-srs-practice-preview">
            With these settings, 12 characters will be included.
          </div>
          
          <!-- Score range (only visible when score mode selected) -->
          <div class="ac-srs-practice-score-range" id="ac-srs-practice-score-range">
            <div class="ac-srs-practice-slider-row">
              <label>Score (t): include ≥</label>
              <input type="range" id="ac-srs-practice-min" min="-10" max="10" value="-2">
              <span id="ac-srs-practice-min-val">-2</span>
            </div>
            <div class="ac-srs-practice-slider-row">
              <label>Score (t): include ≤</label>
              <input type="range" id="ac-srs-practice-max-score" min="-10" max="10" value="1">
              <span id="ac-srs-practice-max-score-val">1</span>
            </div>
          </div>
          
          <!-- Actions -->
          <div class="ac-srs-practice-actions">
            <button id="ac-srs-practice-start" class="ac-srs-btn-primary">Start</button>
            <button id="ac-srs-practice-cancel" class="ac-srs-btn-secondary">Cancel</button>
          </div>
        </div>
      </div>
    `;
    
    // Close button
    overlay.querySelector('#ac-srs-practice-entry-close').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open');
    });
    
    // Cancel button
    overlay.querySelector('#ac-srs-practice-cancel').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open');
    });
    
    // Start button
    overlay.querySelector('#ac-srs-practice-start').addEventListener('click', startPracticeGame);
    
    // Mode radios
    const level0Radio = overlay.querySelector('#ac-srs-practice-level0');
    const scoreRadio = overlay.querySelector('#ac-srs-practice-score');
    
    level0Radio.addEventListener('change', () => {
      if (level0Radio.checked) {
        practiceSettings.mode = 'level0';
        updatePracticeUI();
        updatePracticePreview();
      }
    });
    
    scoreRadio.addEventListener('change', () => {
      if (scoreRadio.checked) {
        practiceSettings.mode = 'score';
        updatePracticeUI();
        updatePracticePreview();
      }
    });
    
    // Sliders
    const maxSlider = overlay.querySelector('#ac-srs-practice-max');
    const minSlider = overlay.querySelector('#ac-srs-practice-min');
    const maxScoreSlider = overlay.querySelector('#ac-srs-practice-max-score');
    
    maxSlider.addEventListener('input', () => {
      document.getElementById('ac-srs-practice-max-val').textContent = maxSlider.value;
      practiceSettings.maxOnScreen = parseInt(maxSlider.value);
      updatePracticePreview();
    });
    
    minSlider.addEventListener('input', () => {
      document.getElementById('ac-srs-practice-min-val').textContent = minSlider.value;
      practiceSettings.scoreMin = parseInt(minSlider.value);
      updatePracticePreview();
    });
    
    maxScoreSlider.addEventListener('input', () => {
      document.getElementById('ac-srs-practice-max-score-val').textContent = maxScoreSlider.value;
      practiceSettings.scoreMax = parseInt(maxScoreSlider.value);
      updatePracticePreview();
    });
    
    return overlay;
  }
  
  function populatePracticeEntry() {
    // Set mode
    document.getElementById('ac-srs-practice-level0').checked = practiceSettings.mode === 'level0';
    document.getElementById('ac-srs-practice-score').checked = practiceSettings.mode === 'score';
    
    // Set sliders
    document.getElementById('ac-srs-practice-max').value = practiceSettings.maxOnScreen;
    document.getElementById('ac-srs-practice-max-val').textContent = practiceSettings.maxOnScreen;
    document.getElementById('ac-srs-practice-min').value = practiceSettings.scoreMin;
    document.getElementById('ac-srs-practice-min-val').textContent = practiceSettings.scoreMin;
    document.getElementById('ac-srs-practice-max-score').value = practiceSettings.scoreMax;
    document.getElementById('ac-srs-practice-max-score-val').textContent = practiceSettings.scoreMax;
    
    // Update UI visibility
    updatePracticeUI();
    updatePracticePreview();
  }
  
  function updatePracticeUI() {
    const scoreRange = document.getElementById('ac-srs-practice-score-range');
    if (practiceSettings.mode === 'level0') {
      scoreRange.style.display = 'none';
    } else {
      scoreRange.style.display = 'block';
    }
  }
  
  function updatePracticePreview() {
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    if (!list) return;
    
    const srsData = loadSRSData(currentListId);
    const min = srsSettings.rangeMin || 1;
    const max = srsSettings.rangeMax || list.items.length;
    
    let eligible = [];
    
    if (practiceSettings.mode === 'level0') {
      // Level 0 only: items with level === 0
      for (let i = min - 1; i < Math.min(max, list.items.length); i++) {
        const srsItem = srsData.items && srsData.items[i];
        if (!srsItem || srsItem.level === 0) {
          eligible.push(i);
        }
      }
    } else {
      // Score mode: filter by score (t = r - w)
      for (let i = min - 1; i < Math.min(max, list.items.length); i++) {
        const srsItem = srsData.items && srsData.items[i];
        if (!srsItem) continue;
        
        const score = (srsItem.r || 0) - (srsItem.w || 0);
        if (score >= practiceSettings.scoreMin && score <= practiceSettings.scoreMax) {
          eligible.push(i);
        }
      }
    }
    
    const preview = document.getElementById('ac-srs-practice-preview');
    preview.innerHTML = `With these settings, <strong>${eligible.length}</strong> ${eligible.length === 1 ? 'word' : 'words'} will be included in the game.`;
    
    const startBtn = document.getElementById('ac-srs-practice-start');
    startBtn.disabled = eligible.length === 0;
  }
  
  function startPracticeGame() {
    // Save settings
    try {
      localStorage.setItem(STORAGE_KEYS.PRACTICE, JSON.stringify(practiceSettings));
    } catch (e) {
      console.error('Failed to save practice settings:', e);
    }
    
    // Gather eligible items
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    const srsData = loadSRSData(currentListId);
    const min = srsSettings.rangeMin || 1;
    const max = srsSettings.rangeMax || list.items.length;
    
    let eligible = [];
    
    if (practiceSettings.mode === 'level0') {
      for (let i = min - 1; i < Math.min(max, list.items.length); i++) {
        const srsItem = srsData.items && srsData.items[i];
        if (!srsItem || srsItem.level === 0) {
          eligible.push({
            index: i,
            word: list.items[i],
            srs: srsItem || {}
          });
        }
      }
    } else {
      for (let i = min - 1; i < Math.min(max, list.items.length); i++) {
        const srsItem = srsData.items && srsData.items[i];
        if (!srsItem) continue;
        
        const score = (srsItem.r || 0) - (srsItem.w || 0);
        if (score >= practiceSettings.scoreMin && score <= practiceSettings.scoreMax) {
          eligible.push({
            index: i,
            word: list.items[i],
            srs: srsItem
          });
        }
      }
    }
    
    if (eligible.length === 0) {
      showToast('No items match the filters');
      return;
    }
    
    // Limit to maxOnScreen
    const gameItems = eligible.slice(0, practiceSettings.maxOnScreen);
    
    // Format for ACBubbles (expects: {chinese, pinyin, translation})
    const bubbleWords = gameItems.map(item => ({
      chinese: item.word.zh,
      pinyin: item.word.py || '',
      translation: item.word.tr
    }));
    
    // Store these words for audio drill (convert to audio format: {zh, py, tr})
    currentPracticeWords = bubbleWords.map(w => ({
      zh: w.chinese,
      py: w.pinyin,
      tr: w.translation
    }));
    
    console.log('🎯 Formatted bubble words:', bubbleWords);
    console.log('🎯 First word check:', bubbleWords[0]);
    console.log('🎯 Stored for audio drill:', currentPracticeWords);
    
    // Close entry modal
    document.getElementById('ac-srs-practice-entry-overlay').classList.remove('ac-srs-open');
    
    // Close any open SRS card overlay
    const cardOverlay = document.getElementById('ac-srs-card-overlay');
    if (cardOverlay) {
      cardOverlay.classList.remove('ac-srs-open');
    }
    
    // Temporarily hide main SRS panel (don't remove class, just hide it)
    const mainPanel = document.getElementById('ac-srs-overlay');
    if (mainPanel) {
      mainPanel.style.display = 'none';
    }
    
    // Launch AC's existing bubble game with a small delay
    setTimeout(() => {
      if (typeof ACBubbles !== 'undefined' && ACBubbles.launch) {
        console.log('🎯 About to launch ACBubbles...');
        
        ACBubbles.launch(bubbleWords);
        console.log('🎯 ACBubbles.launch() called');
        
        // Hook into bubble game exit by monitoring overlay visibility
        const bubbleOverlay = document.getElementById('bubbleGameOverlay');
        if (bubbleOverlay) {
          // Create a MutationObserver to watch for when bubbles close
          const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
              if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                // Check if bubble-active class was removed (game closed)
                if (!bubbleOverlay.classList.contains('bubble-active')) {
                  console.log('🎯 Bubbles ended, restoring Practice Entry');
                  
                  // Restore main panel
                  if (mainPanel) {
                    mainPanel.style.display = '';
                    mainPanel.classList.add('ac-srs-open');
                  }
                  
                  // Reopen Practice Entry modal
                  const practiceEntry = document.getElementById('ac-srs-practice-entry-overlay');
                  if (practiceEntry) {
                    practiceEntry.classList.add('ac-srs-open');
                  }
                  
                  // Disconnect observer after first trigger
                  observer.disconnect();
                }
              }
            });
          });
          
          // Start observing
          observer.observe(bubbleOverlay, { attributes: true });
        }
      } else {
        console.error('❌ ACBubbles not available');
        showToast('ACBubbles not loaded. Please ensure ACBubbles.js is included.');
        // Restore main panel if bubbles failed
        if (mainPanel) {
          mainPanel.style.display = '';
          mainPanel.classList.add('ac-srs-open');
        }
      }
    }, 150);
  }
  
  // ========== CARD DETAILS (STEP 6) ==========
  
  let cardDetailsState = null;
  
  function openCardDetails(items, currentIdx, startIndex) {
    cardDetailsState = {
      items: items,
      currentIdx: currentIdx,
      startIndex: startIndex
    };
    
    // Create overlay if needed
    let overlay = document.getElementById('ac-srs-card-details-overlay');
    if (!overlay) {
      overlay = createCardDetailsOverlay();
      document.body.appendChild(overlay);
    }
    
    // Render current card
    renderCardDetails();
    
    // Show overlay
    overlay.classList.remove('ac-srs-hidden');
  }
  
  function createCardDetailsOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'ac-srs-card-details-overlay';
    overlay.className = 'ac-srs-hidden';
    
    overlay.innerHTML = `
      <div class="ac-srs-card-backdrop"></div>
      <div class="ac-srs-card-content">
        <!-- Close button -->
        <button class="ac-srs-card-close">×</button>
        
        <!-- Prev/Next arrows -->
        <button class="ac-srs-card-prev">‹</button>
        <button class="ac-srs-card-next">›</button>
        
        <!-- KaiTi toggle -->
        <label class="ac-srs-card-kaiti-label">
          <input type="checkbox" id="ac-srs-card-kaiti-check">
          <span>楷体</span>
        </label>
        
        <!-- Card body -->
        <div class="ac-srs-card-body">
          <div class="ac-srs-card-hanzi" id="ac-srs-card-hanzi"></div>
          <div class="ac-srs-card-pinyin" id="ac-srs-card-pinyin"></div>
          <div class="ac-srs-card-translation" id="ac-srs-card-translation"></div>
        </div>
        
        <!-- Actions -->
        <div class="ac-srs-card-actions">
          <button class="ac-srs-card-replay">🔊</button>
        </div>
      </div>
    `;
    
    // Wire close button (stop propagation so Prey stays open)
    overlay.querySelector('.ac-srs-card-close').addEventListener('click', (e) => {
      e.stopPropagation();
      closeCardDetails();
    });
    
    // Wire navigation
    overlay.querySelector('.ac-srs-card-prev').addEventListener('click', gotoPrevCard);
    overlay.querySelector('.ac-srs-card-next').addEventListener('click', gotoNextCard);
    
    // Wire replay
    overlay.querySelector('.ac-srs-card-replay').addEventListener('click', playCardAudio);
    
    // KaiTi toggle
    const kaitiCheck = overlay.querySelector('#ac-srs-card-kaiti-check');
    kaitiCheck.checked = srsSettings.useKaiTi || false;
    kaitiCheck.addEventListener('change', (e) => {
      srsSettings.useKaiTi = e.target.checked;
      saveSettings();
      applyCardKaiTi();
    });
    applyCardKaiTi();
    
    // Backdrop click to close (stop propagation so Prey stays open)
    overlay.querySelector('.ac-srs-card-backdrop').addEventListener('click', (e) => {
      e.stopPropagation(); // Don't let click reach Prey backdrop
      closeCardDetails();
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', handleCardDetailsKeys);
    
    // Touch swipe
    let touchStartX = 0;
    const cardContent = overlay.querySelector('.ac-srs-card-content');
    
    cardContent.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0].clientX;
    }, { passive: true });
    
    cardContent.addEventListener('touchend', (e) => {
      const touchEndX = e.changedTouches[0].clientX;
      const diff = touchStartX - touchEndX;
      if (Math.abs(diff) > 50) {
        if (diff > 0) {
          gotoNextCard(); // Swipe left → next
        } else {
          gotoPrevCard(); // Swipe right → prev
        }
      }
    }, { passive: true });
    
    // Click anywhere on card → next (except interactive elements)
    cardContent.addEventListener('click', (e) => {
      if (e.target.closest('button') || e.target.closest('label') || e.target.closest('input')) {
        return;
      }
      if (e.target.closest('.ac-srs-card-hanzi')) {
        return;
      }
      gotoNextCard();
    });
    
    // Click hanzi → Pleco (mobile + Chinese only)
    overlay.querySelector('#ac-srs-card-hanzi').addEventListener('click', (e) => {
      if (!cardDetailsState) return;
      const item = cardDetailsState.items[cardDetailsState.currentIdx];
      const isChinese = item.py && item.py.trim() !== '';
      const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      
      if (isChinese && isMobile) {
        const word = item.zh;
        if (word) {
          location.href = `plecoapi://x-callback-url/s?q=${encodeURIComponent(word)}`;
        }
      }
      e.stopPropagation();
    });
    
    return overlay;
  }
  
  function renderCardDetails() {
    if (!cardDetailsState) return;
    
    const item = cardDetailsState.items[cardDetailsState.currentIdx];
    const isChinese = item.py && item.py.trim() !== '';
    
    // Display word
    document.getElementById('ac-srs-card-hanzi').textContent = 
      isChinese ? item.zh : item.tr;
    
    // Display pinyin (only for Chinese)
    const pinyinEl = document.getElementById('ac-srs-card-pinyin');
    if (isChinese && item.py) {
      pinyinEl.textContent = item.py;
      pinyinEl.style.display = 'block';
    } else {
      pinyinEl.style.display = 'none';
    }
    
    // Display translation
    document.getElementById('ac-srs-card-translation').textContent = 
      isChinese ? item.tr : item.zh;
    
    // Auto-play audio
    playCardAudio();
  }
  
  function playCardAudio() {
    if (!cardDetailsState) return;
    const item = cardDetailsState.items[cardDetailsState.currentIdx];
    const isChinese = item.py && item.py.trim() !== '';
    const text = isChinese ? item.zh : item.zh;
    const lang = item.lang || (isChinese ? 'zh-CN' : 'en-US');
    playTTS(text, lang);
  }
  
  function gotoPrevCard() {
    if (!cardDetailsState) return;
    cardDetailsState.currentIdx--;
    if (cardDetailsState.currentIdx < 0) {
      cardDetailsState.currentIdx = cardDetailsState.items.length - 1;
    }
    renderCardDetails();
  }
  
  function gotoNextCard() {
    if (!cardDetailsState) return;
    cardDetailsState.currentIdx++;
    if (cardDetailsState.currentIdx >= cardDetailsState.items.length) {
      cardDetailsState.currentIdx = 0;
    }
    renderCardDetails();
  }
  
  function closeCardDetails() {
    const overlay = document.getElementById('ac-srs-card-details-overlay');
    if (overlay) {
      overlay.classList.add('ac-srs-hidden');
    }
    cardDetailsState = null;
    // DON'T close Prey overlay - stay in list view
  }
  
  function handleCardDetailsKeys(e) {
    const overlay = document.getElementById('ac-srs-card-details-overlay');
    if (!overlay || overlay.classList.contains('ac-srs-hidden')) return;
    
    switch(e.key) {
      case 'ArrowLeft':
        e.preventDefault();
        gotoPrevCard();
        break;
      case 'ArrowRight':
      case ' ':
        e.preventDefault();
        gotoNextCard();
        break;
      case 'Escape':
        e.preventDefault();
        closeCardDetails();
        break;
    }
  }
  
  function applyCardKaiTi() {
    const overlay = document.getElementById('ac-srs-card-details-overlay');
    if (!overlay) return;
    
    if (srsSettings.useKaiTi) {
      overlay.classList.add('ac-srs-kaiti-on');
    } else {
      overlay.classList.remove('ac-srs-kaiti-on');
    }
  }
  
  // ========== DUE OVERVIEW + SHIFT + STAT + DILUTE (STEP 7) ==========
  
  function openDueOverview() {
    if (!currentListId) {
      showToast('Please select a list first');
      return;
    }
    
    let overlay = document.getElementById('ac-srs-due-overlay');
    if (!overlay) {
      overlay = createDueOverlay();
      document.body.appendChild(overlay);
    }
    
    renderDueOverview();
    overlay.classList.add('ac-srs-open');
  }
  
  function createDueOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'ac-srs-modal-overlay';
    overlay.id = 'ac-srs-due-overlay';
    
    overlay.innerHTML = `
      <div class="ac-srs-modal ac-srs-due-modal">
        <div class="ac-srs-modal-header">
          <h3 class="ac-srs-modal-title">Due</h3>
          <div class="ac-srs-due-buttons">
            <button id="ac-srs-due-shift-btn" class="ac-srs-btn-secondary">Shift</button>
            <button id="ac-srs-due-stat-btn" class="ac-srs-btn-secondary">Stat</button>
          </div>
          <button id="ac-srs-due-close" class="ac-srs-modal-close">×</button>
        </div>
        <div class="ac-srs-due-content" id="ac-srs-due-content">
          <!-- Date list will be rendered here -->
        </div>
      </div>
    `;
    
    // Close button
    overlay.querySelector('#ac-srs-due-close').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open');
    });
    
    // Shift button
    overlay.querySelector('#ac-srs-due-shift-btn').addEventListener('click', () => {
      shiftDueDatesPrompt();
      renderDueOverview(); // Refresh after shift
    });
    
    // Stat button
    overlay.querySelector('#ac-srs-due-stat-btn').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open'); // Close Due
      openWeeklyStats(); // Open Stats
    });
    
    // Close on backdrop
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('ac-srs-open');
      }
    });
    
    return overlay;
  }
  
  function renderDueOverview() {
    const content = document.getElementById('ac-srs-due-content');
    if (!content) return;
    
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    if (!list) return;
    
    const srsData = loadSRSData(currentListId);
    const min = srsSettings.rangeMin || 1;
    const max = srsSettings.rangeMax || list.items.length;
    
    // Collect all due dates with counts
    const dateMap = new Map(); // date string -> count
    const today4amTime = today4am();
    const todayStr = formatDate(today4amTime);
    
    for (let i = min - 1; i < Math.min(max, list.items.length); i++) {
      const srsItem = srsData.items && srsData.items[i];
      
      // Handle unseen items (no PrTS) - assign to today
      if (!srsItem || !srsItem.PrTS) {
        if (!srsItem) continue;
        dateMap.set(todayStr, (dateMap.get(todayStr) || 0) + 1);
        continue;
      }
      
      // Normalize to 4 AM and group by date string
      const dueDate = new Date(srsItem.PrTS);
      const dateStr = srsItem.nP || formatDate(dueDate);
      
      dateMap.set(dateStr, (dateMap.get(dateStr) || 0) + 1);
    }
    
    // Sort by date string (ISO format sorts correctly)
    const sortedDateKeys = Array.from(dateMap.keys()).sort();
    
    if (sortedDateKeys.length === 0) {
      content.innerHTML = '<div class="ac-srs-due-empty">No items scheduled</div>';
      return;
    }
    
    // Render date list
    let html = '<div class="ac-srs-due-list">';
    
    sortedDateKeys.forEach(dateStr => {
      const count = dateMap.get(dateStr);
      const isToday = dateStr === todayStr;
      const label = isToday ? `Today ${dateStr}` : dateStr;
      const className = isToday ? 'ac-srs-due-row ac-srs-due-today' : 'ac-srs-due-row';
      
      html += `
        <div class="${className}">
          <span class="ac-srs-due-date">${label}:</span>
          <span class="ac-srs-due-count">${count}</span>
        </div>
      `;
    });
    
    html += '</div>';
    content.innerHTML = html;
  }
  
  function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  
  // ========== SHIFT DUE DATES ==========
  
  function shiftDueDatesPrompt() {
    const input = prompt('Shift due dates by ±days (active list + current range).\nRange: -365 to +365', '0');
    if (input === null) return;
    
    const days = parseInt(input, 10);
    if (!Number.isFinite(days) || days < -365 || days > 365) {
      showToast('Please enter an integer between -365 and +365');
      return;
    }
    
    const moved = shiftDueDates(days);
    showToast(`Shifted ${moved} item(s) by ${days} day(s)`);
    updateDueCount();
  }
  
  function shiftDueDates(deltaDays) {
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    if (!list) return 0;
    
    const srsData = loadSRSData(currentListId);
    const min = srsSettings.rangeMin || 1;
    const max = srsSettings.rangeMax || list.items.length;
    
    let touched = 0;
    
    for (let i = min - 1; i < Math.min(max, list.items.length); i++) {
      const srsItem = srsData.items && srsData.items[i];
      if (!srsItem || !srsItem.PrTS) continue; // Only scheduled items
      
      // Shift timestamp
      srsItem.PrTS = normalizePrTS(srsItem.PrTS + deltaDays * MS_PER_DAY);
      
      // Update date string
      if (srsItem.PrTS !== null) {
        const newDate = new Date(srsItem.PrTS);
        srsItem.nP = formatDate(newDate);
      }
      
      touched++;
    }
    
    if (touched > 0) {
      saveDirectSRSData(currentListId, srsData);
    }
    
    return touched;
  }
  
  // ========== DILUTE DUE DATES ==========
  
  function diluteDueDatesPrompt() {
    const input = prompt('Dilute items due up to today across N days (today..today+N-1).\nRange: 1 to 30', '3');
    if (input === null) return;
    
    const N = parseInt(input, 10);
    if (!Number.isFinite(N) || N < 1 || N > 30) {
      showToast('Please enter an integer between 1 and 30');
      return;
    }
    
    const moved = diluteDueDates(N);
    showToast(`Diluted ${moved} item(s) across ${N} day(s)`);
    updateDueCount();
  }
  
  function diluteDueDates(N) {
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    if (!list) return 0;
    
    const srsData = loadSRSData(currentListId);
    const min = srsSettings.rangeMin || 1;
    const max = srsSettings.rangeMax || list.items.length;
    
    const today4amTime = today4am();
    
    // Collect items due today or before
    const bucket = [];
    
    for (let i = min - 1; i < Math.min(max, list.items.length); i++) {
      const srsItem = srsData.items && srsData.items[i];
      if (!srsItem || !srsItem.PrTS) continue;
      
      const dueAt4am = normalizeToLocalMidnight(new Date(srsItem.PrTS));
      if (dueAt4am.getTime() <= today4amTime.getTime()) {
        bucket.push({ index: i, item: srsItem });
      }
    }
    
    if (bucket.length === 0) return 0;
    
    // Sort oldest first (most overdue gets earliest slots)
    bucket.sort((a, b) => {
      const aTime = Number.isFinite(a.item.PrTS) ? a.item.PrTS : 0;
      const bTime = Number.isFinite(b.item.PrTS) ? b.item.PrTS : 0;
      return aTime - bTime;
    });
    
    // Round-robin across today..today+N-1
    let moved = 0;
    for (let i = 0; i < bucket.length; i++) {
      const { item } = bucket[i];
      const offset = i % N;
      const newTimestamp = today4amTime.getTime() + offset * MS_PER_DAY;
      
      item.PrTS = normalizePrTS(newTimestamp);
      
      if (item.PrTS !== null) {
        const newDate = new Date(item.PrTS);
        item.nP = formatDate(newDate);
      }
      
      moved++;
    }
    
    if (moved > 0) {
      saveDirectSRSData(currentListId, srsData);
    }
    
    return moved;
  }
  
  // ========== WEEKLY STATS ==========
  
  function openWeeklyStats() {
    let overlay = document.getElementById('ac-srs-stats-overlay');
    if (!overlay) {
      overlay = createStatsOverlay();
      document.body.appendChild(overlay);
    }
    
    renderWeeklyStats();
    overlay.classList.add('ac-srs-open');
  }
  
  function createStatsOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'ac-srs-modal-overlay';
    overlay.id = 'ac-srs-stats-overlay';
    
    overlay.innerHTML = `
      <div class="ac-srs-modal ac-srs-stats-modal">
        <div class="ac-srs-modal-header">
          <h3 class="ac-srs-modal-title">Weekly Statistics</h3>
          <button id="ac-srs-stats-close" class="ac-srs-modal-close">×</button>
        </div>
        <div class="ac-srs-stats-content" id="ac-srs-stats-content">
          <!-- Stats will be rendered here -->
        </div>
      </div>
    `;
    
    // Close button
    overlay.querySelector('#ac-srs-stats-close').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open');
    });
    
    // Close on backdrop
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('ac-srs-open');
      }
    });
    
    return overlay;
  }
  
  function renderWeeklyStats() {
    const content = document.getElementById('ac-srs-stats-content');
    if (!content) return;
    
    const stats = buildWeeklyStats();
    
    // Calculate total
    const total = Object.values(stats).reduce((sum, week) => sum + week.count, 0);
    
    if (total === 0) {
      content.innerHTML = '<div class="ac-srs-stats-empty">No future items scheduled</div>';
      return;
    }
    
    let html = '<div class="ac-srs-stats-grid">';
    
    Object.values(stats).forEach(week => {
      const percentage = total > 0 ? Math.round((week.count / total) * 100) : 0;
      
      html += `
        <div class="ac-srs-stats-row">
          <span class="ac-srs-stats-label">${week.label}</span>
          <span class="ac-srs-stats-count">${week.count} (${percentage}%)</span>
        </div>
      `;
    });
    
    html += '</div>';
    content.innerHTML = html;
  }
  
  function buildWeeklyStats() {
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    if (!list) {
      return {
        week1: { label: 'Next 7 days', count: 0 },
        week2: { label: 'Week 2', count: 0 },
        week3: { label: 'Week 3', count: 0 },
        week4: { label: 'Week 4', count: 0 },
        beyond: { label: 'Day 29+', count: 0 }
      };
    }
    
    const srsData = loadSRSData(currentListId);
    const min = srsSettings.rangeMin || 1;
    const max = srsSettings.rangeMax || list.items.length;
    
    const today4amTime = today4am();
    
    const weeks = {
      week1: { label: 'Next 7 days', count: 0, start: 1, end: 7 },
      week2: { label: 'Week 2', count: 0, start: 8, end: 14 },
      week3: { label: 'Week 3', count: 0, start: 15, end: 21 },
      week4: { label: 'Week 4', count: 0, start: 22, end: 28 },
      beyond: { label: 'Day 29+', count: 0, start: 29, end: Infinity }
    };
    
    for (let i = min - 1; i < Math.min(max, list.items.length); i++) {
      const srsItem = srsData.items && srsData.items[i];
      if (!srsItem || !srsItem.PrTS) continue;
      
      const dueAt4am = normalizeToLocalMidnight(new Date(srsItem.PrTS));
      const diffTime = dueAt4am - today4amTime;
      const diffDays = Math.ceil(diffTime / MS_PER_DAY);
      
      // Skip if due today or in the past
      if (diffDays <= 0) continue;
      
      // Assign to appropriate week
      if (diffDays >= 1 && diffDays <= 7) weeks.week1.count++;
      else if (diffDays >= 8 && diffDays <= 14) weeks.week2.count++;
      else if (diffDays >= 15 && diffDays <= 21) weeks.week3.count++;
      else if (diffDays >= 22 && diffDays <= 28) weeks.week4.count++;
      else if (diffDays >= 29) weeks.beyond.count++;
    }
    
    return weeks;
  }
  
  // ========== HARD TRACK (STEP 3) ==========
  function openHardTrackModal() {
    if (!currentListId) {
      showToast('Please select a list first');
      return;
    }
    
    let overlay = document.getElementById('ac-srs-hard-track-overlay');
    
    if (!overlay) {
      overlay = createHardTrackOverlay();
      document.body.appendChild(overlay);
    }
    
    // Check if hard track exists
    const hardData = loadHardTrackData(currentListId);
    const hasHardTrack = hardData && hardData.order && hardData.order.length > 0;
    
    // Update UI
    updateHardTrackModal(hasHardTrack, hardData);
    
    // Show overlay
    overlay.classList.add('ac-srs-open');
  }
  
  function createHardTrackOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'ac-srs-modal-overlay';
    overlay.id = 'ac-srs-hard-track-overlay';
    
    overlay.innerHTML = `
      <div class="ac-srs-modal ac-srs-hard-modal">
        <div class="ac-srs-modal-header">
          <h3 class="ac-srs-modal-title" id="ac-srs-hard-title">Create Hard Track</h3>
          <button id="ac-srs-hard-close" class="ac-srs-modal-close">×</button>
        </div>
        
        <div class="ac-srs-hard-content">
          <p class="ac-srs-hard-intro" id="ac-srs-hard-intro">
            Select the most difficult words based on your study history. 
            These words will be placed in a separate Hard Track with independent SRS state.
          </p>
          
          <div class="ac-srs-hard-info" id="ac-srs-hard-info" style="display:none;">
            <!-- Shows existing hard track stats -->
          </div>
          
          <div class="ac-srs-hard-selector" id="ac-srs-hard-selector">
            <label>
              <span>Top</span>
              <input type="number" id="ac-srs-hard-percent" min="5" max="50" value="20" step="5">
              <span>% most difficult words</span>
            </label>
            <div class="ac-srs-hard-preview" id="ac-srs-hard-preview">
              This will select 0 words based on error rate and total views.
            </div>
          </div>
          
          <div class="ac-srs-hard-actions">
            <button id="ac-srs-hard-delete" class="ac-srs-btn-secondary" style="display:none;">
              Delete Hard Track
            </button>
            <button id="ac-srs-hard-submit" class="ac-srs-btn-primary">
              Create Hard Track
            </button>
          </div>
        </div>
      </div>
    `;
    
    // Close button
    overlay.querySelector('#ac-srs-hard-close').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open');
    });
    
    // Close on backdrop click
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('ac-srs-open');
      }
    });
    
    // Percent input - update preview
    const percentInput = overlay.querySelector('#ac-srs-hard-percent');
    percentInput.addEventListener('input', updateHardTrackPreview);
    
    // Submit button
    overlay.querySelector('#ac-srs-hard-submit').addEventListener('click', createHardTrack);
    
    // Delete button
    overlay.querySelector('#ac-srs-hard-delete').addEventListener('click', deleteHardTrack);
    
    return overlay;
  }
  
  function updateHardTrackModal(hasHardTrack, hardData) {
    const title = document.getElementById('ac-srs-hard-title');
    const intro = document.getElementById('ac-srs-hard-intro');
    const info = document.getElementById('ac-srs-hard-info');
    const selector = document.getElementById('ac-srs-hard-selector');
    const submitBtn = document.getElementById('ac-srs-hard-submit');
    const deleteBtn = document.getElementById('ac-srs-hard-delete');
    
    if (hasHardTrack) {
      title.textContent = 'Manage Hard Track';
      intro.style.display = 'none';
      info.style.display = 'block';
      info.innerHTML = `
        <strong>Hard Track Active</strong><br>
        Contains: ${hardData.order.length} words<br>
        Created: ${hardData.createdAt ? new Date(hardData.createdAt).toLocaleDateString() : 'Unknown'}<br>
        Source: Top ${hardData.sourcePercent || 20}% most difficult
      `;
      selector.style.display = 'none';
      submitBtn.style.display = 'none';
      deleteBtn.style.display = 'block';
    } else {
      title.textContent = 'Create Hard Track';
      intro.style.display = 'block';
      info.style.display = 'none';
      selector.style.display = 'block';
      submitBtn.style.display = 'block';
      deleteBtn.style.display = 'none';
      updateHardTrackPreview();
    }
  }
  
  function updateHardTrackPreview() {
    const percent = parseInt(document.getElementById('ac-srs-hard-percent').value) || 20;
    const preview = document.getElementById('ac-srs-hard-preview');
    
    // Get SRS data
    const srsData = loadSRSData(currentListId);
    if (!srsData.items || srsData.items.length === 0) {
      preview.textContent = 'No study data yet. Complete some reviews first.';
      return;
    }
    
    // Find items with views > 0 (studied items)
    const reviewedItems = srsData.items.filter(item => (item.t || 0) > 0);
    
    if (reviewedItems.length === 0) {
      preview.textContent = 'No reviewed items yet. Complete some reviews first.';
      return;
    }
    
    // Calculate how many items the percentage represents
    const count = Math.max(1, Math.floor(reviewedItems.length * (percent / 100)));
    
    preview.textContent = `This will select ${count} word${count !== 1 ? 's' : ''} (top ${percent}% of ${reviewedItems.length} reviewed items).`;
  }
  
  function createHardTrack() {
    const percent = parseInt(document.getElementById('ac-srs-hard-percent').value) || 20;
    const srsData = loadSRSData(currentListId);
    
    if (!srsData.items || srsData.items.length === 0) {
      showToast('No study data yet');
      return;
    }
    
    // Find reviewed items and sort by difficulty (wrong count desc, then views desc)
    const reviewedItems = srsData.items
      .map((item, idx) => ({ item, idx }))
      .filter(({ item }) => (item.t || 0) > 0);
    
    if (reviewedItems.length === 0) {
      showToast('No reviewed items yet');
      return;
    }
    
    // Sort by difficulty: highest wrong count first, then most views
    reviewedItems.sort((a, b) => {
      const wA = a.item.w || 0;
      const wB = b.item.w || 0;
      if (wB !== wA) return wB - wA; // More wrongs = more difficult
      
      const tA = a.item.t || 0;
      const tB = b.item.t || 0;
      return tB - tA; // More views = more practice needed
    });
    
    // Select top percent
    const count = Math.max(1, Math.floor(reviewedItems.length * (percent / 100)));
    const selected = reviewedItems.slice(0, count);
    
    // Re-sort selected items by original index (maintain list order)
    selected.sort((a, b) => a.idx - b.idx);
    
    // Create hard track data
    const hardTrackData = {
      createdAt: new Date().toISOString(),
      sourcePercent: percent,
      sourceCount: count,
      order: selected.map(({ idx }) => idx), // Indices in original list
      items: selected.map(({ item }) => ({
        // Virgin SRS state for hard track
        level: 0,
        PrTS: 0,
        r: 0,
        w: 0,
        t: 0,
        lV: '',
        nP: '—'
      }))
    };
    
    // Save hard track
    const key = `${STORAGE_KEYS.HARD_PREFIX}${currentListId}`;
    try {
      localStorage.setItem(key, JSON.stringify(hardTrackData));
      showToast(`Hard Track created: ${count} words`);
      
      // Close modal
      document.getElementById('ac-srs-hard-track-overlay').classList.remove('ac-srs-open');
      
      // Reload modal to show management view
      setTimeout(() => openHardTrackModal(), 300);
    } catch (e) {
      console.error('Failed to save hard track:', e);
      showToast('Error creating Hard Track');
    }
  }
  
  function deleteHardTrack() {
    if (!confirm('Delete Hard Track? This will remove the hard track but keep your original list intact.')) {
      return;
    }
    
    const key = `${STORAGE_KEYS.HARD_PREFIX}${currentListId}`;
    try {
      localStorage.removeItem(key);
      showToast('Hard Track deleted');
      
      // Close and reopen modal
      document.getElementById('ac-srs-hard-track-overlay').classList.remove('ac-srs-open');
      setTimeout(() => openHardTrackModal(), 300);
    } catch (e) {
      console.error('Failed to delete hard track:', e);
      showToast('Error deleting Hard Track');
    }
  }
  
  function loadHardTrackData(listId) {
    try {
      const key = `${STORAGE_KEYS.HARD_PREFIX}${listId}`;
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  }
  
  // ========== PREY BROWSER (STEP 1) ==========
  
  // Pinyin visibility state (per-item toggle)
  let pinyinVisible = new Map(); // itemIndex -> boolean
  let pinyinDefaultVisible = true;
  
  // Long-press state
  const LONG_PRESS_MS = 550;
  let longPressTimer = null;
  let longPressFired = false;
  let suppressClicksUntil = 0;
  
  function openPreyBrowser() {
    if (!currentListId) {
      showToast('Please select a list first');
      return;
    }
    
    const acLists = loadACLists();
    const list = acLists.lists[currentListId];
    
    if (!list || !list.items || list.items.length === 0) {
      showToast('This list is empty');
      return;
    }
    
    // Get items in active range
    const min = srsSettings.rangeMin || 1;
    const max = srsSettings.rangeMax || list.items.length;
    const items = list.items.slice(min - 1, max);
    
    if (items.length === 0) {
      showToast('No items in selected range');
      return;
    }
    
    // Create overlay if it doesn't exist
    let overlay = document.getElementById('ac-srs-prey-overlay');
    if (!overlay) {
      overlay = createPreyOverlay();
      document.body.appendChild(overlay);
    }
    
    // Populate with items
    renderPreyList(items, min);
    
    // Show overlay
    overlay.classList.add('ac-srs-open');
  }
  
  function createPreyOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'ac-srs-modal-overlay';
    overlay.id = 'ac-srs-prey-overlay';
    
    overlay.innerHTML = `
      <div class="ac-srs-modal ac-srs-prey-modal">
        <div class="ac-srs-modal-header">
          <h3 class="ac-srs-modal-title">Prey</h3>
          <button id="ac-srs-prey-close" class="ac-srs-modal-close">×</button>
        </div>
        
        <!-- Top controls -->
        <div class="ac-srs-prey-controls">
          <div class="ac-srs-prey-control-row">
            <label>
              <span>Font size</span>
              <input type="range" id="ac-srs-prey-hz-size" min="18" max="36" value="24" step="1">
              <span id="ac-srs-prey-hz-val">24px</span>
            </label>
          </div>
          <div class="ac-srs-prey-control-row">
            <label>
              <span>Pinyin size</span>
              <input type="range" id="ac-srs-prey-py-size" min="14" max="28" value="18" step="1">
              <span id="ac-srs-prey-py-val">18px</span>
            </label>
          </div>
          <div class="ac-srs-prey-stats">
            <span>Total Card Views: <strong id="ac-srs-prey-total-views">0</strong></span>
          </div>
        </div>
        
        <!-- List content -->
        <div class="ac-srs-prey-content" id="ac-srs-prey-content">
          <!-- Rows will be rendered here -->
        </div>
      </div>
    `;
    
    // Close button
    overlay.querySelector('#ac-srs-prey-close').addEventListener('click', () => {
      overlay.classList.remove('ac-srs-open');
    });
    
    // Close on backdrop click
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('ac-srs-open');
      }
    });
    
    // Font size controls
    const hzSlider = overlay.querySelector('#ac-srs-prey-hz-size');
    const pySlider = overlay.querySelector('#ac-srs-prey-py-size');
    const hzVal = overlay.querySelector('#ac-srs-prey-hz-val');
    const pyVal = overlay.querySelector('#ac-srs-prey-py-val');
    
    hzSlider.addEventListener('input', () => {
      const size = hzSlider.value;
      hzVal.textContent = size + 'px';
      document.querySelectorAll('.ac-srs-prey-word').forEach(el => {
        el.style.fontSize = size + 'px';
      });
    });
    
    pySlider.addEventListener('input', () => {
      const size = pySlider.value;
      pyVal.textContent = size + 'px';
      document.querySelectorAll('.ac-srs-prey-pinyin').forEach(el => {
        el.style.fontSize = size + 'px';
      });
    });
    
    return overlay;
  }
  
  function renderPreyList(items, startIndex) {
    const content = document.getElementById('ac-srs-prey-content');
    if (!content) return;
    
    // Load SRS data for this list (if exists)
    const srsData = loadSRSData(currentListId);
    let totalViews = 0;
    
    const rows = items.map((item, idx) => {
      const number = startIndex + idx;
      const isChinese = item.py && item.py.trim() !== '';
      
      // Get SRS stats (will be all zeros for now until Step 4)
      const srsItem = srsData.items && srsData.items[number - 1];
      const level = (srsItem && srsItem.level) || 0;
      const r = (srsItem && srsItem.r) || 0;
      const w = (srsItem && srsItem.w) || 0;
      const t = r - w; // score = right - wrong
      const nextDue = (srsItem && srsItem.nP) || '—';
      const views = (srsItem && srsItem.t) || 0; // total views (card counter)
      totalViews += views;
      
      // Check if pinyin should be visible for this item
      const pyVisible = pinyinVisible.has(number) ? pinyinVisible.get(number) : pinyinDefaultVisible;
      const pyClass = pyVisible ? '' : 'ac-srs-py-hidden';
      
      if (isChinese) {
        // Chinese item: number • zh • py • next • level • (t,r,w)
        return `
          <div class="ac-srs-prey-row" data-idx="${number}">
            <span class="ac-srs-prey-index">${number}.</span>
            <span class="ac-srs-prey-word" data-idx="${number}" data-word="${item.zh}">
              ${item.zh}
              <span class="ac-srs-prey-views">${views}</span>
            </span>
            <span class="ac-srs-prey-pinyin ${pyClass}" data-idx="${number}">${item.py}</span>
            <span class="ac-srs-prey-meta">
              <span class="ac-srs-prey-next">${nextDue}</span>
              <span class="ac-srs-prey-level">L${level}</span>
              <span class="ac-srs-prey-stats">(${t},${r},${w})</span>
            </span>
          </div>
        `;
      } else {
        // Non-Chinese: number • tr • zh • next • level • (t,r,w)
        return `
          <div class="ac-srs-prey-row" data-idx="${number}">
            <span class="ac-srs-prey-index">${number}.</span>
            <span class="ac-srs-prey-word" data-idx="${number}" data-word="${item.zh}">
              ${item.tr}
              <span class="ac-srs-prey-views">${views}</span>
            </span>
            <span class="ac-srs-prey-pinyin ${pyClass}" data-idx="${number}">${item.zh}</span>
            <span class="ac-srs-prey-meta">
              <span class="ac-srs-prey-next">${nextDue}</span>
              <span class="ac-srs-prey-level">L${level}</span>
              <span class="ac-srs-prey-stats">(${t},${r},${w})</span>
            </span>
          </div>
        `;
      }
    }).join('');
    
    content.innerHTML = rows;
    
    // Update total views
    document.getElementById('ac-srs-prey-total-views').textContent = totalViews;
    
    // Wire up interactions
    wirePreyInteractions(items, startIndex);
  }
  
  function wirePreyInteractions(items, startIndex) {
    const content = document.getElementById('ac-srs-prey-content');
    if (!content) return;
    
    // Click on row → open card details (EXCEPT pinyin area and word)
    content.addEventListener('click', (e) => {
      // Don't open card if clicking pinyin
      if (e.target.closest('.ac-srs-prey-pinyin')) return;
      
      // Don't open card if clicking the word (Pleco)
      if (e.target.closest('.ac-srs-prey-word')) return;
      
      // Find the row
      const row = e.target.closest('.ac-srs-prey-row');
      if (!row) return;
      
      const idx = parseInt(row.getAttribute('data-idx'));
      if (isNaN(idx)) return;
      
      const arrayIdx = idx - startIndex;
      if (arrayIdx < 0 || arrayIdx >= items.length) return;
      
      // Open the card (NO preventDefault, NO stopPropagation)
      openCardDetails(items, arrayIdx, startIndex);
    }); // NO capture phase!
    
    // Click on pinyin: toggle visibility + speak word
    content.addEventListener('click', (e) => {
      const pyEl = e.target.closest('.ac-srs-prey-pinyin');
      if (pyEl && Date.now() >= suppressClicksUntil) {
        const idx = parseInt(pyEl.getAttribute('data-idx'));
        const item = items[idx - startIndex];
        if (!item) return;
        
        // Toggle pinyin visibility
        const currentVis = pinyinVisible.has(idx) ? pinyinVisible.get(idx) : pinyinDefaultVisible;
        pinyinVisible.set(idx, !currentVis);
        pyEl.classList.toggle('ac-srs-py-hidden');
        
        // Speak the word
        const word = item.zh || item.tr;
        const lang = item.lang || (item.py ? 'zh-CN' : 'en-US');
        playTTS(word, lang);
        
        e.stopPropagation();
      }
    });
    
    // Click on Chinese word: send to Pleco (mobile only, Chinese only)
    content.addEventListener('click', (e) => {
      const wordEl = e.target.closest('.ac-srs-prey-word');
      if (wordEl) {
        const idx = parseInt(wordEl.getAttribute('data-idx'));
        const item = items[idx - startIndex];
        if (!item) return;
        
        // Only for Chinese items on mobile
        const isChinese = item.py && item.py.trim() !== '';
        const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
        
        if (isChinese && isMobile) {
          const word = item.zh;
          if (word) {
            location.href = `plecoapi://x-callback-url/s?q=${encodeURIComponent(word)}`;
          }
        }
        
        e.stopPropagation();
      }
    });
    
    // Long-press on any pinyin: toggle all with confirm
    let longPressTarget = null;
    
    content.addEventListener('pointerdown', (e) => {
      const pyEl = e.target.closest('.ac-srs-prey-pinyin');
      if (pyEl) {
        longPressTarget = pyEl;
        clearTimeout(longPressTimer);
        longPressFired = false;
        
        longPressTimer = setTimeout(() => {
          longPressFired = true;
          toggleAllPinyinWithConfirm();
          suppressClicksUntil = Date.now() + 500;
        }, LONG_PRESS_MS);
      }
    }, true);
    
    const clearTimer = () => {
      clearTimeout(longPressTimer);
      if (longPressFired) {
        suppressClicksUntil = Date.now() + 500;
      }
      longPressTarget = null;
    };
    
    content.addEventListener('pointerup', clearTimer, true);
    content.addEventListener('pointercancel', clearTimer, true);
  }
  
  function toggleAllPinyinWithConfirm() {
    const allVisible = pinyinVisible.size === 0 ? pinyinDefaultVisible : 
                       Array.from(pinyinVisible.values()).every(v => v);
    
    const msg = allVisible 
      ? 'Hide Pinyin for ALL cards in this list?'
      : 'Show Pinyin for ALL cards in this list?';
    
    if (!confirm(msg)) return;
    
    const newState = !allVisible;
    pinyinDefaultVisible = newState;
    pinyinVisible.clear();
    
    // Update UI
    document.querySelectorAll('.ac-srs-prey-pinyin').forEach(el => {
      if (newState) {
        el.classList.remove('ac-srs-py-hidden');
      } else {
        el.classList.add('ac-srs-py-hidden');
      }
    });
  }
  
  function loadSRSData(listId) {
    try {
      const key = `${STORAGE_KEYS.SRS_PREFIX}${listId}`;
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : { settings: {}, items: [] };
    } catch (e) {
      return { settings: {}, items: [] };
    }
  }
  
  function playTTS(text, lang) {
    if (!text) return;
    
    // Cancel any ongoing speech
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang || 'zh-CN';
    utterance.rate = srsSettings.sentenceSpeed || 1.0;
    
    window.speechSynthesis.speak(utterance);
  }
  
  // ========== AUTO-INIT ==========
  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSRS);
  } else {
    initSRS();
  }
  
})();