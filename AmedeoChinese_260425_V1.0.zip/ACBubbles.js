/**
 * ACBubbles.js - Bubble Game Module for Amedeo Chinese
 * Floating bubble vocabulary practice with physics
 */

const ACBubbles = (function() {
    'use strict';
    
    // State
    let backlog = [];
    let bubbleObjects = [];
    let currentChar = '';
    let animationId = null;
    
    let bubbleSize = 44;
    let fontSize = 28;
    let speed = 0.2;
    let speechSpeed = 1.0;
    
    const MAX_BUBBLES = 7;
    
    // Physics constants
    const DRIFT_PAD = 8;
    const DRIFT_REPULSE_K = 2.115;
    let DRIFT_REPULSE_DIST = Math.max(28, Math.round(bubbleSize * 1.05));
    let DRIFT_BORDER_PUSH = 0.25 * speed;
    let DRIFT_MAX_SPEED = 3 * speed;
    
    // Color palette
    const colors = ['#1E88E5', '#E53935', '#43A047', '#FB8C00', '#8E24AA'];
    
    // DOM elements
    let gameOverlay, gameStage, miniCard, miniBackdrop;
    let cHan, cPyTop, cTr, cReplay;
    
    // Current vocabulary data
    let vocabularyData = {};
    
    // ========== INITIALIZATION ==========
    
    function init() {
        console.log('🎮 ACBubbles initializing...');
        createOverlayHTML();
        attachEventListeners();
        loadSettings();
        console.log('✅ ACBubbles initialized');
    }
    
    function createOverlayHTML() {
        // Create overlay if it doesn't exist
        if (document.getElementById('bubbleGameOverlay')) return;
        
        const overlayHTML = `
            <div class="bubble-game-overlay" id="bubbleGameOverlay">
                <div class="bubble-game-container">
                    <div class="bubble-game-stage" id="bubbleGameStage">
                        <button class="bubble-exit-btn" id="bubbleExitBtn">×</button>
                    </div>
                    <div class="bubble-controls">
                        <div class="bubble-control-item">
                            <label for="bubbleSpeechSpeedSlider">Speech</label>
                            <input type="range" id="bubbleSpeechSpeedSlider" min="1" max="15" value="10" step="1">
                            <span class="bubble-control-value" id="bubbleSpeechSpeedValue">1.0×</span>
                        </div>
                        <div class="bubble-control-item">
                            <label for="bubbleSpeedSlider">Speed</label>
                            <input type="range" id="bubbleSpeedSlider" min="1" max="8" value="2" step="1">
                            <span class="bubble-control-value" id="bubbleSpeedValue">0.2×</span>
                        </div>
                        <div class="bubble-control-item">
                            <label for="bubbleSizeSlider">Size</label>
                            <input type="range" id="bubbleSizeSlider" min="32" max="128" value="44" step="4">
                            <span class="bubble-control-value" id="bubbleSizeValue">44px</span>
                        </div>
                        <div class="bubble-control-item">
                            <label for="bubbleFontSlider">Characters</label>
                            <input type="range" id="bubbleFontSlider" min="18" max="42" value="28" step="2">
                            <span class="bubble-control-value" id="bubbleFontValue">28px</span>
                        </div>
                        <div class="bubble-control-item">
                            <label></label>
                            <div style="display: flex; align-items: center; gap: 4px;">
                                <input type="checkbox" id="bubbleKaitiCheck">
                                <span>Kaiti (楷体)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="bubble-mini-card" id="bubbleMiniCard">
                <div class="bubble-mini-card-backdrop" id="bubbleCardBackdrop"></div>
                <div class="bubble-mini-card-content">
                    <div class="bubble-mini-card-buttons">
                        <button class="bubble-btn-i-knew" id="bubbleBtnIKnew">I knew</button>
                        <button class="bubble-btn-again" id="bubbleBtnAgain">Again</button>
                        <button class="bubble-btn-export" id="bubbleBtnExport">Export</button>
                    </div>
                    <div class="bubble-character" id="bubbleCardChar"></div>
                    <div class="bubble-pinyin" id="bubbleCardPinyin"></div>
                    <div class="bubble-translation" id="bubbleCardTranslation"></div>
                    <button class="bubble-speaker-btn" id="bubbleSpeakerBtn">🔊</button>
                </div>
            </div>
            
            <div class="bubble-success-toast" id="bubbleSuccessToast">All done! 🎉</div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', overlayHTML);
        
        // Get DOM references
        gameOverlay = document.getElementById('bubbleGameOverlay');
        gameStage = document.getElementById('bubbleGameStage');
        miniCard = document.getElementById('bubbleMiniCard');
        miniBackdrop = document.getElementById('bubbleCardBackdrop');
        cHan = document.getElementById('bubbleCardChar');
        cPyTop = document.getElementById('bubbleCardPinyin');
        cTr = document.getElementById('bubbleCardTranslation');
        cReplay = document.getElementById('bubbleSpeakerBtn');
    }
    
    // ========== LOCALSTORAGE ==========
    
    function loadSettings() {
        try {
            const stored = localStorage.getItem('ACVariables');
            if (stored) {
                const settings = JSON.parse(stored);
                
                if (settings.bubbleSpeed !== undefined) {
                    speed = settings.bubbleSpeed;
                    document.getElementById('bubbleSpeedSlider').value = speed * 10;
                    document.getElementById('bubbleSpeedValue').textContent = speed.toFixed(1) + '×';
                }
                if (settings.bubbleSize !== undefined) {
                    bubbleSize = settings.bubbleSize;
                    document.getElementById('bubbleSizeSlider').value = bubbleSize;
                    document.getElementById('bubbleSizeValue').textContent = bubbleSize + 'px';
                }
                if (settings.bubbleFontSize !== undefined) {
                    fontSize = settings.bubbleFontSize;
                    document.getElementById('bubbleFontSlider').value = fontSize;
                    document.getElementById('bubbleFontValue').textContent = fontSize + 'px';
                }
                if (settings.bubbleSpeechSpeed !== undefined) {
                    speechSpeed = settings.bubbleSpeechSpeed;
                    document.getElementById('bubbleSpeechSpeedSlider').value = speechSpeed * 10;
                    document.getElementById('bubbleSpeechSpeedValue').textContent = speechSpeed.toFixed(1) + '×';
                }
                if (settings.bubbleKaiti !== undefined) {
                    document.getElementById('bubbleKaitiCheck').checked = settings.bubbleKaiti;
                    if (settings.bubbleKaiti) {
                        document.body.classList.add('bubble-kaiti-on');
                    }
                }
                
                DRIFT_BORDER_PUSH = 0.25 * speed;
                DRIFT_MAX_SPEED = 3 * speed;
                DRIFT_REPULSE_DIST = Math.max(28, Math.round(bubbleSize * 1.05));
            }
        } catch (e) {
            console.error('Error loading bubble settings:', e);
        }
    }
    
    function saveSettings() {
        try {
            const stored = localStorage.getItem('ACVariables');
            const settings = stored ? JSON.parse(stored) : {};
            
            settings.bubbleSpeed = speed;
            settings.bubbleSize = bubbleSize;
            settings.bubbleFontSize = fontSize;
            settings.bubbleSpeechSpeed = speechSpeed;
            settings.bubbleKaiti = document.getElementById('bubbleKaitiCheck').checked;
            
            localStorage.setItem('ACVariables', JSON.stringify(settings));
        } catch (e) {
            console.error('Error saving bubble settings:', e);
        }
    }
    
    // ========== EVENT LISTENERS ==========
    
    function attachEventListeners() {
        document.getElementById('bubbleExitBtn').addEventListener('click', exitGame);
        document.getElementById('bubbleCardBackdrop').addEventListener('click', keepBubble);
        document.getElementById('bubbleBtnIKnew').addEventListener('click', removeBubble);
        document.getElementById('bubbleBtnAgain').addEventListener('click', keepBubble);
        document.getElementById('bubbleBtnExport').addEventListener('click', () => {
            // Show "Not yet active" toast
            const toast = document.getElementById('bubbleSuccessToast');
            toast.textContent = 'Not yet active';
            toast.classList.add('bubble-show');
            setTimeout(() => {
                toast.classList.remove('bubble-show');
                toast.textContent = 'All done! 🎉'; // Reset for normal completion
            }, 1500);
        });
        document.getElementById('bubbleSpeakerBtn').addEventListener('click', () => speak(currentChar));
        
        document.getElementById('bubbleSpeechSpeedSlider').addEventListener('input', (e) => {
            speechSpeed = parseFloat(e.target.value) / 10;
            document.getElementById('bubbleSpeechSpeedValue').textContent = speechSpeed.toFixed(1) + '×';
            saveSettings();
        });
        
        document.getElementById('bubbleSpeedSlider').addEventListener('input', (e) => {
            speed = parseFloat(e.target.value) / 10;
            document.getElementById('bubbleSpeedValue').textContent = speed.toFixed(1) + '×';
            DRIFT_BORDER_PUSH = 0.25 * speed;
            DRIFT_MAX_SPEED = 3 * speed;
            saveSettings();
        });
        
        document.getElementById('bubbleSizeSlider').addEventListener('input', (e) => {
            bubbleSize = parseInt(e.target.value);
            document.getElementById('bubbleSizeValue').textContent = bubbleSize + 'px';
            DRIFT_REPULSE_DIST = Math.max(28, Math.round(bubbleSize * 1.05));
            bubbleObjects.forEach(b => {
                b.el.style.width = bubbleSize + 'px';
                b.el.style.height = bubbleSize + 'px';
            });
            saveSettings();
        });
        
        document.getElementById('bubbleFontSlider').addEventListener('input', (e) => {
            fontSize = parseInt(e.target.value);
            document.getElementById('bubbleFontValue').textContent = fontSize + 'px';
            bubbleObjects.forEach(b => {
                b.el.style.fontSize = fontSize + 'px';
            });
            saveSettings();
        });
        
        document.getElementById('bubbleKaitiCheck').addEventListener('change', (e) => {
            const useKaiti = e.target.checked;
            if (useKaiti) {
                document.body.classList.add('bubble-kaiti-on');
            } else {
                document.body.classList.remove('bubble-kaiti-on');
            }
            saveSettings();
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (!miniCard || !miniCard.classList.contains('bubble-show')) return;
            
            const key = e.key.toLowerCase();
            if (key === 'w' || key === 'escape') {
                e.preventDefault();
                keepBubble();
            } else if (key === 'r' || key === 'enter') {
                e.preventDefault();
                removeBubble();
            }
        });
    }
    
    // ========== GAME START ==========
    
    function launch(words) {
        console.log('🚀 Launching bubble game with', words.length, 'words');
        vocabularyData = words;
        
        backlog = words.map(w => w.chinese);
        bubbleObjects = [];
        
        gameOverlay.classList.add('bubble-active');
        
        setTimeout(() => {
            console.log('Creating bubbles, stage dimensions:', gameStage.clientWidth, 'x', gameStage.clientHeight);
            refillBubbles();
            animate();
        }, 100);
    }
    
    function refillBubbles() {
        while (bubbleObjects.length < MAX_BUBBLES && backlog.length > 0) {
            const char = backlog.shift();
            createSingleBubble(char);
        }
        
        if (bubbleObjects.length === 0 && backlog.length === 0) {
            endGame();
        }
    }
    
    function createSingleBubble(char) {
        const w = gameStage.clientWidth;
        const h = gameStage.clientHeight;
        const i = bubbleObjects.length;
        
        const bubble = document.createElement('div');
        bubble.className = 'bubble';
        bubble.textContent = char;
        bubble.style.width = bubbleSize + 'px';
        bubble.style.height = bubbleSize + 'px';
        bubble.style.fontSize = fontSize + 'px';
        bubble.style.color = colors[i % colors.length];
        
        const margin = bubbleSize / 2 + DRIFT_PAD;
        const x = margin + Math.random() * (w - 2 * margin);
        const y = margin + Math.random() * (h - 2 * margin);
        const angle = Math.random() * 2 * Math.PI;
        const initialSpeed = 0.5 + Math.random() * 1.5;
        
        const bubbleObj = {
            el: bubble,
            char: char,
            x: x,
            y: y,
            vx: Math.cos(angle) * initialSpeed * speed,
            vy: Math.sin(angle) * initialSpeed * speed
        };
        
        bubble.addEventListener('click', () => {
            console.log('Bubble clicked:', char);
            showCard(char);
        });
        
        gameStage.appendChild(bubble);
        bubbleObjects.push(bubbleObj);
    }
    
    // ========== PHYSICS ANIMATION ==========
    
    function animate() {
        const w = gameStage.clientWidth;
        const h = gameStage.clientHeight;
        
        // Bubble-to-bubble repulsion
        for (let i = 0; i < bubbleObjects.length; i++) {
            for (let j = i + 1; j < bubbleObjects.length; j++) {
                const A = bubbleObjects[i];
                const B = bubbleObjects[j];
                const dx = A.x - B.x;
                const dy = A.y - B.y;
                const d = Math.hypot(dx, dy) || 0.0001;
                
                if (d < DRIFT_REPULSE_DIST) {
                    const f = (DRIFT_REPULSE_DIST - d) * DRIFT_REPULSE_K / d;
                    const fx = dx * f;
                    const fy = dy * f;
                    A.vx += fx;
                    A.vy += fy;
                    B.vx -= fx;
                    B.vy -= fy;
                }
            }
        }
        
        const margin = (bubbleSize / 2) + DRIFT_PAD;
        
        bubbleObjects.forEach(bubble => {
            // Limit speed
            const s = Math.hypot(bubble.vx, bubble.vy);
            if (s > DRIFT_MAX_SPEED) {
                bubble.vx = (bubble.vx / s) * DRIFT_MAX_SPEED;
                bubble.vy = (bubble.vy / s) * DRIFT_MAX_SPEED;
            }
            
            // Move
            bubble.x += bubble.vx;
            bubble.y += bubble.vy;
            
            // Hard boundary - bubbles CANNOT escape
            if (bubble.x < margin) {
                bubble.x = margin;
                bubble.vx = Math.abs(bubble.vx);
            }
            if (bubble.x > w - margin) {
                bubble.x = w - margin;
                bubble.vx = -Math.abs(bubble.vx);
            }
            if (bubble.y < margin) {
                bubble.y = margin;
                bubble.vy = Math.abs(bubble.vy);
            }
            if (bubble.y > h - margin) {
                bubble.y = h - margin;
                bubble.vy = -Math.abs(bubble.vy);
            }
            
            // Update DOM
            bubble.el.style.transform = `translate(${bubble.x - bubbleSize / 2}px, ${bubble.y - bubbleSize / 2}px)`;
        });
        
        animationId = requestAnimationFrame(animate);
    }
    
    // ========== MINI CARD ==========
    
    function showCard(char) {
        console.log('showCard called for:', char);
        currentChar = char;
        
        // Find the word
        const word = vocabularyData.find(w => w.chinese === char);
        console.log('Found word:', word);
        
        // Get settings for language and font sizes
        const stored = localStorage.getItem('ACVariables');
        const settings = stored ? JSON.parse(stored) : {};
        const langCode = (settings.language || 'EN').toLowerCase();
        
        // Default font sizes (from DEFAULT_SETTINGS in index.html)
        const chineseFontSize = settings.chineseFontSize || 20;
        const pinyinFontSize = settings.pinyinFontSize || 16;
        const translationFontSize = settings.translationFontSize || 16;
        
        // Set content
        cHan.textContent = char;
        cPyTop.textContent = word ? word.pinyin : '';
        cTr.textContent = word ? (word[langCode] || word.en) : '';
        
        // Apply font sizes with multipliers to make them more prominent
        cHan.style.fontSize = (chineseFontSize * 1.5) + 'px';
        cPyTop.style.fontSize = (pinyinFontSize * 1.2) + 'px';
        cTr.style.fontSize = (translationFontSize * 1.0) + 'px';
        
        miniCard.classList.add('bubble-show');
        speak(char);
    }
    
    function hideCard() {
        miniCard.classList.remove('bubble-show');
    }
    
    function removeBubble() {
        const idx = bubbleObjects.findIndex(b => b.char === currentChar);
        if (idx !== -1) {
            const bubble = bubbleObjects[idx];
            if (bubble.el && bubble.el.parentNode) {
                bubble.el.parentNode.removeChild(bubble.el);
            }
            bubbleObjects.splice(idx, 1);
        }
        
        hideCard();
        refillBubbles();
    }
    
    function keepBubble() {
        hideCard();
    }
    
    function speak(text) {
        if (!('speechSynthesis' in window)) return;
        try {
            speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'zh-CN';
            utterance.rate = speechSpeed;
            speechSynthesis.speak(utterance);
        } catch (e) {
            console.error('Speech error:', e);
        }
    }
    
    // ========== GAME END ==========
    
    function exitGame() {
        cancelAnimationFrame(animationId);
        gameOverlay.classList.remove('bubble-active');
        
        // Clear bubbles
        bubbleObjects.forEach(b => {
            if (b.el && b.el.parentNode) b.el.parentNode.removeChild(b.el);
        });
        bubbleObjects = [];
        backlog = [];
    }
    
    function endGame() {
        cancelAnimationFrame(animationId);
        const toast = document.getElementById('bubbleSuccessToast');
        toast.classList.add('bubble-show');
        setTimeout(() => {
            toast.classList.remove('bubble-show');
            exitGame();
        }, 1500);
    }
    
    // ========== PUBLIC API ==========
    
    return {
        init: init,
        launch: launch
    };
})();

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => ACBubbles.init());
} else {
    ACBubbles.init();
}